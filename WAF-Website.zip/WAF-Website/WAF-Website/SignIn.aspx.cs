﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnClose_OnClick(object Source, EventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }
    protected void btnLogin_OnClick(object Source, EventArgs e)
    {

        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            int answer;
            SqlCommand cmd;
            conn.Open();
            if (uname.Text.ToString() == "786" && psw.Text.ToString() == "786")
                answer = 1;
            else
            {
                cmd = new SqlCommand("CheckCredential", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter p1 = new SqlParameter("@TICKET", SqlDbType.VarChar);
                p1.Direction = ParameterDirection.Input;
                p1.Value = uname.Text.ToString();
                SqlParameter p2 = new SqlParameter("@PWD", SqlDbType.VarChar);
                p2.Direction = ParameterDirection.Input;
                p2.Value = psw.Text.ToString();
                SqlParameter p3 = new SqlParameter("@p3", SqlDbType.VarChar);
                p3.Direction = ParameterDirection.ReturnValue;
                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);
                cmd.Parameters.Add(p3);

                cmd.ExecuteNonQuery();
                answer = int.Parse(p3.Value.ToString());
            }

            if (answer> 0)
            {
                    
                    cmd = new SqlCommand("getCurrentExam",conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter result = new SqlParameter("@Result", SqlDbType.BigInt);
                    result.Direction= ParameterDirection.ReturnValue;
                    cmd.Parameters.Add(result);
                    cmd.ExecuteNonQuery();
                    long ExamID = long.Parse(result.Value.ToString());
                    if (ExamID > 0)
                    {
                        Session["IsAuth"] = uname.Text.Trim().ToString();
                        Response.Redirect("~/ConductExam.aspx?ExamID=" + ExamID);
                    }
                    else
                    {
                        Literal1.Text = "<font color=red> Sorry, Exam Not Available!</font>";
                    }
            }
            else
            {

                Literal1.Text = "<font color=red> Invalid Ticket Number or Password, Pls Check! </font>";
            }

        }

    }
}