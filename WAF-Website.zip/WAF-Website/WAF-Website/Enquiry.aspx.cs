﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Enquiry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string enq_title = Request.Form["title"].ToString();
        string enq_name = Request.Form["name"].ToString();
        string enq_cname = Request.Form["cname"].ToString();
        string enq_city = Request.Form["city"].ToString();
        string enq_phone = Request.Form["phone"].ToString();
        string enq_email = Request.Form["email"].ToString();
        string enq_business = Request.Form["ctype"].ToString();
        string remarks = Request.Form["remarks"].ToString();


        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            string strQuery;
            strQuery = @"insert into enquiry (enq_title, enq_name, enq_cname, enq_city, enq_phone, enq_email, enq_business, remarks)  values('"
                            + enq_title + "','"
                            + enq_name + "','"
                            + enq_cname + "','"
                            + enq_city + "','"
                            + enq_phone + "','"
                            + enq_email + "','"
                            + enq_business + "','"
                            + remarks + "')";
            (new SqlCommand(strQuery, conn)).ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, GetType(), "Enquiry", "alert('Thanks! for your enquiry, will contact you soon.');", true);
            conn.Close();
        }
        //Literal1.Text = Request["InputName"].ToString();
    }
}