﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;

public partial class ConductExam : System.Web.UI.Page
{
    private static SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    static DataTable dt;
    static int intCounter = 0;
    static ExamResult curExamResult;
    static List<QuestionDetail> QuestionDetails;
    static ExamDetail curExamDetails;
    static int ansCount = 0;
    static long TicketNumber = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            TicketNumber =long.Parse(Session["IsAuth"].ToString());
            if (TicketNumber > 0)
            {
                Session["IsAuth"] = 0;
                mp1.Show();
                ClientScript.RegisterStartupScript(GetType(), "Javascript", "javascript:StartDur(" + Request["ExamID"].ToString() + "); ", true);
            }
            else
            {
                Response.Redirect("~/Home.aspx");
            }
        }

    }
    protected static void getData(string id)
    {
        if (conn.State == ConnectionState.Closed)
            conn.Open();
        SqlCommand objCommand = new SqlCommand(@"select d.*,a.ExamName, iif(IsScheduleActive=1,dbo.GETDATEDIFFASSEC(examdatetime),5) as WaitSeconds, IsScheduleActive, IsTrial from Exam a join QGroup b on a.GroupID=b.GroupID join QGroupQuestions c on b.GroupID=c.GroupID join Question d on d.QuestionID=c.QuestionID where a.ExamID='" + id + "' order by c.OrderID", conn);
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        dt = new DataTable();
        da.Fill(dt);
        if(conn.State == ConnectionState.Open)
            conn.Close();
    }

    protected static string TrimAll(string str)
    {
        string replaceWith = "";
        return str.Replace("\r\n", replaceWith).Replace("\n", replaceWith).Replace("\r", replaceWith).Replace("<br>", replaceWith).Replace("<p>", "<br>").Replace("</p>", replaceWith);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        mp1.Hide();
        Response.Redirect("ModalExam1.aspx");
        if (conn.State == ConnectionState.Open)
            conn.Close();

    }

    public class ExamResult
    {
        public long ExamID { get; set; }
        public string ExamName { get; set; }
        public int QuestionsAnswered { get; set; }
        public int QuestionsAnsweredRight { get; set; }
        public int QuestionsAnsweredWrong { get; set; }
        public int TotalMarks { get; set; }
        public float Percentage { get; set; }
        public long TicketNumber{ get; set; }
        public int SkillPrize { get; set; }
        public int Prize { get; set; }
        
    }

    public class QuestionDetail
    {
        public long QuestionID { get; set; }
        public string DirectionsToSolve { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string OptionE { get; set; }
        public string OptionF { get; set; }
        public string OptionG { get; set; }
        public string OptionH { get; set; }
        public string OptionI { get; set; }
        public string CorrectAnswer { get; set; }
        public string Answered { get; set; }
        public int Result { get; set; }
        public int IsDirectionToSolve { get; set; }
        public int OptionCount { get; set; }
        public int IsImage { get; set; }
        public int Duration { get; set; }
        public int Total { get; set; }
        public string ExamName { get; set; }
    }

    public class ExamDetail
    {
        public long TotalRecords { get; set; }
        public long WaitSeconds { get; set; }
        public int IsScheduleActive { get; set; }
        public int IsTrial { get; set; }
        public long TicketNumber { get; set; }
        public long WinningNumber { get; set; }
    }

    [System.Web.Services.WebMethod]
    public static ExamDetail  StartExam(string id)
    {
        getData(id);
        intCounter = 0;
        ansCount = 0;
        curExamResult = new ExamResult();
        curExamResult.ExamID = long.Parse(id);
        curExamResult.ExamName = dt.Rows[0]["ExamName"].ToString();
        curExamResult.TicketNumber = TicketNumber;
        curExamResult.QuestionsAnswered = dt.Rows.Count;
        QuestionDetails = new List<QuestionDetail>();
        curExamDetails = new ExamDetail();
        curExamDetails.TotalRecords = dt.Rows.Count;
        if(TicketNumber == 786)
            curExamDetails.WaitSeconds = 5;
        else
            curExamDetails.WaitSeconds = long.Parse(dt.Rows[0]["WaitSeconds"].ToString());

        curExamDetails.IsScheduleActive = int.Parse(dt.Rows[0]["IsScheduleActive"].ToString());
        curExamDetails.IsTrial = int.Parse(dt.Rows[0]["IsTrial"].ToString());
        curExamDetails.TicketNumber = TicketNumber;
        curExamDetails.WinningNumber = getWinningNumber(curExamResult.ExamID);
        return curExamDetails;
    }


    public static int FindPrize(long ExamID, long TicketNumber)
    {
        int retValue=0;
        try
        {
            conn.Open();
            
            retValue= int.Parse( (new SqlCommand(@"select top 1 prize from prizedetails 
                                where ExamID = '" + ExamID.ToString() +
                                                  "' and TicketNumber ='" + TicketNumber + "'", conn)).ExecuteScalar().ToString());
            conn.Close();

        }
        catch (Exception ex1)
        {
            if (conn.State == ConnectionState.Open)
                conn.Close();
        }
        return retValue;
    }

    public static int FindSkillPrize(int answer)
    {
        if (answer >= 2)
            return (6 - answer) + 1;
        else
            return 0;
    }

    public static long getWinningNumber(long ExamID)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            long GroupID = long.Parse(new SqlCommand("Select GroupID from exam where examid = '" + ExamID.ToString() + "'", con).ExecuteScalar().ToString());

            SqlCommand cmd = new SqlCommand("getwinningnumber",con);
            cmd.CommandType = CommandType.StoredProcedure;
            
            SqlParameter p1 = new SqlParameter("@GroupID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = GroupID;

            SqlParameter p2 = new SqlParameter("@p2", SqlDbType.BigInt);
            p2.Direction = ParameterDirection.ReturnValue;

            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);

            cmd.ExecuteNonQuery();
            long retValue= long.Parse(p2.Value.ToString());
            con.Close();
            
            return retValue;
            
        }

    }
    [System.Web.Services.WebMethod]
    public static int UpdateAnswer(string ans)
    {
        //if (ansCount == 1)
        //    QuestionDetails[ansCount].Answered = ans;
        //long x;
        //if (ansCount == dt.Rows.Count - 1)
        //    x = 1;
        QuestionDetails[ansCount].Answered = ans;
        if (QuestionDetails[ansCount].CorrectAnswer.ToUpper() == QuestionDetails[ansCount].Answered.ToUpper())
        {
            QuestionDetails[ansCount].Result = 1;
            curExamResult.QuestionsAnsweredRight++;
            curExamResult.TotalMarks++;
        }
        else
        {
            QuestionDetails[ansCount].Result = 0;
            curExamResult.QuestionsAnsweredWrong++;
        }
        curExamResult.Percentage = (100 * curExamResult.QuestionsAnsweredRight) / curExamResult.QuestionsAnswered;
        curExamResult.SkillPrize = FindSkillPrize(curExamResult.QuestionsAnsweredRight);
        curExamResult.Prize = FindPrize(curExamResult.ExamID, curExamResult.TicketNumber);
        
        if (ansCount == dt.Rows.Count - 1  )
        {
                conn.Open();
                SqlCommand command;
                SqlTransaction SqlTrans = conn.BeginTransaction("UpdateExam");

                command = new SqlCommand(@"DELETE FROM examresultdetails WHERE examresultid IN (SELECT examresultid FROM examresult WHERE ticketnumber =1 or ticketnumber=786)", conn);
                command.Transaction = SqlTrans;
                command.ExecuteNonQuery();
                new SqlCommand(@"DELETE FROM examresult WHERE ticketnumber =1 or ticketnumber=786", conn);
                command.Transaction = SqlTrans;
                command.ExecuteNonQuery(); 
                if (curExamResult.SkillPrize > 0 && TicketNumber > 1 && TicketNumber != 786)
                {
                    if (curExamResult.SkillPrize <= 2)
                        curExamResult.SkillPrize = 3;
                    if (curExamResult.Prize == 0)
                    {
                        command = new SqlCommand(@"INSERT INTO prizedetails(WinningNumber, Prize, TicketNumber, ExamID, ActualPrize) VALUES('" +
                                    curExamDetails.WinningNumber.ToString() + "','" +
                                    curExamResult.SkillPrize.ToString() + "','" +
                                    curExamResult.TicketNumber.ToString() + "','" +
                                    curExamResult.ExamID.ToString() + "','" +
                                    curExamResult.Prize.ToString() + "')", conn);
                        command.Transaction = SqlTrans;
                        command.ExecuteNonQuery();

                    }
                    //else if (curExamResult.SkillPrize < curExamResult.Prize)
                    else
                    {
                        
                        command = new SqlCommand(@"UPDATE prizedetails SET prize='" + curExamResult.SkillPrize +
                                                    "', ActualPrize ='" + curExamResult.Prize +
                                                    "' WHERE ExamID = '" + curExamResult.ExamID.ToString() +
                                                    "' AND TicketNumber = '" + curExamResult.TicketNumber.ToString() +
                                                    "'", conn);
                        command.Transaction = SqlTrans;

                        command.ExecuteNonQuery();
                    }
                }

                SqlCommand cmd = new SqlCommand(@"insert into examresult 
                                   (ExamID,TicketNumber, QuestionsAnswered,QuestionsAnsweredRight,QuestionsAnsweredWrong,TotalMarks,Percentage,SkillPrize, CreatedBy) values 
                                   ('" + curExamResult.ExamID.ToString() + "','" +
                                        curExamResult.TicketNumber.ToString() + "','" +
                                        curExamResult.QuestionsAnswered.ToString() + "','" +
                                        curExamResult.QuestionsAnsweredRight.ToString() + "','" +
                                        curExamResult.QuestionsAnsweredWrong.ToString() + "','" +
                                        curExamResult.TotalMarks.ToString() + "','" +
                                        curExamResult.Percentage.ToString() + "','" +
                                        curExamResult.SkillPrize.ToString() + "',null);SELECT CAST(scope_identity() AS bigint);", conn);
                cmd.Transaction = SqlTrans;
                long ExamResultID = (long)cmd.ExecuteScalar();
                try
                {
                    SqlCommand cmd1;
                    foreach (QuestionDetail item in QuestionDetails)
                    {
                        cmd1 = new SqlCommand(@"insert into examresultdetails
                                        (ExamResultID, QuestionID, CorrectAnswer, Answered, Result, CreatedBy) values ('" +
                                         ExamResultID + "','" +
                                         item.QuestionID + "','" +
                                         item.CorrectAnswer + "','" +
                                         item.Answered + "','" +
                                         item.Result + "',null)", conn);
                        cmd1.Transaction = SqlTrans;
                        cmd1.ExecuteNonQuery();

                    }
                    SqlTrans.Commit();
                    conn.Close();
                    return 1;
                }
                catch (Exception ex)
                {

                    try
                    {
                        SqlTrans.Rollback();
                    }
                    catch (Exception ex2) { }
                    if (conn.State == ConnectionState.Open)
                        conn.Close();
                    return -1;
                }
        }
        else
        {
            ansCount++;
            return 0;
        }
    }

    [System.Web.Services.WebMethod]
    public static ExamResult GetCurrentResult()
    {
        return curExamResult;
        //string sqlQry = "";
        //long newID = 0;
        //SqlCommand cmd;
        //conn.Open();
        //SqlTransaction trans = conn.BeginTransaction();
        //try
        //{
        //    sqlQry = @"insert into examresult(ExamID, UserID, QuestionsAnswered, QuestionsAnsweredRight, QuestionsAnsweredWrong, TotalMarks, Percentage, CreatedBy) values('" + curExamResult.ExamID.ToString() + "','" +
        //                        Membership.GetUser().ProviderUserKey.ToString() + "','" +
        //                        curExamResult.QuestionsAnswered.ToString() + "','" + curExamResult.QuestionsAnsweredRight.ToString() + "','" +
        //                        curExamResult.QuestionsAnsweredWrong.ToString() + "','" + curExamResult.TotalMarks.ToString() + "','" +
        //                        curExamResult.Percentage.ToString() + "','" + Membership.GetUser().ProviderUserKey.ToString() + "');SELECT SCOPE_IDENTITY();";
        //    cmd = new SqlCommand(sqlQry, conn);
        //    cmd.Transaction = trans;
        //    newID = long.Parse(cmd.ExecuteScalar().ToString());
        //    foreach (QuestionDetail Q in QuestionDetails)
        //    {
        //        sqlQry = @"insert into examresultdetails(ExamResultID, QuestionID, CorrectAnswer, Answered, Result, CreatedBy) values('" + newID.ToString() + "','" +
        //                Q.QuestionID.ToString() + "','" +
        //                Q.CorrectAnswer.ToString() + "','" + Q.Answered.ToString() + "','" +
        //                Q.Result.ToString() + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')";
        //        cmd = new SqlCommand(sqlQry, conn);
        //        cmd.Transaction = trans;
        //        cmd.ExecuteNonQuery();
        //    }
        //    trans.Commit();
        //    if (conn.State == ConnectionState.Open) conn.Close();
        //    return curExamResult;
        //}
        //catch (Exception e)
        //{

        //    trans.Rollback();
        //    if (conn.State == ConnectionState.Open) conn.Close();
        //    return null;
        //}

    }

    [System.Web.Services.WebMethod]
    public static QuestionDetail GetCurrentQuestion()
    {
        long QuesID;
        QuestionDetail curQuestionDetail = new QuestionDetail();
        DataRow dr = dt.Rows[intCounter];
        curQuestionDetail.OptionCount = 0;

        curQuestionDetail.ExamName = dr["ExamName"].ToString();
        QuesID = long.Parse(dr["QuestionID"].ToString());
        curQuestionDetail.QuestionID = QuesID;
        //DirectionToSolve
        if (!TrimAll(dr["DirectionsToSolve"].ToString()).Equals(""))
        {
            curQuestionDetail.DirectionsToSolve = "<tr> <td colspan='2' style=' background-color:#F5FFFA; border: 1px; border-color: black;' > <font color='black' size='2px'> <b> <u> Directions To Solve </u> </b>" + TrimAll(dr["DirectionsToSolve"].ToString()) + "  </font></td></tr>";
            curQuestionDetail.IsDirectionToSolve = 1;
        }
        else
            curQuestionDetail.IsDirectionToSolve = 0;

        //Image
        if (int.Parse(dr["IsImage"].ToString()) == 1)
            curQuestionDetail.IsImage = 1;
        else
            curQuestionDetail.IsImage = 0;

        //Question
        curQuestionDetail.Question = "<tr> <td colspan='2'>  <font color='#00008B' size='3px'> <b>" + dr["Question"].ToString() + " </b> </font></td></tr>";
        //Options
        if (!TrimAll(dr["OptionA"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionA = "<tr> <td> <b> <i> <font color='#00008B' size='3px'> A. &nbsp;&nbsp;  " + TrimAll(dr["OptionA"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionB"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionB = "<td> <b> <i> <font color='#00008B' size='3px'> B. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionB"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionB = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionC"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionC = "<tr> <td> <b> <i> <font color='#00008B' size='3px'> C. &nbsp;&nbsp;  " + TrimAll(dr["OptionC"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionD"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionD = "<td> <b> <i> <font color='#00008B' size='3px'> D. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionD"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionD = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionE"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionE = "<tr> <td> <b> <i> <font color='#00008B' size='3px'> E. &nbsp;&nbsp;  " + TrimAll(dr["OptionE"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionF"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionF = "<td> <b> <i> <font color='#00008B' size='3px'> F. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionF"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionF = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionG"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionG = "<tr> <td> <b> <i> <font color='#00008B' size='3px'> G. &nbsp;&nbsp;  " + TrimAll(dr["OptionG"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionH"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionH = "<td> <b> <i> <font color='#00008B' size='3px'> H. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionH"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionH = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionI"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionI = "<tr> <td> <b> <i> <font color='#00008B' size='3px'> I. &nbsp;&nbsp;  " + TrimAll(dr["OptionI"].ToString()) + "</b>  </i> </font></td><td> &nbsp; </td></tr>";
            curQuestionDetail.OptionCount++;
        }

        curQuestionDetail.Duration = int.Parse(dr["Duration"].ToString());
        curQuestionDetail.CorrectAnswer = dr["Answer"].ToString().Trim().ToUpper();
        intCounter++;
        QuestionDetails.Add(curQuestionDetail);
        return curQuestionDetail;
    }

}

