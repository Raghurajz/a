﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_ResultDetails : System.Web.UI.Page
{
    readonly PagedDataSource _pgsource = new PagedDataSource();
    int _firstIndex, _lastIndex;
    private int _pageSize = 6;
    protected long ExamID;
    protected long TicketNumber;


    private int CurrentPage
    {
        get
        {
            if (ViewState["CurrentPage"] == null)
            {
                return 0;
            }
            return ((int)ViewState["CurrentPage"]);
        }
        set
        {
            ViewState["CurrentPage"] = value;
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateExam();
        
            if (Request["id1"] != null && Request["id2"] != null)
            {
                TicketNumber= long.Parse(Request["id1"].ToString());
                ExamID = long.Parse(Request["id2"].ToString());
                DropDownList1.Visible = false;
                TextBox1.Visible = false;
                TextBox2.Visible = false;
                Button1.Visible = false;
                BindDataIntoRepeater();
            }
        }
    }

    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and isdeleted=0 order by examdatetime desc", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DropDownList1.Items.Clear();
            //DropDownList1.Items.Add(new ListItem("All","0"));
            foreach (DataRow dr in dt.Rows)
                DropDownList1.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }

    protected DataTable GetDataFromDb()
    {

            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd;
            if (TextBox2.Visible == true)
            {
                cmd = new SqlCommand(@"select ROW_NUMBER() Over (Order by ExamResultDetailsID) As [sno], q.*, e.*, er.*,erd.*
                                from Exam e join examresult er on e.ExamID=er.ExamID
                                            join examresultdetails erd on er.ExamResultID = erd.ExamResultID
                                            join Question q on erd.QuestionID = Q.QuestionID
                                            join alltickets at on er.TicketNumber = at.TicketNumber
                                where e.ExamID = '" + ExamID + "' and er.TicketNumber='" + TicketNumber + "' and PassWrd ='" + TextBox2.Text + "'", conn);
            }
            else
            {
                cmd = new SqlCommand(@"select ROW_NUMBER() Over (Order by ExamResultDetailsID) As [sno], q.*, e.*, er.*,erd.*
                                                from Exam e join examresult er on e.ExamID=er.ExamID
                                                            join examresultdetails erd on er.ExamResultID = erd.ExamResultID
                                                            join Question q on erd.QuestionID = Q.QuestionID
                                                where e.ExamID = '" + ExamID + "' and TicketNumber='" + TicketNumber + "'", conn);
            }
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "Question");
            DataTable dt = new DataTable();
            dt = ds.Tables["Question"];
            conn.Close();
            if (dt.Rows.Count == 0)
            {
                Literal2.Text = "<b> <i>  Result Details not found! </i></b>";
                return null;
            }
            else
            {
                return dt;
            }
    }

    private void BindDataIntoRepeater()
    {
        var dt = GetDataFromDb();
        if (dt != null)
        {
            Literal2.Text = "";
            _pgsource.DataSource = dt.DefaultView;
            _pgsource.AllowPaging = true;
            // Number of items to be displayed in the Repeater
            _pgsource.PageSize = _pageSize;
            //if (CurrentPage > _lastIndex)
            //    CurrentPage = _lastIndex;
            _pgsource.CurrentPageIndex = CurrentPage;
            // Keep the Total pages in View State
            ViewState["TotalPages"] = _pgsource.PageCount;
            // Example: "Page 1 of 10"
            lblpage.Text = "Page " + (CurrentPage + 1) + " of " + _pgsource.PageCount;
            // Enable First, Last, Previous, Next buttons
            lbPrevious.Enabled = !_pgsource.IsFirstPage;
            lbNext.Enabled = !_pgsource.IsLastPage;
            lbFirst.Enabled = !_pgsource.IsFirstPage;
            lbLast.Enabled = !_pgsource.IsLastPage;

            //Display Summary
            DisplaySummary(dt);
            // Bind data into repeater
            Repeater1.DataSource = _pgsource;
            Repeater1.DataBind();

            // Call the function to do paging
            HandlePaging();
        }
    }

    private void DisplaySummary(DataTable dt)
    {
        LtrlSummary.Text = "";
        LtrlSummary.Text += "<table width='90%' border='1'>";
        LtrlSummary.Text += "<tr>";
            LtrlSummary.Text += "<td> <b> Name of Exam  </b> </td>";
            LtrlSummary.Text += "<td> <b> Total Questions Asked </b> </td>";
            LtrlSummary.Text += "<td> <b> Answered Right </b> </td>";
            LtrlSummary.Text += "<td> <b> Answered Wrong </b> </td>";
            LtrlSummary.Text += "<td> <b> Prize </b> </td>";
        LtrlSummary.Text += "</tr>";
        
        LtrlSummary.Text += "<tr>";
        
        LtrlSummary.Text += "<td>";
        LtrlSummary.Text += dt.Rows[0]["ExamName"];    
        LtrlSummary.Text += "</td>";

        LtrlSummary.Text += "<td>";
        LtrlSummary.Text += dt.Rows[0]["QuestionsAnswered"];
        LtrlSummary.Text += "</td>";

        LtrlSummary.Text += "<td>";
        LtrlSummary.Text += dt.Rows[0]["QuestionsAnsweredRight"];
        LtrlSummary.Text += "</td>";

        LtrlSummary.Text += "<td>";
        LtrlSummary.Text += dt.Rows[0]["QuestionsAnsweredWrong"];
        LtrlSummary.Text += "</td>";

        LtrlSummary.Text += "<td>";
        LtrlSummary.Text += dt.Rows[0]["SkillPrize"];
        LtrlSummary.Text += "</td>";

        LtrlSummary.Text += "</tr>";
        LtrlSummary.Text += "</table>";
        LtrlSummary.Text += "<br />";
    }


    private void HandlePaging()
    {
        var dt = new DataTable();
        dt.Columns.Add("PageIndex"); //Start from 0
        dt.Columns.Add("PageText"); //Start from 1

        _firstIndex = CurrentPage - 5;
        if (CurrentPage > 5)
            _lastIndex = CurrentPage + 5;
        else
            _lastIndex = 10;

        // Check last page is greater than total page then reduced it 
        // to total no. of page is last index
        if (_lastIndex > Convert.ToInt32(ViewState["TotalPages"]))
        {
            _lastIndex = Convert.ToInt32(ViewState["TotalPages"]);
            _firstIndex = _lastIndex - 10;
        }

        if (_firstIndex < 0)
            _firstIndex = 0;

        // Now creating page number based on above first and last page index
        for (var i = _firstIndex; i < _lastIndex; i++)
        {
            var dr = dt.NewRow();
            dr[0] = i;
            dr[1] = i + 1;
            dt.Rows.Add(dr);
        }

        rptPaging.DataSource = dt;
        rptPaging.DataBind();
    }

    protected void lbFirst_Click(object sender, EventArgs e)
    {
        CurrentPage = 0;
        BindDataIntoRepeater();
    }
    protected void lbLast_Click(object sender, EventArgs e)
    {
        CurrentPage = (Convert.ToInt32(ViewState["TotalPages"]) - 1);
        BindDataIntoRepeater();
    }
    protected void lbPrevious_Click(object sender, EventArgs e)
    {
        CurrentPage -= 1;
        BindDataIntoRepeater();
    }
    protected void lbNext_Click(object sender, EventArgs e)
    {
        CurrentPage += 1;
        BindDataIntoRepeater();
    }

    protected void rptPaging_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (!e.CommandName.Equals("newPage")) return;
        CurrentPage = Convert.ToInt32(e.CommandArgument.ToString());
        BindDataIntoRepeater();
    }

    protected void rptPaging_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        var lnkPage = (LinkButton)e.Item.FindControl("lbPaging");
        if (lnkPage.CommandArgument != CurrentPage.ToString()) return;
        lnkPage.Enabled = false;
        lnkPage.BackColor = Color.FromName("#1E90FF");
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //e.Item.FindControl("divDirectionsToSolve")


    }
    protected string ShowQuestion(object item, object item1)
    {
        string retValue="";
        if (item.ToString() == "")
            return ""; //don't create any html
        else
        {
            if (item1 != DBNull.Value)
            {
                Session["pic"] = ((byte[])item1);
                string base64String = Convert.ToBase64String((byte[])Session["pic"]);
                retValue = string.Format("<tr style=' height: 30px;'><td colspan='4'> <img src=data:image/jpg;base64,{0} width=150px/> </td> </tr>", base64String);
            }
            return retValue+= string.Format("<tr style=' height: 30px;'><td colspan='4'> {0} </td> </tr>", item.ToString());
        }
    }

    protected string ShowDirections(object item, string title, object serial)
    {
        //if (item.ToString() == "")
        //{
        //    return ""; //don't create any html
        //}
        //else
        //{
            return string.Format("<tr><td colspan='4' style=' border: thin solid #32CD32; border-left: #32CD32; border-left-width:thick; border-left-style:inset;background-color: #FFFFFF; padding-left: 5px;'><b> <font color='green'> {0} </font> </b> {1}<br></br></td></tr>", title, item.ToString());
        //}

    }
    protected string ShowExplanation(object item, string title)
    {
        //if (item.ToString() == "")
        //    return ""; //don't create any html
        //else
            return string.Format("<tr ><td>&nbsp;</td> <td colspan='4' > <b> <font color='green'> {0} </font> </b> <br>  </br> {1} </td> </tr>", title, item.ToString());

    }
    protected string ShowDoubleColumn(object item1, string title1, object item2, string title2)
    {
        if (item1.ToString() == "" && item2.ToString() == "")
            return ""; //don't create any html
        else if (item2.ToString() == "")
            return string.Format("<tr style=' height: 30px;'><td><font color=blue> <b> {0}  </b> </font></td><td>{1}</td></tr>", title1, item1.ToString());
        else
            return string.Format("<tr style=' height: 30px;'><td><font color=blue> <b> {0}  </b> </font></td><td>{1}</td><td><font color=blue> <b> {2}  </b> </font></td><td>{3}</td></tr>", title1, item1.ToString(), title2, item2.ToString());

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Literal2.Text = "";
        LtrlSummary.Text = "";
        _pgsource.DataSource = null;
        Repeater1.DataSource = null;
        Repeater1.DataBind();

        if (DropDownList1.SelectedIndex >= 0 && TextBox1.Text.Trim().Length > 0)
        {
            ExamID = long.Parse( DropDownList1.SelectedValue);
            TicketNumber =long.Parse(TextBox1.Text.Trim());
            BindDataIntoRepeater();
        }
        //SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        //conn.Open();
        //SqlCommand cmd = new SqlCommand("Select ExamID from Alltickets where TicketNumber = '" + TextBox1.Text + "'", conn);
        //object retObj = cmd.ExecuteScalar();
        //if (retObj != null)
        //{
        //    Literal2.Text = "";
        //    ExamID = long.Parse(retObj.ToString());
        //    BindDataIntoRepeater();
        //}
        //else
        //    Literal2.Text = "<b> <i> Result Not Found! </i> </b>";
        

    }
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {


    }
}