﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Windows.Forms;
public partial class Account_WAFPanel : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (!(HttpContext.Current.User.Identity.IsAuthenticated == true) && HttpContext.Current.User.IsInRole("Retailer"))
            {
                Session.Abandon();
                FormsAuthentication.SignOut();
                FormsAuthentication.RedirectToLoginPage();
            }
            else if (Roles.IsUserInRole("Admin"))
            {
                MnuAdmin.Visible = true;
                MnuAgency.Visible = false;
            }
            else if (Roles.IsUserInRole("Agency"))
            {
                MnuAdmin.Visible = false;
                MnuAgency.Visible = true;
            }
            else
            {
                MnuAdmin.Visible = false;
                MnuAgency.Visible = false;

            }

        }
    }
}
