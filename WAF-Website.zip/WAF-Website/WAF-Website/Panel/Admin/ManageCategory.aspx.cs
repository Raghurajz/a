﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Admin_ManageCategory : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadData();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if(con.State==ConnectionState.Closed)
            con.Open();
        new SqlCommand("insert into Category(CategoryName,CreatedBy) values('" + txtCategory.Text + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con).ExecuteNonQuery();
        loadData();
        con.Close();
        reset();
        ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }
    protected void reset()
    {
        txtCategory.Text = "";
    }
    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand("Select * from Category where isdeleted=0", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["CategoryTable"] = ds.Tables[0];
        
        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        
    }

    protected void gridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gridView.EditIndex = e.NewEditIndex;
        loadData();
    }
    protected void gridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string CategoryID = gridView.DataKeys[e.RowIndex].Values["CategoryID"].ToString();
        //long CategoryID = Convert.ToInt32(gridView.Rows[e.RowIndex].Cells[1].Text);
        System.Web.UI.WebControls.TextBox CategoryName = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtname");
        con.Open();
        (new SqlCommand("update Category set CategoryName='" + CategoryName.Text + "', " +
                    "ModifiedDateTime = '" + DateTime.Now.ToString("yyyy-MMM-dd HH:mm:ss") + "', " +
                    "ModifiedBy = '" + Membership.GetUser().ProviderUserKey.ToString() + "' where CategoryID=" + CategoryID, con)).ExecuteNonQuery();
        con.Close();
        lblmsg.BackColor = Color.Blue;
        lblmsg.ForeColor = Color.White;
        lblmsg.Text = CategoryName.Text + "        Updated successfully........    ";
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        
        //string name = Convert.ToString(DataBinder.Eval(gridView.Rows[e.RowIndex].DataItem, "CategoryName"));
        string CategoryID = gridView.DataKeys[e.RowIndex].Values["CategoryID"].ToString();
        if (!IsRecordExists(CategoryID))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from category where CategoryID=" + CategoryID, con);
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result == 1)
            {
                loadData();
                lblmsg.BackColor = Color.Red;
                lblmsg.ForeColor = Color.White;
                lblmsg.Text = CategoryID + "      Deleted successfully.......    ";
            }
        }
        else
        {
            lblmsg.BackColor = Color.Red;
            lblmsg.ForeColor = Color.White;
            lblmsg.Text = "Question Exist on this ID, So unable to Delete!";
        }
    }

    protected bool IsRecordExists(string id)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(*) from Question where CategoryID='" + id + "' and isdeleted=0", con);
        long x = Convert.ToInt64( cmd.ExecuteScalar().ToString());
        con.Close();
        if (x > 0)
            return true;
        else
            return false;
    }
    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string name= Convert.ToString(DataBinder.Eval(e.Row.DataItem, "CategoryName"));
            //string name = e.Row.Cells[1].Text;
            System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete"); //access the LinkButton from the TemplateField using FindControl method
            //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
            if (lnkbtnresult != null)
            {
                lnkbtnresult.Attributes.Add("onclick", "return ConfirmOnDelete('" + name + "');"); //attach the JavaScript function
            }
        }
    }
    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["CategoryTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }
    //protected void gridView_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName.Equals("AddNew"))
    //    {
    //        System.Web.UI.WebControls.TextBox inname = (System.Web.UI.WebControls.TextBox)gridView.FooterRow.FindControl("inname");
    //        con.Open();
    //        SqlCommand cmd =
    //            new SqlCommand(
    //                "insert into Category(CategoryName,CreatedBy) values('" + inname.Text + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con);
    //        int result = cmd.ExecuteNonQuery();
    //        con.Close();
    //        if (result == 1)
    //        {
    //            loadData();
    //            lblmsg.BackColor = Color.Green;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + "      Added successfully......    ";
    //        }
    //        else
    //        {
    //            lblmsg.BackColor = Color.Red;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + " Error while adding row.....";
    //        }
    //    }
    //}
}