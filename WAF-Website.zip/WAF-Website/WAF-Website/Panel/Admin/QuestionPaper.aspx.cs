﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Configuration;

public partial class Admin_QuestionPaper : System.Web.UI.Page
{
    private static int PageSize = 10;
    private static long grpID;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["id"] != null)
                grpID = Convert.ToInt64(Request["id"]);
            //BindGridView();
            DisplayWinningNumber();
            BindDummyRow();
            RefreshTopic();
        }
    }
    protected void MyButtonClick(object sender, EventArgs e)
    {


    }

    private void BindDummyRow()
    {
        DataTable dummy = new DataTable();
        dummy.Columns.Add("sno");
        dummy.Columns.Add("GroupName");
        dummy.Columns.Add("QuestionName");
        dummy.Rows.Add();
        gvQuestionPaper.DataSource = dummy;
        gvQuestionPaper.DataBind();
    }
    protected void BindGridView()
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand(@"select ROW_NUMBER() Over (Order by GroupQuestionID) As [sno],a.*,b.*,(SELECT  left(REPLACE(REPLACE(REPLACE(dbo.[udf_StripHTML](c.Question), CHAR(9), ''), CHAR(10), ''), CHAR(13), ''),35) + '...') as QuestionName, c.Answer +  ' (' + cast ( (ascii(upper(c.answer)) -64) as varchar) + ')' as Answer from QGroupQuestions a join QGroup b on a.GroupID = b.GroupID 
                     join Question c on a.QuestionID = c.QuestionID where a.GroupID='" + grpID + "' and a.isdeleted=0", conn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        
        //GridView2.DataSource = dt;
        //GridView2.DataBind();
    }

    protected void DisplayWinningNumber()
    {
        if( int.Parse(GetCount().ToString()) <=6)
        {
        long n = WAFUtility.getWinningNumber(grpID);
        if(n>0)
            Literal1.Text = "<table > <tr> <td> Winning Number :  </td> <td width='100px;' style='border: 1px solid green; display:inline-block; padding: 2px;'>  <font  size='3px' color='green'> <b> " + WAFUtility.getWinningNumber(grpID).ToString() + " </b> </font></td></tr> </table>";
        else
            Literal1.Text = "<table > <tr> <td> Winning Number :  </td> <td width='200px;' style='border: 1px solid green; display:inline-block;'>  &nbsp; </td></tr> </table>";
        }
    }


    //protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    //{
    //    SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    //    string GroupQuestionID = GridView2.DataKeys[e.RowIndex].Values["GroupQuestionID"].ToString();
    //    conn.Open();
    //    SqlCommand cmd = new SqlCommand("delete from QGroupQuestions where GroupQuestionID='" + GroupQuestionID + "'", conn);
    //    int result = cmd.ExecuteNonQuery();
    //    conn.Close();
    //    BindGridView();
    //}

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string s = GridView1.SelectedRow.Cells[1].Text;
        
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        mp1.Hide();
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "AddToGroup")
        {
            // Retrieve the row index stored in the 
            // CommandArgument property.
            bool blnIsAdd=false;
            int index = Convert.ToInt32(e.CommandArgument);

            // Retrieve the row that contains the button 
            // from the Rows collection.
            GridViewRow row = GridView1.Rows[index];
            
            Button activeButton = (Button)GridView1.Rows[index].FindControl("Button1");
            if (activeButton.Text == "Select")
            {
                activeButton.Text = "UnSelect";
                activeButton.CssClass = "btnRed";
                blnIsAdd = true;
            }
            else
            {
                activeButton.Text = "Select";
                activeButton.CssClass = "btnBlue";
                blnIsAdd = false;
            }

            Session["QuesID"] = Convert.ToInt64(GridView1.DataKeys[row.RowIndex].Values[0].ToString());
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd;

            int orderId;
            int LastorderId=0;
            int QCount = int.Parse(GetCount());
            if (QCount > 0)
                LastorderId = int.Parse((new SqlCommand("select top 1 orderid from QGroupQuestions where GroupID = '" + grpID + "' order by orderid desc", conn)).ExecuteScalar().ToString());

            orderId = LastorderId + 1;


            if (blnIsAdd)
                cmd = new SqlCommand("Insert into QGroupQuestions(GroupID, QuestionID, OrderID) values('" + grpID + "','" + Convert.ToInt64(Session["QuesID"]) + "','" + orderId + "')", conn);
            else
                cmd = new SqlCommand("Delete from QGroupQuestions where GroupID = '" + grpID + "' and QuestionID ='" + Convert.ToInt64(Session["QuesID"]) + "'", conn);
            
            cmd.ExecuteNonQuery();

            conn.Close();
            //cmd = new SqlCommand("update Question IsSelected =1 where QuestionID=" + Convert.ToInt64(Session["QuesID"]) + "')", conn);
            
            DisplayWinningNumber();
            
            //BindGridView();
            RefreshGrid();
            
        }
    }


    [WebMethod]
    public static string GetCount()
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            return (new SqlCommand("Select count(*) from QGroupQuestions where GroupID = " + grpID.ToString() + " and isDeleted=0", conn).ExecuteScalar().ToString());

        }
    }

    [WebMethod]
    public static string GetQPName()
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            return (new SqlCommand("Select GroupName from QGroup where GroupID = " + grpID.ToString() + " and isDeleted=0", conn).ExecuteScalar().ToString());

        }
    }

    [WebMethod]
    public static string GetRecordsFromQP(int pageIndex)
    {
        string query = "[GetRecordsFromQP_Pager]";
        SqlCommand cmd = new SqlCommand(query);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@PageIndex", pageIndex);
        cmd.Parameters.AddWithValue("@PageSize", PageSize);
        cmd.Parameters.AddWithValue("@GrpID", grpID);
        cmd.Parameters.Add("@RecordCount", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
        return GetData(cmd, pageIndex).GetXml();
    }

    private static DataSet GetData(SqlCommand cmd, int pageIndex)
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            using (SqlDataAdapter sda = new SqlDataAdapter())
            {
                cmd.Connection = conn;
                sda.SelectCommand = cmd;
                using (DataSet ds = new DataSet())
                {
                    sda.Fill(ds, "QuestionPaper");
                    DataTable dt = new DataTable("Pager");
                    dt.Columns.Add("PageIndex");
                    dt.Columns.Add("PageSize");
                    dt.Columns.Add("RecordCount");
                    dt.Rows.Add();
                    dt.Rows[0]["PageIndex"] = pageIndex;
                    dt.Rows[0]["PageSize"] = PageSize;
                    dt.Rows[0]["RecordCount"] = cmd.Parameters["@RecordCount"].Value;
                    ds.Tables.Add(dt);
                    return ds;
                }
            }
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType != DataControlRowType.DataRow) return;
        Button activeButton = e.Row.FindControl("Button1") as Button;
        long QuesID = long.Parse(GridView1.DataKeys[e.Row.RowIndex].Values[0].ToString());
        if (activeButton != null)
        {
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
            {
                conn.Open();
                int isExists = int.Parse((new SqlCommand("Select count(*) from QGroupQuestions where GroupID = " + grpID.ToString() + " and QuestionID = '" + QuesID.ToString()  + "' and isDeleted=0", conn).ExecuteScalar().ToString()));
                if (isExists > 0)
                {
                    activeButton.Text = "UnSelect";
                    activeButton.CssClass = "btnRed";
                }
                else
                {
                    activeButton.Text = "Select";
                    activeButton.CssClass = "btnBlue";
                }

            }
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        RefreshGrid();
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        RefreshTopic();
        
    }
    protected void RefreshTopic()
    {
        ddlTopic.Items.Clear();
        if (ddlCategory.SelectedValue == "0")
            TopicDataSource.SelectCommand = "Select a.TopicID, a.TopicName, cast( a.CategoryID as varchar) as CategoryID, b.CategoryName as CategoryName from Topic a join Category b on a.CategoryID = b.CategoryID where a.IsDeleted=0";
        else
            TopicDataSource.SelectCommand = @"Select a.TopicID, a.TopicName, cast( a.CategoryID as varchar) as CategoryID, b.CategoryName as CategoryName 
                                        from Topic a join Category b on a.CategoryID = b.CategoryID 
                                        where a.IsDeleted=0 and a.CategoryID ='" + ddlCategory.SelectedValue + "'";
        ddlTopic.DataBind();
        ddlTopic.Items.Insert(0, new ListItem("All Topics", "0"));
    }

    protected void ddlTopic_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void RefreshGrid()
    {

        if (chkShowSelection.Checked == true)
        {
            string strQuery = @"Select  ROW_NUMBER() Over (Order by a.QuestionID) As Serial,  
                            a.QuestionID as QuestionID, 
                            left(REPLACE(REPLACE(REPLACE(dbo.[udf_StripHTML](a.Question), CHAR(9), ''), CHAR(10), ''), CHAR(13), ''),35) + '...' as Question ,
                            b.CategoryName as CategoryName,c.TopicName as TopicName, 
                            a.Answer +  ' (' + cast ( (ascii(upper(a.answer)) -64) as varchar) + ')' as Answer 
                            from QGroupQuestions x join Question a on x.QuestionID=a.QuestionID join Category b on a.CategoryID = b.CategoryID join Topic c on a.TopicID=c.TopicID 
                            where x.GroupID ='" + grpID + "' order by x.OrderID";
            SqlDataSource1.SelectCommand = strQuery;
        }
        else
        {
            string strCondition = " Question LIKE '%" + txtSearchQuestion.Text + "%' ";
            if (ddlCategory.SelectedValue != "0")
                strCondition += " and a.CategoryID = '" + ddlCategory.SelectedValue + "' ";
            if (ddlTopic.SelectedValue != "0")
                strCondition += " and a.TopicID = '" + ddlTopic.SelectedValue + "' ";

            SqlDataSource1.SelectCommand = @"Select  ROW_NUMBER() Over (Order by QuestionID) As Serial,  
                        QuestionID as QuestionID, 
                        left(REPLACE(REPLACE(REPLACE(dbo.[udf_StripHTML](a.Question), CHAR(9), ''), CHAR(10), ''), CHAR(13), ''),35) + '...' as Question ,
                        b.CategoryName as CategoryName,c.TopicName as TopicName, 
                        a.Answer +  ' (' + cast ( (ascii(upper(a.answer)) -64) as varchar) + ')' as Answer 
                        from Question a join Category b on a.CategoryID = b.CategoryID join Topic c on a.TopicID=c.TopicID 
                        where a.Isdeleted=0 and a.IsSelected = 0 and "
                         + strCondition;
        }
        //Literal2.Text = SqlDataSource1.SelectCommand;
            GridView1.DataBind();
    }
    protected void btnApplyFilter_Click(object sender, EventArgs e)
    {
        RefreshGrid();
    }
    protected void chkShowSelection_CheckedChanged(object sender, EventArgs e)
    {
        RefreshGrid();

    }
}