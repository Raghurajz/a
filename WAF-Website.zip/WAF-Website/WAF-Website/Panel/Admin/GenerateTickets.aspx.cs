﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using Microsoft.Reporting.WebForms;
using AllTicketsTableAdapters;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
public partial class Panel_Admin_GenerateTickets : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
   
            PopulateExam();
            //if (Roles.GetRolesForUser().Contains("Agency"))
            //{
            //    divAllocate.Style["display"] = "none";
            //    PopulateAgency(1);
            //}
            //else
            //{
            //    PopulateAgency(0);
            //}
            DataBind();    
        }
        
        
    }
    protected void SetDefaultIndex()
    {
        if (ViewState["GT_Ex_Index"] != null)
        {
            DropDownList1.SelectedIndex = int.Parse(ViewState["GT_Ex_Index"].ToString());
        }
        else
        {
            DropDownList1.SelectedIndex = 0;
            //ViewState["GT_Ex_Index"] = 0;
            ViewState["GT_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
            ViewState["GT_Ex_Value"] = DropDownList1.SelectedValue.ToString();
            ViewState["GT_Ex_Text"] = DropDownList1.SelectedItem.Text;
        }

        //if (ViewState["GT_Ag_Index"] != null)
        //    DropDownList2.SelectedIndex = int.Parse(ViewState["GT_Ag_Index"].ToString());
        //else
        //{
        //    DropDownList2.SelectedIndex = 0;
        //    ViewState["GT_Ag_Index"] = 0;
        //}
    }
    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and examdatetime > DATEADD(mi,330,GETUTCDATE()) and isdeleted=0 order by examdatetime desc", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DropDownList1.Items.Clear();
            //DropDownList1.Items.Add(new ListItem("All","0"));
            foreach (DataRow dr in dt.Rows)
                DropDownList1.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }
//    protected void PopulateAgency(int IsAgency)
//    {
//        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
//        {
//            con.Open();
//            SqlCommand cmd;
//            if (IsAgency == 0)
//            {
//                cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
//                                                join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
//                                                join aspnet_Roles r on ur.RoleId= r.RoleId
//                                                join Member m on u.UserId = m.MemberID
//                                                where r.RoleName='Agency' ", con);
//            }
//            else
//            {
//                cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
//                                                join Member m on u.UserId = m.MemberID
//                                                where u.UserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'", con);

//            }
//            SqlDataAdapter sda = new SqlDataAdapter(cmd);
//            DataTable dt = new DataTable();
//            sda.Fill(dt);

//            DropDownList2.Items.Clear();
//            if (IsAgency == 0)
//                DropDownList2.Items.Add(new ListItem("All", "0"));
//            foreach (DataRow dr in dt.Rows)
//                DropDownList2.Items.Add(new ListItem(dr["UserName"].ToString(), dr["UserID"].ToString()));
//            con.Close();
//        }
//    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //if (DropDownList1.SelectedIndex == 0 || DropDownList2.SelectedIndex == 0 || TextBox1.Text.Trim().Length == 0)
        if (DropDownList1.SelectedIndex <0 )
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid Selection, Please Check!');", true);
            return;
        }
        DateTime AllocatedDateTime =  DateTime.UtcNow.AddMinutes(330);
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * from AllocationMaster WHERE isdeleted=0", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETS",con);
                cmdAllocate.CommandType = CommandType.StoredProcedure;
            
                SqlParameter p1 = new SqlParameter("@ExamID",SqlDbType.BigInt);
                p1.Direction = ParameterDirection.Input;
                p1.Value = long.Parse(DropDownList1.SelectedValue);

                SqlParameter p2 = new SqlParameter("@AgencyID",SqlDbType.UniqueIdentifier);
                p2.Direction = ParameterDirection.Input;
                p2.Value = new Guid(dr["AgencyUserId"].ToString());
            
                //SqlParameter p3 = new SqlParameter("@AllocatedDateTime",SqlDbType.DateTime);
                //p3.Direction = ParameterDirection.Input;
                //p3.Value = AllocatedDateTime;

                SqlParameter p3 = new SqlParameter("@AllocatedBy",SqlDbType.UniqueIdentifier);
                p3.Direction = ParameterDirection.Input;
                p3.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

                SqlParameter p4 = new SqlParameter("@TotalNonPrize", SqlDbType.BigInt);
                p4.Direction = ParameterDirection.Input;
                p4.Value = long.Parse(dr["NonPrizeAllocation"].ToString());

                SqlParameter p5 = new SqlParameter("@TotalPrize1", SqlDbType.Int);
                p5.Direction = ParameterDirection.Input;
                p5.Value = int.Parse(dr["Prize1Allocation"].ToString());

                SqlParameter p6 = new SqlParameter("@TotalPrize2", SqlDbType.Int);
                p6.Direction = ParameterDirection.Input;
                p6.Value = int.Parse(dr["Prize2Allocation"].ToString());

                SqlParameter p7 = new SqlParameter("@TotalOtherPrize", SqlDbType.BigInt);
                p7.Direction = ParameterDirection.Input;
                p7.Value = long.Parse(dr["OtherPrizeAllocation"].ToString());

                cmdAllocate.Parameters.Add(p1);
                cmdAllocate.Parameters.Add(p2);
                cmdAllocate.Parameters.Add(p3);
                cmdAllocate.Parameters.Add(p4);
                cmdAllocate.Parameters.Add(p5);
                cmdAllocate.Parameters.Add(p6);
                cmdAllocate.Parameters.Add(p7);

                cmdAllocate.ExecuteNonQuery();

            }

            BindData();
            con.Close();
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        BindData();
    }

    
    protected void BindData()
    {

        if (DropDownList1.SelectedIndex >= 0)
        {
            string strCondition = "";
            strCondition = "WHERE a.ExamID = '" + DropDownList1.SelectedValue + "'";

            //if (ViewState["GT_Ex_Value"] != null)
            //{
                //if (ViewState["GT_Ag_Value"].ToString() != "0")
                //{
                //    if (strCondition.Length > 0)
                //        strCondition = " and a.AgencyUserID = '" + ViewState["GT_Ag_Value"].ToString() + "'";
                //    else
                //        strCondition = " WHERE a.AgencyUserID = '" + ViewState["GT_Ag_Value"].ToString() + "'";
                //}
            //}

            SqlDataSource SqlDataSource1 = new SqlDataSource();
            SqlDataSource1.ID = "SqlDataSource1";

            SqlDataSource SqlDataSource2 = new SqlDataSource();
            SqlDataSource2.ID = "SqlDataSource2";

            this.Page.Controls.Add(SqlDataSource1);
            this.Page.Controls.Add(SqlDataSource2);

            SqlDataSource1.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString;
            SqlDataSource2.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString;

            /*SqlDataSource1.SelectCommand = @"SELECT a.ExamID, a.AgencyUserId, e.ExamName + ' - ' + + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName,
                                                    m.MemberName, convert(varchar, a.createddatetime,121) as createddatetime, count(*) as TotalTickets, a.CreatedBy from alltickets a
                                                    join Exam e on a.ExamID = e.ExamID
                                                    join Member m on a.AgencyUserID = m.MemberID " + strCondition +
                                                    " group by a.CreatedDateTime, a.CreatedBy,e.ExamName,e.ExamName,e.ExamDateTime,m.MemberName, a.ExamID, a.AgencyUserId  order by a.CreatedDateTime,  a.CreatedBy"; */

            SqlDataSource1.SelectCommand = @"SELECT a.AllocationID, a.ExamID, a.AgencyUserId, e.ExamName + ' - ' + + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName,
                                                m.MemberName, convert(varchar, b.AllocatedDateTime,121) as createddatetime,
                                                count(*) as TotalTickets,
                                                b.AllocatedBy from alltickets a
                                                join TicketAllocation b on a.AllocationID=b.AllocationID
                                                join Exam e on a.ExamID = e.ExamID
                                                join Member m on a.AgencyUserID = m.MemberID " + strCondition +
                                                    " group by a.AllocationID, b.AllocatedDateTime, b.AllocatedBy,e.ExamName,e.ExamName,e.ExamDateTime,m.MemberName, a.ExamID, a.AgencyUserId  order by a.AllocationID desc";

            SqlDataSource2.SelectCommand = @"SELECT a.AllocationID, a.ExamID, a.AgencyUserId, e.ExamName + ' - ' + + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName,
                                                m.MemberName, convert(varchar, b.AllocatedDateTime,121) as createddatetime, a.IsPrize as IsPrize,
                                                count(*) as TotalTickets,
                                                b.AllocatedBy from alltickets a
                                                join TicketAllocation b on a.AllocationID=b.AllocationID
                                                join Exam e on a.ExamID = e.ExamID
                                                join Member m on a.AgencyUserID = m.MemberID " + strCondition +
                                                    " group by a.AllocationID, b.AllocatedDateTime, b.AllocatedBy,e.ExamName,e.ExamName,e.ExamDateTime,m.MemberName, a.ExamID, a.AgencyUserId,a.IsPrize  order by a.AllocationID desc, a.IsPrize asc";


            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

            GridView2.DataSource = SqlDataSource2;
            GridView2.DataBind();
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        //ViewState["GT_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        //ViewState["GT_Ex_Text"] = DropDownList1.SelectedItem.Text;
        //ViewState["GT_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
    }

    //protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    ViewState["GT_Ag_Value"] = DropDownList2.SelectedValue.ToString();
    //    ViewState["GT_Ag_Text"] = DropDownList2.SelectedItem.Text;
    //    ViewState["GT_Ag_Index"] = DropDownList2.SelectedIndex.ToString();
    //}

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
            string arg;
            arg = e.CommandArgument.ToString();
            CreatePDF(arg);
        }
        else if (e.CommandName == "Delete")
        {
            //long id = (int)GridView1.DataKeys[e.RowIndex].Value;
            long arg = long.Parse(e.CommandArgument.ToString());
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DEALLOCATETICKETS", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter p1 = new SqlParameter("@AllocationID", SqlDbType.BigInt);
                p1.Direction = ParameterDirection.Input;
                p1.Value = arg;

                cmd.Parameters.Add(p1);
                cmd.ExecuteNonQuery();
                BindData();
                con.Close();
            }
        }
        
    }

    private void CreatePDF(string AllocationID)
    {
        // Setup DataSet
        AllTicketsTableAdapters.AllTicketsTableAdapter ds = new AllTicketsTableAdapters.AllTicketsTableAdapter();
        // Create Report DataSource
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        con.Open();
            /*string strQuery = @"select a.*,b.* from AllTickets a join Exam b on a.ExamId = b.ExamID where a.ExamID = '" 
                                    + ExamID + "' and a.AgencyUserId ='" + AgencyUserId
                                    + "' and a.CreatedDateTime ='" + CreatedDateTime
                                    + "' and a.CreatedBy ='" + CreatedBy + "'";*/
            string strQuery = @"select a.*,b.*,c.* from AllTickets a join Exam b on a.ExamId = b.ExamID 
                                JOIN Member c ON a.AgencyUserId = c.MemberID
                                where a.AllocationID = '"
                        + AllocationID +"'";
            Literal1.Text = strQuery;
            //string strQuery = "Select a.*,b.* from alltickets a join exam b on a.examid = b.examid where a.AgencyUserId is not null";
            SqlCommand cmd = new SqlCommand(strQuery, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet dset = new DataSet();
            da.Fill(dset);
            ReportDocument crystalReport = new ReportDocument();
            crystalReport.Load(Server.MapPath("~/Panel/Admin/WAFTicket.rpt"));
            //ReportDataSource datasource = new ReportDataSource("AllTickets", ds.Tables[0]);
            //ReportDataSource rds = new ReportDataSource("AllTickets", dset.Tables[0]);
            crystalReport.SetDataSource(dset.Tables[0]);
            CrystalReportViewer1.ReportSource = crystalReport;
            con.Close();

        ExportFormatType formatType = ExportFormatType.PortableDocFormat;
   

        crystalReport.ExportToHttpResponse(formatType, Response, true, "Crystal");
        Response.End();


        //// Variables
        //Warning[] warnings;
        //string[] streamIds;
        //string mimeType = string.Empty;
        //string encoding = string.Empty;
        //string extension = string.Empty;


        //// Setup the report viewer object and get the array of bytes
        //ReportViewer viewer = new ReportViewer();
        //viewer.ProcessingMode = ProcessingMode.Local;
        //viewer.LocalReport.ReportPath = "Panel/Admin/Tickets.rdlc";
        //viewer.LocalReport.DataSources.Add(rds); // Add datasource here

        //crystalReport.Export(
        //byte[] bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);


        //// Now that you have all the bytes representing the PDF report, buffer it and send it to the client.
        //Response.Buffer = true;
        //Response.Clear();
        //Response.ContentType = mimeType;
        //Response.AddHeader("content-disposition", "attachment; filename=check.pdf");
        //Response.BinaryWrite(bytes); // create the file
        //Response.Flush(); // send it to the client to download
    }

    //protected void GenerateReport(string ExamID, string AgencyUserId, string CreatedDateTime, string CreatedBy)
    //{
    //    Warning[] warnings;
    //    string[] streamIds;
    //    string mimeType = string.Empty;
    //    string encoding = string.Empty;
    //    string extension = string.Empty;

    //    ReportViewer1.ProcessingMode = ProcessingMode.Local;
    //    ReportViewer1.LocalReport.ReportPath = Server.MapPath("Tickets.rdlc");
    //    using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
    //    {
    //        con.Open();
    //        /*string strQuery = @"select a.*,b.* from AllTickets a join Exam b on a.ExamId = b.ExamID where a.ExamID = '" 
    //                                + ExamID + "' and a.AgencyUserId ='" + AgencyUserId
    //                                + "' and a.CreatedDateTime ='" + CreatedDateTime
    //                                + "' and a.CreatedBy ='" + CreatedBy + "'";*/
    //        string strQuery = @"select a.*,b.* from AllTickets a join Exam b on a.ExamId = b.ExamID where a.ExamID = '"
    //                    + ExamID + "' and a.AgencyUserId ='" + AgencyUserId
    //                    + "' and a.CreatedBy ='" + CreatedBy
    //                    + "' and convert(varchar,a.CreatedDateTime,121) ='" + DateTime.Parse(CreatedDateTime).ToString("yyyy-MM-dd HH:mm:ss.FFF") + "'";
    //        Literal1.Text = strQuery; 
    //        //string strQuery = "Select a.*,b.* from alltickets a join exam b on a.examid = b.examid where a.AgencyUserId is not null";
    //        SqlCommand cmd = new SqlCommand(strQuery, con);
    //        SqlDataAdapter da = new SqlDataAdapter(cmd);
    //        DataSet ds = new DataSet();
    //        da.Fill(ds);

    //        ReportDataSource datasource = new ReportDataSource("AllTickets", ds.Tables[0]);
    //        ReportViewer1.LocalReport.DataSources.Clear();
    //        ReportViewer1.LocalReport.DataSources.Add(datasource);

    //        byte[] bytes = ReportViewer1.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);


    //        // Now that you have all the bytes representing the PDF report, buffer it and send it to the client.
    //        Response.Buffer = true;
    //        Response.Clear();
    //        Response.ContentType = mimeType;
    //        Response.AddHeader("content-disposition", "attachment; filename=check.pdf");
    //        Response.BinaryWrite(bytes); // create the file
    //        Response.Flush(); // send it to the client to download
    //        con.Close();
    //    }
    //}
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
}