﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;


public partial class Admin_GroupQuestions : System.Web.UI.Page
{
    private SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["id"] != null)
                Session["GroupID"] = Convert.ToInt64(Request["id"]);
            PopulateRootLevel();
            BindGridView();
        }
    }

    private void PopulateRootLevel()
    {
        conn.Open();
        SqlCommand objCommand = new SqlCommand(@"select CategoryID as nodeid,CategoryName as nodename,(select count(*) FROM Question WHERE CategoryID=c.CategoryID) childnodecount FROM Category c where c.IsDeleted=0", conn);
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        DataTable dt = new DataTable();
        da.Fill(dt);
        conn.Close();
        PopulateNodes(dt, TreeView1.Nodes,1);
        
    }

    private void PopulateSubLevel(int parentid, TreeNode parentNode)
    {
        SqlCommand objCommand = new SqlCommand(@"select TopicID as nodeid,TopicName as nodename,(select count(*) FROM Question WHERE TopicID=t.TopicID) childnodecount FROM Topic t where t.CategoryID=@parentID and t.IsDeleted=0", conn);
        objCommand.Parameters.Add("@parentID", SqlDbType.Int).Value = parentid;
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        DataTable dt = new DataTable();
        da.Fill(dt);
        PopulateNodes(dt, parentNode.ChildNodes,2);
    }


    private void PopulateSubSubLevel(int parentid, TreeNode parentNode)
    {
        SqlCommand objCommand = new SqlCommand(@"select QuestionID as nodeid,(SELECT  ( CASE WHEN CHARINDEX(CHAR(13), [Question]) = 0
                       THEN [Question]
                       ELSE SUBSTRING([Question], 0,
                                      CHARINDEX(CHAR(13), [Question]))
                  END )) as nodename,0 as childnodecount FROM Question where TopicID=@parentID and IsDeleted=0", conn);
        objCommand.Parameters.Add("@parentID", SqlDbType.Int).Value = parentid;
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        DataTable dt = new DataTable();
        da.Fill(dt);
        PopulateNodes(dt, parentNode.ChildNodes, 3);
    }


    private void PopulateNodes(DataTable dt, TreeNodeCollection nodes,int Lvl)
    {
        foreach (DataRow dr in dt.Rows)
        {
            TreeNode tn = new TreeNode();
            if (Lvl <= 2)
                tn.Text = dr["nodename"].ToString() + "(" + dr["childnodecount"].ToString() + ")";
            else
                tn.Text = dr["nodename"].ToString();
            tn.Value = dr["nodeid"].ToString();
            nodes.Add(tn);
            if (Lvl==1)
                PopulateSubLevel(Int32.Parse(tn.Value), tn);
            else if(Lvl==2)
                PopulateSubSubLevel(Int32.Parse(tn.Value), tn);
            //If node has child nodes, then enable on-demand populating
            //tn.PopulateOnDemand = ((int)(dr["childnodecount"]) > 0);
            tn.Collapse();
        }
    }

    protected void TreeView1_TreeNodePopulate(object sender, TreeNodeEventArgs e)
    {
       // PopulateSubLevel(Int32.Parse(e.Node.Value), e.Node);
    }

    protected string ShowQuestion(object item, object serial)
    {
        if (item.ToString() == "")
            return ""; //don't create any html
        else
            return string.Format("<tr><td  style='vertical-align: top;width: 25px;'> {1}. </td><td colspan='4'> {0} </td> <br> </br> </tr>", item.ToString(), serial.ToString());

    }

    protected string ShowDirections(object item, string title, object serial)
    {
        if (item.ToString() == "")
            return ""; //don't create any html
        else
            return string.Format("<tr><td style='vertical-align: top;width: 25px;'> {2}. </td><td colspan='4' style=' border: thin solid #32CD32; border-left: #32CD32; border-left-width:thick; border-left-style:inset;background-color: #DCDCDC; padding-left: 5px;'><b> <font color='green'> {0} </font> </b> {1}<br></br></td></tr>", title, item.ToString(), serial.ToString());

    }
    protected string ShowExplanation(object item, string title)
    {
        if (item.ToString() == "")
            return ""; //don't create any html
        else
            return string.Format("<tr ><td>&nbsp;</td> <td colspan='4' > <b> <font color='green'> {0} </font> </b> <br>  </br> {1} </td> </tr>", title, item.ToString());

    }
    protected string ShowDoubleColumn(object item1, string title1, object item2, string title2)
    {
        if (item1.ToString() == "" && item2.ToString() == "")
            return ""; //don't create any html
        else if (item2.ToString() == "")
            return string.Format("<tr style=' height: 30px;'><td>&nbsp;</td><td><font color=blue> <b> {0}  </b> </font></td><td>{1}</td></tr>", title1, item1.ToString());
        else
            return string.Format("<tr style=' height: 30px;'><td>&nbsp;</td><td><font color=blue> <b> {0}  </b> </font></td><td>{1}</td><td><font color=blue> <b> {2}  </b> </font></td><td>{3}</td></tr>", title1, item1.ToString(), title2, item2.ToString());
    }

    protected DataTable GetDataFromDb(long id)
    {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select ROW_NUMBER() Over (Order by QuestionID) As [sno], * from Question where QuestionID='" + id + "' and isdeleted=0", conn);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "Question");
            DataTable dt = new DataTable();
            dt = ds.Tables["Question"];
            conn.Close();
            return dt;
    }

    protected void AddToGroup(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();
        TransferQuestion(Convert.ToInt64(Session["QuesID"]));
        SqlCommand cmd = new SqlCommand("Insert into QGroupQuestions(GroupID, QuestionID) " +
                        " values('" + Session["GroupID"].ToString() + "','" + Convert.ToInt64(Session["QuesID"]) + "')", conn);
        cmd.ExecuteNonQuery();
        BindGridView();
    }

    protected void TransferQuestion(long QuesID)
    {

                

    }


    protected void BindGridView()
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand(@"select ROW_NUMBER() Over (Order by GroupQuestionID) As [sno],a.*,b.*,(SELECT  ( CASE WHEN CHARINDEX(CHAR(13), [Question]) = 0
                       THEN [Question]
                       ELSE SUBSTRING([Question], 0,
                                      CHARINDEX(CHAR(13), [Question]))
                  END )) as QuestionName from QGroupQuestions a join QGroup b on a.GroupID = b.GroupID 
                     join Question c on a.QuestionID = c.QuestionID where a.GroupID='" + Session["GroupID"].ToString() + "' and a.isdeleted=0", conn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

    protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
    {
        Session["QuesID"] = Convert.ToInt64(TreeView1.SelectedNode.Value);
        var dt = GetDataFromDb( Convert.ToInt64(Session["QuesID"]));
        Repeater1.DataSource = dt;
        Repeater1.DataBind();
    }

    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        string GroupQuestionID = GridView1.DataKeys[e.RowIndex].Values["GroupQuestionID"].ToString();
        conn.Open();
        SqlCommand cmd = new SqlCommand("delete from QGroupQuestions where GroupQuestionID='" + GroupQuestionID + "'", conn);
        int result = cmd.ExecuteNonQuery();
        conn.Close();
        BindGridView();
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
}