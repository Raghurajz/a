﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Admin_ManageTopic : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    static bool IsFiltered;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCategory();
            IsFiltered = false; 
            loadData();
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        IsFiltered = false;
        loadData();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        IsFiltered = true;
        loadData();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        new SqlCommand("insert into Topic(TopicName,CategoryID,CreatedBy) values('" + txtTopicName.Text + "','" + ddlCategory.SelectedValue + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con).ExecuteNonQuery();
        IsFiltered = false; 
        loadData();
        con.Close();
        ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }
    protected void BindCategory()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        //DropDownList ddlCategory = (DropDownList)gridView.HeaderRow.FindControl("ddlCategory");
        SqlCommand cmd = new SqlCommand("select CategoryID, CategoryName from Category where isDeleted=0", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        ddlCategory.DataSource = ds;
        ddlCategory.DataTextField = "CategoryName";
        ddlCategory.DataValueField = "CategoryID";
        ddlCategory.DataBind();
        //ddlCategory.Items.Insert(0, new ListItem("--Select--", "0"));
        //ddlCategory.SelectedIndex = 0;


    }
    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd;
        if(IsFiltered)
            cmd = new SqlCommand("Select a.TopicID, a.TopicName, a.CategoryID,b.CategoryName from Topic a join Category b on a.CategoryID= b.CategoryID where a.CategoryID='" + ddlCategory.SelectedValue + "' and a.isdeleted=0", con);
        else
            cmd = new SqlCommand("Select a.TopicID, a.TopicName, a.CategoryID,b.CategoryName from Topic a join Category b on a.CategoryID= b.CategoryID where a.isdeleted=0", con);
        
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["TopicTable"] = ds.Tables[0];
        
        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        
    }

    protected void gridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gridView.EditIndex = e.NewEditIndex;
        loadData();
    }
    protected void gridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string TopicID = gridView.DataKeys[e.RowIndex].Values["TopicID"].ToString();
        //long TopicID = Convert.ToInt32(gridView.Rows[e.RowIndex].Cells[1].Text);
        System.Web.UI.WebControls.TextBox TopicName = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtname");
        DropDownList ddlCategoryEdit = (DropDownList)gridView.Rows[e.RowIndex].FindControl("ddlCategoryEdit");
        con.Open();
        (new SqlCommand("update Topic set TopicName='" + TopicName.Text + "', " +
                    "CategoryID = '" + ddlCategoryEdit.SelectedValue.ToString() + "', " +
                    "ModifiedDateTime = '" + DateTime.Now.ToString("yyyy-MMM-dd HH:mm:ss") + "', " +
                    "ModifiedBy = '" + Membership.GetUser().ProviderUserKey.ToString() + "' where TopicID=" + TopicID, con)).ExecuteNonQuery();
        con.Close();
        lblmsg.BackColor = Color.Blue;
        lblmsg.ForeColor = Color.White;
        lblmsg.Text = TopicName.Text + "        Updated successfully........    ";
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string TopicID = gridView.DataKeys[e.RowIndex].Values["TopicID"].ToString();
        if (!IsRecordExists(TopicID))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from topic where TopicID=" + TopicID, con);
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result == 1)
            {
                loadData();
                lblmsg.BackColor = Color.Red;
                lblmsg.ForeColor = Color.White;
                lblmsg.Text = TopicID + "      Deleted successfully.......    ";
            }
        }
        else
        {
            lblmsg.BackColor = Color.Red;
            lblmsg.ForeColor = Color.White;
            lblmsg.Text = "Question Exist on this ID, So unable to Delete!";
        }
    }

    protected bool IsRecordExists(string id)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(*) from Question where TopicID='" + id + "' and isdeleted=0", con);
        long x = Convert.ToInt64(cmd.ExecuteScalar().ToString());
        con.Close();
        if (x > 0)
            return true;
        else
            return false;
    }
    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string name = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "TopicName"));
            System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete");
            //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
            if (lnkbtnresult != null)
            {
                lnkbtnresult.Attributes.Add("onclick", "javascript:return deleteConfirm('" + name + "')");
            }
        }

        if (e.Row.RowType == DataControlRowType.DataRow && gridView.EditIndex == e.Row.RowIndex)
        {

            con.Open();
            DropDownList ddlCategoryEdit = (DropDownList)e.Row.FindControl("ddlCategoryEdit");
            HiddenField hdnCategory = (HiddenField)e.Row.FindControl("hdnCategory");
            SqlCommand cmd = new SqlCommand("select CategoryID, CategoryName from Category where isDeleted=0",con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlCategoryEdit.DataSource = ds;
            ddlCategoryEdit.DataTextField = "CategoryName";
            ddlCategoryEdit.DataValueField = "CategoryID";
            ddlCategoryEdit.DataBind();
            //ddlCategoryEdit.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCategoryEdit.Items.FindByValue(hdnCategory.Value).Selected = true;
            con.Close();
        }
    }
    //protected void gridView_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName.Equals("AddNew"))
    //    {
    //        System.Web.UI.WebControls.TextBox inname = (System.Web.UI.WebControls.TextBox)gridView.HeaderRow.FindControl("inname");
    //        DropDownList ddlCategory = (DropDownList)gridView.HeaderRow.FindControl("ddlCategory");
    //        con.Open();
    //        SqlCommand cmd =
    //            new SqlCommand(
    //                "insert into Topic(TopicName,CategoryID,CreatedBy) values('" + inname.Text + "','" + ddlCategory.SelectedValue + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con);
    //        int result = cmd.ExecuteNonQuery();
    //        con.Close();
    //        if (result == 1)
    //        {
    //            loadData();
    //            lblmsg.BackColor = Color.Green;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + "      Added successfully......    ";
    //        }
    //        else
    //        {
    //            lblmsg.BackColor = Color.Red;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + " Error while adding row.....";
    //        }
    //    }
    //}

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["TopicTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }
    
}   