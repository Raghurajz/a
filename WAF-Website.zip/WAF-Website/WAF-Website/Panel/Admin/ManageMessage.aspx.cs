﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_ManageMessage : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        new SqlCommand("update ManageMessage SET MessageText ='" + txtMessage.Text +  "'", con).ExecuteNonQuery();
        //new SqlCommand("insert into ManageMessage(MessageText,CreatedBy) values('" + txtMessage.Text + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con).ExecuteNonQuery();
        con.Close();
        reset();
        ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Updated');", true);
    }
    protected void reset()
    {
        txtMessage.Text = "";
    }
}