﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Panel_Admin_GeneratePrize : System.Web.UI.Page
{
    protected long ExamID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            PopulateExam();
        
    }

    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and examdatetime > DATEADD(mi,330,GETUTCDATE()) and isdeleted=0 order by examdatetime desc", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DropDownList1.Items.Clear();
            //DropDownList1.Items.Add(new ListItem("All","0"));
            foreach (DataRow dr in dt.Rows)
                DropDownList1.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }

    protected void SetDefaultIndex()
    {
        if (ViewState["GP_Ex_Index"] != null)
        {
            DropDownList1.SelectedIndex = int.Parse(ViewState["GP_Ex_Index"].ToString());

        }
        else
        {
            DropDownList1.SelectedIndex = 0;
            ViewState["GP_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
            ViewState["GP_Ex_Text"] = DropDownList1.SelectedItem.Text;
            ViewState["GP_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Literal1.Text = "";
        //ViewState["GP_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        //ViewState["GP_Ex_Text"] = DropDownList1.SelectedItem.Text;
        //ViewState["GP_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
    }


    List<string> GenerateSequences(long n, int r)
    {
        List<string> retList = new List<string>();
        int length = n.ToString().Length;
        for (int i = 0; i <= length - r; i++)
            retList.Add(n.ToString().Substring(i, r) + "," + (i + 1).ToString() + "," + r.ToString());
        return retList;
    }

    protected long getWinningNumber()
    {
        //ExamID = long.Parse(DropDownList1.SelectedValue.ToString());
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            long GroupID = long.Parse(new SqlCommand("Select GroupID from exam where examid = '" + DropDownList1.SelectedValue + "'", con).ExecuteScalar().ToString());
                long retValue =  WAFUtility.getWinningNumber(GroupID);
            con.Close();
            return retValue;
        }
    }

    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex < 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid Selection, Please Check!');", true);
            return;
        }
        try
        {
        System.Threading.Thread.Sleep(1000);
        Literal1.Text = "Please wait while processing...";
        btnGenerate.Enabled = false;
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        con.Open();

        long WinningNumber = getWinningNumber();
        new SqlCommand("delete from prizedetails where examid='" + DropDownList1.SelectedValue + "'", con).ExecuteNonQuery();
        for (int i = 6; i >= 2; i--)
        {
            List<string> result = GenerateSequences(WinningNumber, i);
            foreach (string itm in result)
            {
                string[] arr = itm.Split(',');
                new SqlCommand(@"insert into prizedetails(WinningNumber, Prize, MatchingNumber,
StartPosition, StringLength, TicketNumber,
ExamID) select '" + WinningNumber + "' as WinningNumber,'" + (7 - i).ToString() + "' as Prize,'" + arr[0] + "' as MatchingNumber, '" + arr[1] + "' as StartPosition, '" + arr[2] + "' as StringLength, TicketNumber,'" + DropDownList1.SelectedValue + "' from alltickets where SUBSTRING(ticketnumber," + int.Parse(arr[1]) + "," + int.Parse(arr[2]) + ")='" + arr[0] + "'", con).ExecuteNonQuery();
            }
        }

        // The Same Ticket will fall under 2 or 3 different prize, the below keeps the top prizes and removes other prizes
        new SqlCommand(@"DELETE FROM PrizeDetails WHERE AutoID IN (
                                                SELECT AutoID FROM (
                                                    SELECT 
                                                        AutoID
                                                        ,ROW_NUMBER() OVER (PARTITION BY TicketNumber ORDER BY AutoID) AS Ticket
                                                    FROM PrizeDetails WHERE EXAMID = '" + DropDownList1.SelectedValue + @"') a WHERE Ticket > 1 
                                            )", con).ExecuteNonQuery();

        //update prize tickets in alltickets
        /*new SqlCommand(@"update AllTickets SET IsPrize =1  WHERE ticketnumber in 
                        ( SELECT a.ticketnumber from AllTickets a join PrizeDetails b on a.ExamID = b.ExamID and a.TicketNumber = b.TicketNumber ) 
                        and examid='" + ExamID + "'", con).ExecuteNonQuery();*/

        new SqlCommand(@"UPDATE a SET a.IsPrize = b.Prize, IsExamAttended=1 FROM AllTickets a 
                            JOIN PrizeDetails b ON a.TicketNumber = b.TicketNumber 
                            WHERE a.ExamID='" + DropDownList1.SelectedValue + "'and b.ExamID ='" + DropDownList1.SelectedValue + "'", con).ExecuteNonQuery();

        new SqlCommand(@"UPDATE AllTickets SET IsExamAttended = 1 WHERE TicketNumber IN
                        (
	                        select * from (	SELECT TOP (" + GetNonPrizeAttended() + ") TicketNumber from AllTickets WHERE ExamID = '" + DropDownList1.SelectedValue + @"' AND IsExamAttended=0 ORDER BY NEWID()  ) a
                        ) AND ExamID = '" + DropDownList1.SelectedValue + "'", con).ExecuteNonQuery();
        
        btnGenerate.Enabled = true;
        Literal1.Text = "Process completed successfully!";
        }
        catch (Exception ex)
        {
            Literal1.Text = ex.Message.ToString();
            btnGenerate.Enabled = true;
        }
    }

    protected int GetNonPrizeAttended()
    {
        Random rnd = new Random();
        return rnd.Next(50176, 100352);

    }
}