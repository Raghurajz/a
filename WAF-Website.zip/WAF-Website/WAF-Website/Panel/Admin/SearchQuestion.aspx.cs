﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Configuration;
public partial class Panel_Admin_SearchQuestion : System.Web.UI.Page
{
    private static int PageSize = 10;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            RefreshTopic();
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Remove")
        {
            // Retrieve the row index stored in the 
            // CommandArgument property.
            int index = Convert.ToInt32(e.CommandArgument);

            // Retrieve the row that contains the button 
            // from the Rows collection.
            GridViewRow row = GridView1.Rows[index];

            Session["QuesID"] = Convert.ToInt64(GridView1.DataKeys[row.RowIndex].Values[0].ToString());
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand("delete from Question where QuestionID ='" + Convert.ToInt64(Session["QuesID"]) + "'", conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            //BindGridView();
            RefreshGrid();

        }
    }


   
    
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        RefreshGrid();
    }
    protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        RefreshTopic();

    }
    protected void RefreshTopic()
    {
        ddlTopic.Items.Clear();
        if (ddlCategory.SelectedValue == "0")
            TopicDataSource.SelectCommand = "Select a.TopicID, a.TopicName, cast( a.CategoryID as varchar) as CategoryID, b.CategoryName as CategoryName from Topic a join Category b on a.CategoryID = b.CategoryID where a.IsDeleted=0";
        else
            TopicDataSource.SelectCommand = @"Select a.TopicID, a.TopicName, cast( a.CategoryID as varchar) as CategoryID, b.CategoryName as CategoryName 
                                        from Topic a join Category b on a.CategoryID = b.CategoryID 
                                        where a.IsDeleted=0 and a.CategoryID ='" + ddlCategory.SelectedValue + "'";
        ddlTopic.DataBind();
        ddlTopic.Items.Insert(0, new ListItem("All Topics", "0"));
    }

    protected void ddlTopic_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void RefreshGrid()
    {

        string strCondition = " Question LIKE '%" + txtSearchQuestion.Text + "%' ";
        if (ddlCategory.SelectedValue != "0")
            strCondition += " and a.CategoryID = '" + ddlCategory.SelectedValue + "' ";
        if (ddlTopic.SelectedValue != "0")
            strCondition += " and a.TopicID = '" + ddlTopic.SelectedValue + "' ";

        SqlDataSource1.SelectCommand = @"Select  ROW_NUMBER() Over (Order by QuestionID) As Serial,  
                    QuestionID as QuestionID, 
                    left(REPLACE(REPLACE(REPLACE(dbo.[udf_StripHTML](a.Question), CHAR(9), ''), CHAR(10), ''), CHAR(13), ''),35) + '...' as Question ,
                    b.CategoryName as CategoryName,c.TopicName as TopicName, 
                    a.Answer +  ' (' + cast ( (ascii(upper(a.answer)) -64) as varchar) + ')' as Answer 
                    from Question a join Category b on a.CategoryID = b.CategoryID join Topic c on a.TopicID=c.TopicID 
                    where a.Isdeleted=0 and a.IsSelected = 0 and "
                        + strCondition;
        //Literal2.Text = SqlDataSource1.SelectCommand;
        GridView1.DataBind();
    }
    protected void btnApplyFilter_Click(object sender, EventArgs e)
    {
        RefreshGrid();
    }

}