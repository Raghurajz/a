﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class ConductExam : System.Web.UI.Page
{
    private static SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    static DataTable dt;
    static int intCounter = 0;
    static ExamResult curExamResult;
    static List<QuestionDetail> QuestionDetails;
    static int ansCount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            mp1.Show();
            ClientScript.RegisterStartupScript(GetType(), "Javascript", "javascript:StartDur(" + Request["ExamID"].ToString() +"); ", true);
        }

    }
    protected static void getData(string id)
    {
        conn.Open();
        SqlCommand objCommand = new SqlCommand(@"select d.*,a.ExamName from Exam a join QGroup b on a.GroupID=b.GroupID join QGroupQuestions c on b.GroupID=c.GroupID join Question d on d.QuestionID=c.QuestionID where a.ExamID='" + id + "'", conn);
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        dt = new DataTable();
        da.Fill(dt);
        conn.Close();
    }

    protected static string TrimAll(string str)
    {
        string replaceWith = "";
        return str.Replace("\r\n", replaceWith).Replace("\n", replaceWith).Replace("\r", replaceWith).Replace("<br>", replaceWith).Replace("<p>", "<br>").Replace("</p>", replaceWith);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        mp1.Hide();
        Response.Redirect("ModalExam1.aspx");
    }

    public class ExamResult
    {
        public long ExamID { get; set; }
        public int QuestionsAnswered { get; set; }
        public int QuestionsAnsweredRight { get; set; }
        public int QuestionsAnsweredWrong { get; set; }
        public int TotalMarks { get; set; }
        public float Percentage { get; set; }
    }

    public class QuestionDetail
    {
        public long QuestionID { get; set; }
        public string DirectionsToSolve { get; set; }
        public string Question { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string OptionE { get; set; }
        public string OptionF { get; set; }
        public string CorrectAnswer { get; set; }
        public string Answered { get; set; }
        public int Result { get; set; }
        public int IsDirectionToSolve { get; set; }
        public int OptionCount { get; set; }
        public int IsImage { get; set; }
        public int Duration { get; set; }
        public int Total { get; set; }
        public string ExamName { get; set; }
    }

    [System.Web.Services.WebMethod]
    public static int StartExam(string id)
    {
        getData(id);
        intCounter = 0;
        ansCount = 0;
        curExamResult = new ExamResult();
        curExamResult.ExamID = long.Parse(id);
        curExamResult.QuestionsAnswered = dt.Rows.Count;
        QuestionDetails = new List<QuestionDetail>();
        return dt.Rows.Count;
    }

    [System.Web.Services.WebMethod]
    public static int UpdateAnswer(string ans)
    {
        //if (ansCount == 1)
        //    QuestionDetails[ansCount].Answered = ans;
        long x;
        if (ansCount == dt.Rows.Count - 1)
            x = 1;
        QuestionDetails[ansCount].Answered = ans;
        if (QuestionDetails[ansCount].CorrectAnswer == QuestionDetails[ansCount].Answered)
        {
            QuestionDetails[ansCount].Result = 1;
            curExamResult.QuestionsAnsweredRight++;
            curExamResult.TotalMarks++;
        }
        else
        {
            QuestionDetails[ansCount].Result = 0;
            curExamResult.QuestionsAnsweredWrong++;
        }
        curExamResult.Percentage = (100 * curExamResult.QuestionsAnsweredRight) / curExamResult.QuestionsAnswered;
        if (ansCount == dt.Rows.Count - 1)
            return 1;
        else
        {
            ansCount++;
            return 0;
        }
    }

    [System.Web.Services.WebMethod]
    public static ExamResult GetCurrentResult()
    {
        return curExamResult;
        //string sqlQry = "";
        //long newID = 0;
        //SqlCommand cmd;
        //conn.Open();
        //SqlTransaction trans = conn.BeginTransaction();
        //try
        //{
        //    sqlQry = @"insert into examresult(ExamID, UserID, QuestionsAnswered, QuestionsAnsweredRight, QuestionsAnsweredWrong, TotalMarks, Percentage, CreatedBy) values('" + curExamResult.ExamID.ToString() + "','" +
        //                        Membership.GetUser().ProviderUserKey.ToString() + "','" +
        //                        curExamResult.QuestionsAnswered.ToString() + "','" + curExamResult.QuestionsAnsweredRight.ToString() + "','" +
        //                        curExamResult.QuestionsAnsweredWrong.ToString() + "','" + curExamResult.TotalMarks.ToString() + "','" +
        //                        curExamResult.Percentage.ToString() + "','" + Membership.GetUser().ProviderUserKey.ToString() + "');SELECT SCOPE_IDENTITY();";
        //    cmd = new SqlCommand(sqlQry, conn);
        //    cmd.Transaction = trans;
        //    newID = long.Parse(cmd.ExecuteScalar().ToString());
        //    foreach (QuestionDetail Q in QuestionDetails)
        //    {
        //        sqlQry = @"insert into examresultdetails(ExamResultID, QuestionID, CorrectAnswer, Answered, Result, CreatedBy) values('" + newID.ToString() + "','" +
        //                Q.QuestionID.ToString() + "','" +
        //                Q.CorrectAnswer.ToString() + "','" + Q.Answered.ToString() + "','" +
        //                Q.Result.ToString() + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')";
        //        cmd = new SqlCommand(sqlQry, conn);
        //        cmd.Transaction = trans;
        //        cmd.ExecuteNonQuery();
        //    }
        //    trans.Commit();
        //    if (conn.State == ConnectionState.Open) conn.Close();
        //    return curExamResult;
        //}
        //catch (Exception e)
        //{

        //    trans.Rollback();
        //    if (conn.State == ConnectionState.Open) conn.Close();
        //    return null;
        //}

    }

    [System.Web.Services.WebMethod]
    public static QuestionDetail GetCurrentQuestion()
    {
        long QuesID;
        QuestionDetail curQuestionDetail = new QuestionDetail();
        DataRow dr = dt.Rows[intCounter];
        curQuestionDetail.OptionCount = 0;

        curQuestionDetail.ExamName = dr["ExamName"].ToString();
        QuesID = long.Parse(dr["QuestionID"].ToString());
        curQuestionDetail.QuestionID = QuesID;
        //DirectionToSolve
        if (!TrimAll(dr["DirectionsToSolve"].ToString()).Equals(""))
        {
            curQuestionDetail.DirectionsToSolve = "<tr> <td colspan='2' style=' background-color:#F5FFFA; border: 1px; border-color: black;' > <font color='black' size='2px'> <b> <u> Directions To Solve </u> </b>" + TrimAll(dr["DirectionsToSolve"].ToString()) + "  </font></td></tr>";
            curQuestionDetail.IsDirectionToSolve = 1;
        }
        else
            curQuestionDetail.IsDirectionToSolve = 0;

        //Image
        if (int.Parse(dr["IsImage"].ToString()) == 1)
            curQuestionDetail.IsImage = 1;
        else
            curQuestionDetail.IsImage = 0;

        //Question
        curQuestionDetail.Question = "<tr> <td colspan='2'>  <font color='#00008B' size='3.5px'> <b>" + dr["Question"].ToString() + " </b> </font></td></tr>";
        //Options
        if (!TrimAll(dr["OptionA"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionA = "<tr> <td> <b> <i> <font color='#00008B' size='3.5px'> A. &nbsp;&nbsp;  " + TrimAll(dr["OptionA"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionB"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionB = "<td> <b> <i> <font color='#00008B' size='3.5px'> B. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionB"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionB = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionC"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionC = "<tr> <td> <b> <i> <font color='#00008B' size='3.5px'> C. &nbsp;&nbsp;  " + TrimAll(dr["OptionC"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionD"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionD = "<td> <b> <i> <font color='#00008B' size='3.5px'> D. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionD"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionD = "<td> &nbsp; </td></tr>";
        }

        if (!TrimAll(dr["OptionE"].ToString()).Equals(""))
        {
            curQuestionDetail.OptionE = "<tr> <td> <b> <i> <font color='#00008B' size='3.5px'> E. &nbsp;&nbsp;  " + TrimAll(dr["OptionE"].ToString()) + "</b>  </i> </font></td>";
            curQuestionDetail.OptionCount++;
            if (!TrimAll(dr["OptionF"].ToString()).Equals(""))
            {
                curQuestionDetail.OptionF = "<td> <b> <i> <font color='#00008B' size='3.5px'> F. &nbsp;&nbsp;  <b> <i>" + TrimAll(dr["OptionF"].ToString()) + "</b> </i> </font></td></tr>";
                curQuestionDetail.OptionCount++;
            }
            else
                curQuestionDetail.OptionF = "<td> &nbsp; </td></tr>";
        }
        curQuestionDetail.Duration = int.Parse(dr["Duration"].ToString());
        curQuestionDetail.CorrectAnswer = dr["Answer"].ToString();
        intCounter++;
        QuestionDetails.Add(curQuestionDetail);
        return curQuestionDetail;
    }

}