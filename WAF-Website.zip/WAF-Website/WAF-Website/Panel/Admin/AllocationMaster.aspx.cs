﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_AllocationMaster : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    long Prize1Total = 0;
    long Prize2Total = 0;
    long OtherPrizeTotal = 0;
    long NonPrizeTotal = 0;
    long GrandTotal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Reset();
            loadData();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        if (con.State == ConnectionState.Closed)
            con.Open();
        new SqlCommand(@"insert into AllocationMaster(AgencyUserId, NonPrizeAllocation, Prize1Allocation, Prize2Allocation, OtherPrizeAllocation) 
                            values('" + ddlAgency.SelectedValue + "','" + txtNonPrize.Text + "','" + txtPrize1.Text
                            + "','" + txtPrize2.Text
                            + "','" + txtOtherPrize.Text
                            + "')", con).ExecuteNonQuery();
        loadData();
        Reset();
        con.Close();
        ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }

    protected void BindAgency()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
                                                    join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
                                                    join aspnet_Roles r on ur.RoleId= r.RoleId
                                                    join Member m on u.UserId = m.MemberID
                                                    where r.RoleName='Agency' AND u.UserId NOT IN (SELECT AgencyUserId from AllocationMaster)", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);


            ddlAgency.DataSource = ds;
            ddlAgency.DataTextField = "UserName";
            ddlAgency.DataValueField = "UserID";
            ddlAgency.DataBind();
            con.Close();
        }
    }
 
    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand(@"Select a.AutoID, a.AgencyUserId, m.MemberName  as AgencyName, a.NonPrizeAllocation, a.Prize1Allocation, a.Prize2Allocation,a.OtherPrizeAllocation,
                                            (a.NonPrizeAllocation+a.Prize1Allocation+a.Prize2Allocation+a.OtherPrizeAllocation) as Total  
                                            from AllocationMaster a join Member m on a.AgencyUserId= m.MemberID where a.isdeleted=0", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["AllocationTable"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        BindAgency();
    }

    protected void gridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gridView.EditIndex = e.NewEditIndex;
        loadData();
    }
    protected void gridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        lblmsg.Text = "";
        string AutoID = gridView.DataKeys[e.RowIndex].Values["AutoID"].ToString();
        DropDownList ddlAgencyEdit = (DropDownList)gridView.Rows[e.RowIndex].FindControl("ddlAgencyEdit");

        System.Web.UI.WebControls.TextBox NonPrizeAllocation = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtNonPrizeAllocation");
        System.Web.UI.WebControls.TextBox Prize1Allocation = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtPrize1Allocation");
        System.Web.UI.WebControls.TextBox Prize2Allocation = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtPrize2Allocation");
        System.Web.UI.WebControls.TextBox OtherPrizeAllocation = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtOtherPrizeAllocation");


        con.Open();

        SqlCommand cmd = new SqlCommand("update AllocationMaster set NonPrizeAllocation='" + NonPrizeAllocation.Text + "', " +
                    "Prize1Allocation = '" + Prize1Allocation.Text + "', " +
                    "Prize2Allocation = '" + Prize2Allocation.Text + "', " +
                    "OtherPrizeAllocation = '" + OtherPrizeAllocation.Text + "' where AutoID=" + AutoID, con);
        cmd.ExecuteNonQuery();
        con.Close();
        lblmsg.BackColor = Color.Blue;
        lblmsg.ForeColor = Color.White;
        lblmsg.Text = "Updated successfully...";
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblmsg.Text = "";
        string AutoID = gridView.DataKeys[e.RowIndex].Values["AutoID"].ToString();
        //if (!IsRecordExists(ExamID))
        //{
        con.Open();
        SqlCommand cmd = new SqlCommand("delete from AllocationMaster where AutoID=" + AutoID, con);
        int result = cmd.ExecuteNonQuery();
        con.Close();
        if (result == 1)
        {
            loadData();
            lblmsg.BackColor = Color.Red;
            lblmsg.ForeColor = Color.White;
            lblmsg.Text = "Deleted successfully...";
        }
        //}
        //else
        //{
        //    lblmsg.BackColor = Color.Red;
        //    lblmsg.ForeColor = Color.White;
        //    lblmsg.Text = "Exam Result Exist on this ID, So unable to Delete!";
        //}
    }

   protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string name = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "AgencyName"));
            System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete");
            //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
            if (lnkbtnresult != null)
            {
                lnkbtnresult.Attributes.Add("onclick", "javascript:return deleteConfirm('" + name + "')");
            }

            if (DataBinder.Eval(e.Row.DataItem, "Prize1Allocation") != DBNull.Value)
                Prize1Total += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Prize1Allocation"));
            if (DataBinder.Eval(e.Row.DataItem, "Prize2Allocation") != DBNull.Value)
                Prize2Total += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Prize2Allocation"));
            if (DataBinder.Eval(e.Row.DataItem, "OtherPrizeAllocation") != DBNull.Value)
                OtherPrizeTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "OtherPrizeAllocation"));
            if (DataBinder.Eval(e.Row.DataItem, "NonPrizeAllocation") != DBNull.Value)
                NonPrizeTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "NonPrizeAllocation"));
            if (DataBinder.Eval(e.Row.DataItem, "Total") != DBNull.Value)
                GrandTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Total"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblPrize1Total = (Label)e.Row.FindControl("lblPrize1Total");
            lblPrize1Total.Text = Prize1Total.ToString();
            Label lblPrize2Total = (Label)e.Row.FindControl("lblPrize2Total");
            lblPrize2Total.Text = Prize2Total.ToString();
            Label lblOtherPrizeTotal = (Label)e.Row.FindControl("lblOtherPrizeTotal");
            lblOtherPrizeTotal.Text = OtherPrizeTotal.ToString();
            Label lblNonPrizeTotal = (Label)e.Row.FindControl("lblNonPrizeTotal");
            lblNonPrizeTotal.Text = NonPrizeTotal.ToString();
            Label lblGrandTotal = (Label)e.Row.FindControl("lblGrandTotal");
            lblGrandTotal.Text = GrandTotal.ToString();
        }

        //if (e.Row.RowType == DataControlRowType.DataRow && gridView.EditIndex == e.Row.RowIndex)
        //{

        //    con.Open();
        //    DropDownList ddlAgencyEdit = (DropDownList)e.Row.FindControl("ddlAgencyEdit");
        //    HiddenField hdnAgency = (HiddenField)e.Row.FindControl("hdnAgency");
        //    SqlCommand cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
        //                                            join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
        //                                            join aspnet_Roles r on ur.RoleId= r.RoleId
        //                                            join Member m on u.UserId = m.MemberID
        //                                            where r.RoleName='Agency' ", con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    ddlAgencyEdit.DataSource = ds;
        //    ddlAgencyEdit.DataTextField = "UserName";
        //    ddlAgencyEdit.DataValueField = "UserID";
        //    ddlAgencyEdit.DataBind();
        //    ddlAgencyEdit.Items.FindByValue(hdnAgency.Value).Selected = true;
        //    con.Close();
        //}


    }
    

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["AllocationTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void Reset()
    {
        txtNonPrize.Text = "";
        txtPrize1.Text = "";
        txtPrize2.Text = "";
        txtOtherPrize.Text = "";
        if(ddlAgency.Items.Count >0)
            ddlAgency.SelectedIndex = 0;
        lblmsg.Text = "";
    }

}