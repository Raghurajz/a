using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class _Default : System.Web.UI.Page
{
    static bool alert;


 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (alert == true)
        {
            Page.ClientScript.RegisterClientScriptBlock(GetType(), "Success", "alert('Successfully Updated')", true);
            alert = false;
        }

        //ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Updated');", true);
        if (!IsPostBack)
        {
            Session["pic"] = new byte[0];
            if (Request["id"] != null)
            {
                Session["QuestionIsEditMode"] = "true";
                Session["QuesID"] = long.Parse(Request["id"].ToString());
                DisplayData();
            }
            else
            {
                Session["QuestionIsEditMode"] = "false";
            }
        }

    }
    protected void DisplayData()
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("select * from question where QuestionID='" + Session["QuesID"].ToString() + "'", conn);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        DirectionsToSolveLtrl.Text = ds.Tables[0].Rows[0]["directionstosolve"].ToString();
        QuestionLtrl.Text = ds.Tables[0].Rows[0]["question"].ToString();
        if ( ds.Tables[0].Rows[0]["Image"] !=DBNull.Value )
        {
            Session["pic"] = ((byte[])ds.Tables[0].Rows[0]["Image"]);
            //if ( ( (byte[])Session["pic"]).Length > 0)
            //{
            
            string base64String = Convert.ToBase64String((byte[])Session["pic"]);
            string st = String.Format("<img src=data:image/jpg;base64,{0} width=150px/>", base64String);
            ClientScript.RegisterStartupScript(this.GetType(), "ReadImage", "readImage('" + st + "');", true);
        }
        optALtrl.Text = ds.Tables[0].Rows[0]["OptionA"].ToString();
        optBLtrl.Text = ds.Tables[0].Rows[0]["OptionB"].ToString();
        optCLtrl.Text = ds.Tables[0].Rows[0]["OptionC"].ToString();
        optDLtrl.Text = ds.Tables[0].Rows[0]["OptionD"].ToString();
        optELtrl.Text = ds.Tables[0].Rows[0]["OptionE"].ToString();
        optFLtrl.Text = ds.Tables[0].Rows[0]["OptionF"].ToString();
        optGLtrl.Text = ds.Tables[0].Rows[0]["OptionG"].ToString();
        optHLtrl.Text = ds.Tables[0].Rows[0]["OptionH"].ToString();
        optILtrl.Text = ds.Tables[0].Rows[0]["OptionI"].ToString();

        ansLtrl.Text = ds.Tables[0].Rows[0]["Answer"].ToString();
        expLtrl.Text = ds.Tables[0].Rows[0]["Explanation"].ToString();
        txtDuration.Text = ds.Tables[0].Rows[0]["Duration"].ToString();
        string CategoryID = ds.Tables[0].Rows[0]["CategoryID"].ToString();
        string CategoryName = SetComboBox("Category", "CategoryName", "CategoryID", long.Parse(CategoryID));
        ClientScript.RegisterStartupScript(this.GetType(), "SetCategory", "SetCategory('" + CategoryName + "','" + CategoryID + "');", true);
        string TopicID = ds.Tables[0].Rows[0]["TopicID"].ToString();
        string TopicName = SetComboBox("Topic", "TopicName", "TopicID", long.Parse(TopicID));
        ClientScript.RegisterStartupScript(this.GetType(), "SetTopic", "SetTopic('" + TopicName + "','" + TopicID + "');", true);
        ClientScript.RegisterStartupScript(this.GetType(), "SetHiddenValues", "SetHiddenValues('" + CategoryID + "','" + TopicID + "');", true);
        conn.Close();
    }


    protected string SetComboBox(string tablename, string namefield, string idfield, long id)
    {

        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select " + namefield + " from " + tablename + " where " + idfield + " = '" + id + "' and isdeleted=0",conn);
            string nm = cmd.ExecuteScalar().ToString();
            return nm;
        }
    }

    protected bool CheckMandatory(string value, HtmlGenericControl  ValidationControl)
    {

        if (value.Trim() == "")
        {
            ValidationControl.InnerHtml = "* <i> (field is mandatory </i>)";
            return false;
        }
        else
            return true;
    }

    //protected void Save()
    //{
    //    Session["editor1"] = Request.Form["editor1"].ToString();
    //    Session["editor2"] = Request.Form["editor2"].ToString();
    //    Session["optAEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optBEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optCEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optDEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optEEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optFEditor"] = Request.Form["optAEditor"].ToString();
    //    Session["optBAEditor"] = Request.Form["optAEditor"].ToString();
    //}
    protected void Button1_Click(object sender, EventArgs e)
    {
        string CategoryID="";
        string TopicID="";
        bool saveData=true;

        string[] arr = Request.Form["MasterValue"].ToString().Split(',');
        if (arr.GetUpperBound(0) == 1)
        {
            CategoryID = Request.Form["MasterValue"].ToString().Split(',')[0].ToString();
            TopicID = Request.Form["MasterValue"].ToString().Split(',')[1].ToString();
        }

        saveData = CheckMandatory(Request.Form["editor2"].ToString().Trim(), lblValidateQuestion);
        saveData = CheckMandatory(Request.Form["optAEditor"].ToString().Trim(), lblValidationOptionA);
        saveData = CheckMandatory(Request.Form["optBEditor"].ToString().Trim(), lblValidationOptionB);
        saveData = CheckMandatory(Request.Form["ansEditor"].ToString().Trim(), lblValidationAnswer);
        saveData = CheckMandatory(CategoryID, lblValidationCategory);
        saveData = CheckMandatory(TopicID, lblValidationTopic);
        saveData = CheckMandatory(txtDuration.Text, lblValidationDuration);

        if(saveData == true)
        {
            SqlCommand cmd;
            int isImage = 0;
            HttpPostedFile fl = Request.Files["files"];
            if (fl != null && fl.ContentLength > 0)
            {
                int len = fl.ContentLength;
                Session["pic"] = new byte[len];
                fl.InputStream.Read((byte[])Session["pic"], 0, len);
                isImage = 1;
            }
            else if (((byte[])Session["pic"]).Length > 0)
                isImage = 1;
            else
                Session["pic"] = new byte[0];

            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            if (Session["QuestionIsEditMode"].ToString() == "false")
            {
                cmd = new SqlCommand("insert into " +
                                "Question(DirectionsToSolve, Question, OptionA, OptionB, OptionC, OptionD, OptionE, OptionF, OptionG, OptionH, OptionI, " +
                                "Answer, Explanation, IsImage, Duration, CategoryID, TopicID, CreatedBy) " +
                                "values('" + Request.Form["editor1"] + "','" +
                                Request.Form["editor2"] + "','" +
                                Request.Form["optAEditor"] + "','" +
                                Request.Form["optBEditor"] + "','" +
                                Request.Form["optCEditor"] + "','" +
                                Request.Form["optDEditor"] + "','" +
                                Request.Form["optEEditor"] + "','" +
                                Request.Form["optFEditor"] + "','" +
                                Request.Form["optGEditor"] + "','" +
                                Request.Form["optHEditor"] + "','" +
                                Request.Form["optIEditor"] + "','" +
                                Request.Form["ansEditor"] + "','" +
                                Request.Form["expEditor"] + "','" +
                                isImage + "','" +
                                txtDuration.Text + "','" +
                                CategoryID + "','" +
                                TopicID + "','" +
                                Membership.GetUser().ProviderUserKey.ToString() + "'" +
                                ");SELECT CAST(scope_identity() AS bigint);", conn);
                Session["QuesID"] = (long)cmd.ExecuteScalar();
            }
            else
            {
                cmd = new SqlCommand(" Update Question SET " +
                    "DirectionsToSolve = '" + Request.Form["editor1"] + "', " +
                    "Question = '" + Request.Form["editor2"] + "', " +
                    "OptionA = '" + Request.Form["optAEditor"] + "', " +
                    "OptionB = '" + Request.Form["optBEditor"] + "', " +
                    "OptionC = '" + Request.Form["optCEditor"] + "', " +
                    "OptionD = '" + Request.Form["optDEditor"] + "', " +
                    "OptionE = '" + Request.Form["optEEditor"] + "', " +
                    "OptionF = '" + Request.Form["optFEditor"] + "', " +
                    "OptionG = '" + Request.Form["optGEditor"] + "', " +
                    "OptionH = '" + Request.Form["optHEditor"] + "', " +
                    "OptionI = '" + Request.Form["optIEditor"] + "', " +
                    "Answer = '" + Request.Form["ansEditor"] + "', " +
                    "Explanation = '" + Request.Form["expEditor"] + "', " +
                    "IsImage = '" + isImage + "', " +
                    "Duration = '" + txtDuration.Text + "', " +
                    "CategoryID = '" + CategoryID + "', " +
                    "TopicID = '" + TopicID + "', " +
                    "ModifiedDateTime = '" + DateTime.Now.ToString("yyyy-MMM-dd HH:mm:ss") + "', " +
                    "ModifiedBy = '" + Membership.GetUser().ProviderUserKey.ToString() + "' where QuestionID='" + Session["QuesID"].ToString() + "'", conn);
                cmd.ExecuteNonQuery();
            }

            if (isImage == 1)
            {
                cmd.CommandText = "update question set [image]=@pic where questionid='" + Session["QuesID"].ToString() + "'";
                cmd.Parameters.AddWithValue("@pic", (byte[])Session["pic"]);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
        System.Web.UI.WebControls.Label lbl = new System.Web.UI.WebControls.Label();
        //string strMsg="Successfully Updated!";
   
        //lbl.Text = "<script language='javascript'>" + Environment.NewLine + "window.alert(" + "'" + strMsg + "'" + ")</script>";
        //MsgBox(strMsg, this.Page, this);
        
        //Page.Controls.Add(lbl);
            //MessageBox.Show("Successfully Updated!");
        alert = true;
            
        if (Session["QuestionIsEditMode"].ToString() == "false")
        {

            Response.Redirect("Default.aspx");
        }
        else
        {
            Response.Redirect("Default.aspx?id=" + Session["QuesID"].ToString());
        }

            
        }
    }
    public void MsgBox(String ex, Page pg, Object obj)
    {
        string s = "<SCRIPT language='javascript'>alert('" + ex.Replace("\r\n", "\\n").Replace("'", "") + "'); </SCRIPT>";
        Type cstype = obj.GetType();
        ClientScriptManager cs = pg.ClientScript;
        cs.RegisterClientScriptBlock(cstype, s, s.ToString());
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string st = String.Format("<img src='' />");
        ClientScript.RegisterStartupScript(this.GetType(), "ReadImage", "readImage('" + st + "')", true);
        Session["pic"] = new byte[0];
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        if (MessageBox.Show("Are you sure want to delete?", "Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("update Question set isdeleted=1 where QuestionID='" + Session["QuesID"].ToString() + "'", conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted", "Deleted");
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
            //ClientScript.RegisterStartupScript(this.GetType(), "goBack", "history.go(-1);", true);
        }
    }

    [WebMethod]
    public static List<string> GetAutoCompleteCategory(string categoryname)
    {
        List<string> result = new List<string>();
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("select categoryid, categoryname from category where categoryname LIKE '%'+@SearchText+'%'", con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@SearchText", categoryname);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    result.Add(string.Format("{0}/{1}", dr["categoryname"], dr["categoryid"]));
                }
                return result;
            }
        }
    }

    [WebMethod]
    public static List<string> GetAutoCompleteTopic(string topicname, string categoryid)
    {
        List<string> result = new List<string>();
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("select topicid, topicname from topic where topicname LIKE '%'+@SearchText+'%' and categoryid = @categoryid", con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@SearchText", topicname);
                cmd.Parameters.AddWithValue("@categoryid", categoryid);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    result.Add(string.Format("{0}/{1}", dr["topicname"], dr["topicid"]));
                }
                return result;
            }
        }
    }

}
