﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Admin_CategoryList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from category", conn);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds, "Category");
            DataTable dt = new DataTable();
            dt = ds.Tables["Category"];
            Literal1.Text = "<center>";
            Literal1.Text += "<table width='75%' border='0' >";
            int i = 1;
            foreach (DataRow dr in dt.Rows)
            {
                if(i % 2 == 1)
                    Literal1.Text += "<tr height='35px'>";
                Literal1.Text += "<td style=' vertical-align: middle;'> <i class='fa fa-folder' aria-hidden='true'></i> </td> <td> <a href='TopicList.aspx?id="  + dr["CategoryID"].ToString() + "' > <i>"  + dr["CategoryName"].ToString() + " </i> </a> </td>";
                if (i % 2 == 0)
                    Literal1.Text += "</tr>";
                i++;
            }
            Literal1.Text += "</table>";
            Literal1.Text += "</center>";
        }
    }
}