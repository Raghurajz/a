﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;

public partial class Admin_StartExam : System.Web.UI.Page
{
    private SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    DataTable dt;
    static int intCounter = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        conn.Open();
        SqlCommand objCommand = new SqlCommand(@"select * from Question", conn);
        SqlDataAdapter da = new SqlDataAdapter(objCommand);
        dt = new DataTable();
        da.Fill(dt);
        conn.Close();
        ViewState["QuesNumber"] = 0;
        
    }

    protected static string DisplayQuestion(DataTable dt)
    {
        //ViewState["QuesNumber"] = int.Parse(ViewState["QuesNumber"].ToString()) + 1;
        intCounter++;
        DataRow dr = dt.Rows[intCounter];
        return dr["Question"].ToString();
        //Timer1.Interval = int.Parse(dr["Duration"].ToString());
        //Timer1.Interval = 1000;
    }




    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if( int.Parse(Session["StartTimer"].ToString()) == 1)
            Literal1.Text= DisplayQuestion(dt);
    }
}