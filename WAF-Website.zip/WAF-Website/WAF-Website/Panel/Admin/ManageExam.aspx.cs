﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Admin_ManageExam : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Reset();
            loadData();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        long ExamID=-1;
        try
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            ExamID = long.Parse(new SqlCommand("insert into Exam(ExamName,ExamDateTime,GroupID,IsTrial,IsScheduleActive,CreatedBy) values('" + txtExamName.Text + "','" + DateTime.Parse(Request.Form[TextBox1.UniqueID]) + "','" + ddlGroup.SelectedValue
                            + "','" + ddlIsTrial.SelectedValue
                            + "','" + ddlIsScheduleActive.SelectedValue
                            + "','" + Membership.GetUser().ProviderUserKey.ToString() + "'); select @@identity", con).ExecuteScalar().ToString());
            if (ExamID > 0 && ddlIsScheduleActive.SelectedValue.ToString() == "1")
                GenerateAllocateTickets(ExamID);
            loadData();
            Reset();
            if (con.State == ConnectionState.Open)
                con.Close();

            ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
        }
        catch (Exception e1)
        {
            if (ExamID >0)
            {
                if (con.State == ConnectionState.Closed)
                con.Open();
                new SqlCommand("delete from alltickets where ExamID=" + ExamID, con).ExecuteNonQuery();
                new SqlCommand("delete from prizedetails where ExamID=" + ExamID, con).ExecuteNonQuery();
                new SqlCommand("delete from exam where ExamID=" + ExamID, con).ExecuteNonQuery();
            }
            if (con.State == ConnectionState.Open)
                con.Close();
            ClientScript.RegisterStartupScript(this.GetType(), "Error", "alert('" + e1.Message + "');", true);
        }
    }

    protected void GenerateAllocateTickets(long ID)
    {
        GenerateTickets(ID);
        GeneratePrizes(ID); 
        //AllocateTickets(ID);
    }

    protected void GenerateTickets(long ID)
    {

            SqlCommand cmd = new SqlCommand("RefreshPassword", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;

            SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = ID;
            cmd.Parameters.Add(p1);

            cmd.ExecuteNonQuery();
        
    }

    protected void GeneratePrizes(long ID)
    {
            System.Threading.Thread.Sleep(1000);


            long WinningNumber = getWinningNumber(ID);
            new SqlCommand("delete from prizedetails where examid='" + ID + "'", con).ExecuteNonQuery();
            for (int i = 6; i >= 2; i--)
            {
                List<string> result = GenerateSequences(WinningNumber, i);
                foreach (string itm in result)
                {
                    string[] arr = itm.Split(',');
                    new SqlCommand(@"insert into prizedetails(WinningNumber, Prize, MatchingNumber,StartPosition, StringLength, TicketNumber,
                                ExamID) select '" + WinningNumber + "' as WinningNumber,'" + (7 - i).ToString() + "' as Prize,'" + arr[0] + "' as MatchingNumber, '" + arr[1] + "' as StartPosition, '" + arr[2] + "' as StringLength, TicketNumber,'" + ID + "' from alltickets where SUBSTRING(ticketnumber," + int.Parse(arr[1]) + "," + int.Parse(arr[2]) + ")='" + arr[0] + "'", con).ExecuteNonQuery();
                }
            }

            // The Same Ticket will fall under 2 or 3 different prize, the below keeps the top prizes and removes other prizes
            new SqlCommand(@"DELETE FROM PrizeDetails WHERE AutoID IN (
                                                SELECT AutoID FROM (
                                                    SELECT 
                                                        AutoID
                                                        ,ROW_NUMBER() OVER (PARTITION BY TicketNumber ORDER BY AutoID) AS Ticket
                                                    FROM PrizeDetails WHERE EXAMID = '" + ID + @"') a WHERE Ticket > 1 
                                            )", con).ExecuteNonQuery();

            //update prize tickets in alltickets
            /*new SqlCommand(@"update AllTickets SET IsPrize =1  WHERE ticketnumber in 
                            ( SELECT a.ticketnumber from AllTickets a join PrizeDetails b on a.ExamID = b.ExamID and a.TicketNumber = b.TicketNumber ) 
                            and examid='" + ExamID + "'", con).ExecuteNonQuery();*/

            new SqlCommand(@"UPDATE a SET a.IsPrize = b.Prize, IsExamAttended=1 FROM AllTickets a 
                            JOIN PrizeDetails b ON a.TicketNumber = b.TicketNumber 
                            WHERE a.ExamID='" + ID + "'and b.ExamID ='" + ID + "'", con).ExecuteNonQuery();

            new SqlCommand(@"UPDATE AllTickets SET IsExamAttended = 1 WHERE TicketNumber IN
                        (
	                        select * from (	SELECT TOP (" + GetNonPrizeAttended() + ") TicketNumber from AllTickets WHERE ExamID = '" + ID + @"' AND IsExamAttended=0 ORDER BY NEWID()  ) a
                        ) AND ExamID = '" + ID + "'", con).ExecuteNonQuery();

    }

    protected int GetNonPrizeAttended()
    {
        Random rnd = new Random();
        return rnd.Next(50176, 100352);

    }

    protected void AllocateTickets(long ID)
    {
        DateTime AllocatedDateTime = DateTime.UtcNow.AddMinutes(330);
   
        SqlCommand cmd = new SqlCommand("SELECT * from AllocationMaster WHERE isdeleted=0", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        foreach (DataRow dr in dt.Rows)
        {
            SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETS", con);
            cmdAllocate.CommandType = CommandType.StoredProcedure;

            SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = ID;

            SqlParameter p2 = new SqlParameter("@AgencyID", SqlDbType.UniqueIdentifier);
            p2.Direction = ParameterDirection.Input;
            p2.Value = new Guid(dr["AgencyUserId"].ToString());

            //SqlParameter p3 = new SqlParameter("@AllocatedDateTime",SqlDbType.DateTime);
            //p3.Direction = ParameterDirection.Input;
            //p3.Value = AllocatedDateTime;

            SqlParameter p3 = new SqlParameter("@AllocatedBy", SqlDbType.UniqueIdentifier);
            p3.Direction = ParameterDirection.Input;
            p3.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

            SqlParameter p4 = new SqlParameter("@TotalNonPrize", SqlDbType.BigInt);
            p4.Direction = ParameterDirection.Input;
            p4.Value = long.Parse(dr["NonPrizeAllocation"].ToString());

            SqlParameter p5 = new SqlParameter("@TotalPrize1", SqlDbType.Int);
            p5.Direction = ParameterDirection.Input;
            p5.Value = int.Parse(dr["Prize1Allocation"].ToString());

            SqlParameter p6 = new SqlParameter("@TotalPrize2", SqlDbType.Int);
            p6.Direction = ParameterDirection.Input;
            p6.Value = int.Parse(dr["Prize2Allocation"].ToString());

            SqlParameter p7 = new SqlParameter("@TotalOtherPrize", SqlDbType.BigInt);
            p7.Direction = ParameterDirection.Input;
            p7.Value = long.Parse(dr["OtherPrizeAllocation"].ToString());

            cmdAllocate.Parameters.Add(p1);
            cmdAllocate.Parameters.Add(p2);
            cmdAllocate.Parameters.Add(p3);
            cmdAllocate.Parameters.Add(p4);
            cmdAllocate.Parameters.Add(p5);
            cmdAllocate.Parameters.Add(p6);
            cmdAllocate.Parameters.Add(p7);

            cmdAllocate.ExecuteNonQuery();

        }

    }

    List<string> GenerateSequences(long n, int r)
    {
        List<string> retList = new List<string>();
        int length = n.ToString().Length;
        for (int i = 0; i <= length - r; i++)
            retList.Add(n.ToString().Substring(i, r) + "," + (i + 1).ToString() + "," + r.ToString());
        return retList;
    }

    protected long getWinningNumber(long ID)
    {

            long GroupID = long.Parse(new SqlCommand("Select GroupID from exam where examid = '" + ID + "'", con).ExecuteScalar().ToString());
            long retValue = WAFUtility.getWinningNumber(GroupID);
            return retValue;
    }


    protected void BindCategory()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        //DropDownList ddlCategory = (DropDownList)gridView.HeaderRow.FindControl("ddlCategory");
        SqlCommand cmd = new SqlCommand("select GroupID, GroupName from QGroup where isDeleted=0", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        ddlGroup.DataSource = ds;
        ddlGroup.DataTextField = "GroupName";
        ddlGroup.DataValueField = "GroupID";
        ddlGroup.DataBind();
        //ddlCategory.Items.Insert(0, new ListItem("--Select--", "0"));
        //ddlCategory.SelectedIndex = 0;


    }
    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand("Select a.ExamID, a.ExamName, a.ExamDateTime, a.GroupID,b.GroupName, a.IsTrial, a.IsScheduleActive,a.IsHistory from Exam a join QGroup b on a.GroupID= b.GroupID where a.isdeleted=0 order by a.ExamDateTime desc, a.ExamID asc", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["ExamTable"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        BindCategory();
    }

    protected void gridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gridView.EditIndex = e.NewEditIndex;
        loadData();
    }
    protected void gridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string confirmValue = Request.Form["confirm_value"];
        if (confirmValue != "Yes")
            return;
        string ExamID = gridView.DataKeys[e.RowIndex].Values["ExamID"].ToString();
        //long TopicID = Convert.ToInt32(gridView.Rows[e.RowIndex].Cells[1].Text);
        System.Web.UI.WebControls.TextBox ExamName = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtname");
        System.Web.UI.WebControls.TextBox ExamDateTime = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtDateTime");
        DropDownList ddlGroupEdit = (DropDownList)gridView.Rows[e.RowIndex].FindControl("ddlGroupEdit");
        System.Web.UI.WebControls.CheckBox chkIsTrial =  (System.Web.UI.WebControls.CheckBox) gridView.Rows[e.RowIndex].FindControl("chkIsTrial");
        System.Web.UI.WebControls.CheckBox chkIsScheduleActive =  (System.Web.UI.WebControls.CheckBox) gridView.Rows[e.RowIndex].FindControl("chkIsScheduleActive");
        System.Web.UI.WebControls.CheckBox chkIsHistory = (System.Web.UI.WebControls.CheckBox)gridView.Rows[e.RowIndex].FindControl("chkIsHistory");
        con.Open();

        SqlCommand cmd; 
        cmd = new SqlCommand("update alltickets set IsHistory = '" + Convert.ToInt16(chkIsHistory.Checked) + "' where ExamID=" + ExamID, con);
        int ra = cmd.ExecuteNonQuery();
        if (ra == 0)
        {
            chkIsHistory.Checked = false;
        }
        else
        {
            cmd = new SqlCommand("update prizedetails set IsHistory = '" + Convert.ToInt16(chkIsHistory.Checked) + "' where ExamID=" + ExamID, con);
            cmd.ExecuteNonQuery();
        }

        cmd = new SqlCommand("update Exam set ExamName='" + ExamName.Text + "', " +
                    "ExamDateTime='" + DateTime.Parse(Request.Form[ExamDateTime.UniqueID]) + "', " +
                    "GroupID = '" + ddlGroupEdit.SelectedValue.ToString() + "', " +
                    "ModifiedDateTime = '" + DateTime.Now.ToString("yyyy-MMM-dd HH:mm:ss") + "', " +
                    "IsTrial = '" + Convert.ToInt16(chkIsTrial.Checked) + "', " +
                    "IsHistory = '" + Convert.ToInt16(chkIsHistory.Checked) + "', " +
                    "IsScheduleActive = '" + Convert.ToInt16(chkIsScheduleActive.Checked) + "', " +
                    "ModifiedBy = '" + Membership.GetUser().ProviderUserKey.ToString() + "' where ExamID=" + ExamID, con);
        cmd.ExecuteNonQuery();


                


        //if (chkIsTrial.Checked == true)
        //{
        //    new SqlCommand("delete from alltickets where ExamID=" + ExamID, con).ExecuteNonQuery();
        //    new SqlCommand("delete from prizedetails where ExamID=" + ExamID, con).ExecuteNonQuery();
        //}

        //if (chkIsScheduleActive.Checked == true)
        //{
        //    GenerateAllocateTickets(long.Parse(ExamID));
        //}

        con.Close();
        lblmsg.BackColor = Color.Blue;
        lblmsg.ForeColor = Color.White;
        lblmsg.Text = ExamName.Text + "        Updated successfully........    ";
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {


        string ExamID = gridView.DataKeys[e.RowIndex].Values["ExamID"].ToString();
        //if (!IsRecordExists(ExamID))
        //{
            if(con.State==ConnectionState.Closed)
                con.Open();
            new SqlCommand("delete from alltickets where ExamID=" + ExamID, con).ExecuteNonQuery();
            new SqlCommand("delete from prizedetails where ExamID=" + ExamID, con).ExecuteNonQuery();
            SqlCommand cmd = new SqlCommand("delete from exam where ExamID=" + ExamID, con);
            int result = cmd.ExecuteNonQuery();
            con.Close();
            if (result == 1)
            {
                loadData();
                lblmsg.BackColor = Color.Red;
                lblmsg.ForeColor = Color.White;
                lblmsg.Text = ExamID + "      Deleted successfully.......    ";
            }
        //}
        //else
        //{
        //    lblmsg.BackColor = Color.Red;
        //    lblmsg.ForeColor = Color.White;
        //    lblmsg.Text = "Exam Result Exist on this ID, So unable to Delete!";
        //}
    }

    protected bool IsRecordExists(string id)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(*) from ExamResult where ExamID='" + id + "' and isdeleted=0", con);
        long x = Convert.ToInt64(cmd.ExecuteScalar().ToString());
        con.Close();
        if (x > 0)
            return true;
        else
            return false;
    }
    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string name = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "ExamName"));
            System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete");
            //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
            if (lnkbtnresult != null)
            {
                lnkbtnresult.Attributes.Add("onclick", "javascript:return deleteConfirm('" + name + "')");
            }
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string item = e.Row.Cells[0].Text;
            foreach (System.Web.UI.WebControls.Button button in e.Row.Cells[2].Controls.OfType<System.Web.UI.WebControls.Button>())
            {
                if (button.CommandName == "Update")
                {
                    button.Attributes["onclick"] = "if(!confirm('Do you want to delete " + item + "?')){ return false; };";
                }
            }
        }


        if (e.Row.RowType == DataControlRowType.DataRow && gridView.EditIndex == e.Row.RowIndex)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            DropDownList ddlGroupEdit = (DropDownList)e.Row.FindControl("ddlGroupEdit");
            HiddenField hdnGroup = (HiddenField)e.Row.FindControl("hdnGroup");
            SqlCommand cmd = new SqlCommand("select GroupID, GroupName from QGroup where isDeleted=0", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ddlGroupEdit.DataSource = ds;
            ddlGroupEdit.DataTextField = "GroupName";
            ddlGroupEdit.DataValueField = "GroupID";
            ddlGroupEdit.DataBind();
            //ddlCategoryEdit.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlGroupEdit.Items.FindByValue(hdnGroup.Value).Selected = true;
            con.Close();
        }
    }
    //protected void gridView_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName.Equals("AddNew"))
    //    {
    //        System.Web.UI.WebControls.TextBox inname = (System.Web.UI.WebControls.TextBox)gridView.HeaderRow.FindControl("inname");
    //        DropDownList ddlCategory = (DropDownList)gridView.HeaderRow.FindControl("ddlCategory");
    //        con.Open();
    //        SqlCommand cmd =
    //            new SqlCommand(
    //                "insert into Topic(TopicName,CategoryID,CreatedBy) values('" + inname.Text + "','" + ddlCategory.SelectedValue + "','" + Membership.GetUser().ProviderUserKey.ToString() + "')", con);
    //        int result = cmd.ExecuteNonQuery();
    //        con.Close();
    //        if (result == 1)
    //        {
    //            loadData();
    //            lblmsg.BackColor = Color.Green;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + "      Added successfully......    ";
    //        }
    //        else
    //        {
    //            lblmsg.BackColor = Color.Red;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = inname.Text + " Error while adding row.....";
    //        }
    //    }
    //}

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["ExamTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void Reset()
    {

        txtExamName.Text = "";
        TextBox1.Text = "";
        ddlIsTrial.SelectedIndex = 0;
        ddlIsScheduleActive.SelectedIndex = 0;
    }
}