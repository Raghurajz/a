﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Panel_Admin_CreateTickets : System.Web.UI.Page
{
    long curExamID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            PopulateExam();
        
    }

    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and examdatetime > DATEADD(mi,330,GETUTCDATE()) and isdeleted=0 order by examdatetime desc", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DropDownList1.Items.Clear();
            foreach (DataRow dr in dt.Rows)
                DropDownList1.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }

    protected void SetDefaultIndex()
    {
        if (ViewState["CT_Ex_Index"] != null)
            DropDownList1.SelectedIndex = int.Parse(ViewState["CT_Ex_Index"].ToString());
        else
        {
            DropDownList1.SelectedIndex = 0;
            ViewState["CT_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
            ViewState["CT_Ex_Text"] = DropDownList1.SelectedItem.Text;
            ViewState["CT_Ex_Value"] = DropDownList1.SelectedValue.ToString();

        }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Literal1.Text = "";
        //ViewState["CT_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        //ViewState["CT_Ex_Text"] = DropDownList1.SelectedItem.Text;
        //ViewState["CT_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
    }

    protected void btnCreate_Click(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex < 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid Selection, Please Check!');", true);
            return;
        }

        btnCreate.Enabled = false;
        try
        {
            //curExamID = long.Parse(DropDownList1.SelectedValue.ToString());
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
            {
                //conn.Open();
                //long TicketCount = long.Parse((new SqlCommand("select count(*) from alltickets where examid = '" + curExamID.ToString() + "'", conn)).ExecuteScalar().ToString());
                //if (TicketCount > 1)
                //{
                //    if (System.Windows.Forms.MessageBox.Show("Tickets Already Created, Do you want to recreate it?", "Tickets Already Created", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                //    {
                //        CreateTickets();
                //    }
                //}
                //else
                //{
                Literal1.Text = "";
                    CreateTickets();
                //}
                //conn.Close();
            }
        }
        catch (Exception ex1)
        {
            Literal1.Text = "<font color=red> <b> " + ex1.Message.ToString() + "</b> </font>";
            btnCreate.Enabled = true;
        }
        btnCreate.Enabled = true;
        Literal1.Text = "<font color=red> <b> Ticket Creation Completed! </b> </font>";
    }
    protected void CreateTickets()
    {
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            
            SqlCommand cmd = new SqlCommand("RefreshPassword", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;

            SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = long.Parse(DropDownList1.SelectedValue);
            cmd.Parameters.Add(p1);
            
            cmd.ExecuteNonQuery();

            conn.Close();
            
        }

    }
}