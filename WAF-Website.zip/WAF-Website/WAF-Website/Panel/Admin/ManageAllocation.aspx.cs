﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_ManageAllocation : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    long Prize1Total = 0;
    long Prize2Total = 0;
    long OtherPrizeTotal = 0;
    long NonPrizeTotal = 0;
    long GrandTotal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateExam();
            UpdateSalesInfo();
            Reset();
            loadData();
        }
    }

    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and examdatetime > DATEADD(mi,330,GETUTCDATE()) and isdeleted=0 order by examdatetime", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddlExam.Items.Clear();
            foreach (DataRow dr in dt.Rows)
                ddlExam.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }


    //protected void UpdateSalesInfo()
    //{
    //    using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
    //    {
    //        con.Open();
    //        lblTotalAllocated.Text = new SqlCommand("SELECT COUNT(*) FROM AllTickets WHERE ExamID='" + ddlExam.SelectedValue.ToString() + "'", con).ExecuteScalar().ToString();
    //        lblTotalSales.Text = new SqlCommand("SELECT COUNT(*) FROM AllTickets WHERE ExamID='" + ddlExam.SelectedValue.ToString() + "' AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();
    //        con.Close();
    //    }
    //}

    protected void UpdateSalesInfo()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            lblTotalAllocatedNonPrize.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=0 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0", con).ExecuteScalar().ToString();
            lblTotalSalesNonPrize.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=0 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();

            lblTotalAllocatedPrize1.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=1 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0", con).ExecuteScalar().ToString();
            lblTotalSalesPrize1.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=1 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();

            lblTotalAllocatedPrize2.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=2 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0", con).ExecuteScalar().ToString();
            lblTotalSalesPrize2.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize=2 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();

            lblTotalAllocatedOtherPrize.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize>2 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0", con).ExecuteScalar().ToString();
            lblTotalSalesOtherPrize.Text = new SqlCommand(@"Select ISNULL(SUM(CASE WHEN IsPrize>2 THEN 1 ELSE 0 END),0) as  NonPrizeAllocation from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();

            lblTotalAllocated.Text = new SqlCommand(@"Select ISNULL(count(*),0) as  NonPrizeAllocation from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0", con).ExecuteScalar().ToString();
            lblTotalSales.Text = new SqlCommand(@"Select ISNULL(count(*),0) as  NonPrizeAllocation from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND AgencyUserId IS NOT NULL", con).ExecuteScalar().ToString();

            con.Close();
        }
    }

    protected void AllocateTickets()
    {
        DateTime AllocatedDateTime = DateTime.UtcNow.AddMinutes(330);

        SqlCommand cmd = new SqlCommand("SELECT * from AllocationMaster WHERE isdeleted=0", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        foreach (DataRow dr in dt.Rows)
        {
            SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETS", con);
            cmdAllocate.CommandType = CommandType.StoredProcedure;

            SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = long.Parse(ddlExam.SelectedValue.ToString());

            SqlParameter p2 = new SqlParameter("@AgencyID", SqlDbType.UniqueIdentifier);
            p2.Direction = ParameterDirection.Input;
            p2.Value = new Guid(dr["AgencyUserId"].ToString());

            //SqlParameter p3 = new SqlParameter("@AllocatedDateTime",SqlDbType.DateTime);
            //p3.Direction = ParameterDirection.Input;
            //p3.Value = AllocatedDateTime;

            SqlParameter p3 = new SqlParameter("@AllocatedBy", SqlDbType.UniqueIdentifier);
            p3.Direction = ParameterDirection.Input;
            p3.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

            SqlParameter p4 = new SqlParameter("@TotalNonPrize", SqlDbType.BigInt);
            p4.Direction = ParameterDirection.Input;
            p4.Value = long.Parse(dr["NonPrizeAllocation"].ToString());

            SqlParameter p5 = new SqlParameter("@TotalPrize1", SqlDbType.Int);
            p5.Direction = ParameterDirection.Input;
            p5.Value = int.Parse(dr["Prize1Allocation"].ToString());

            SqlParameter p6 = new SqlParameter("@TotalPrize2", SqlDbType.Int);
            p6.Direction = ParameterDirection.Input;
            p6.Value = int.Parse(dr["Prize2Allocation"].ToString());

            SqlParameter p7 = new SqlParameter("@TotalOtherPrize", SqlDbType.BigInt);
            p7.Direction = ParameterDirection.Input;
            p7.Value = long.Parse(dr["OtherPrizeAllocation"].ToString());

            cmdAllocate.Parameters.Add(p1);
            cmdAllocate.Parameters.Add(p2);
            cmdAllocate.Parameters.Add(p3);
            cmdAllocate.Parameters.Add(p4);
            cmdAllocate.Parameters.Add(p5);
            cmdAllocate.Parameters.Add(p6);
            cmdAllocate.Parameters.Add(p7);

            cmdAllocate.ExecuteNonQuery();

        }

    }


    protected void AllocateUnSoldTickets()
    {
        DateTime AllocatedDateTime = DateTime.UtcNow.AddMinutes(330);

        SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETS", con);
        cmdAllocate.CommandType = CommandType.StoredProcedure;

        SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
        p1.Direction = ParameterDirection.Input;
        p1.Value = long.Parse( ddlExam.SelectedValue.ToString());

        SqlParameter p2 = new SqlParameter("@AgencyID", SqlDbType.UniqueIdentifier);
        p2.Direction = ParameterDirection.Input;
        p2.Value = new Guid(ddlAgency.SelectedValue.ToString());

        //SqlParameter p3 = new SqlParameter("@AllocatedDateTime",SqlDbType.DateTime);
        //p3.Direction = ParameterDirection.Input;
        //p3.Value = AllocatedDateTime;

        SqlParameter p3 = new SqlParameter("@AllocatedBy", SqlDbType.UniqueIdentifier);
        p3.Direction = ParameterDirection.Input;
        p3.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

        SqlParameter p4 = new SqlParameter("@TotalNonPrize", SqlDbType.BigInt);
        p4.Direction = ParameterDirection.Input;
        p4.Value = long.Parse(txtNonPrize.Text);

        SqlParameter p5 = new SqlParameter("@TotalPrize1", SqlDbType.Int);
        p5.Direction = ParameterDirection.Input;
        p5.Value = int.Parse(txtPrize1.Text);

        SqlParameter p6 = new SqlParameter("@TotalPrize2", SqlDbType.Int);
        p6.Direction = ParameterDirection.Input;
        p6.Value = int.Parse(txtPrize2.Text);

        SqlParameter p7 = new SqlParameter("@TotalOtherPrize", SqlDbType.BigInt);
        p7.Direction = ParameterDirection.Input;
        p7.Value = long.Parse(txtOtherPrize.Text);

        cmdAllocate.Parameters.Add(p1);
        cmdAllocate.Parameters.Add(p2);
        cmdAllocate.Parameters.Add(p3);
        cmdAllocate.Parameters.Add(p4);
        cmdAllocate.Parameters.Add(p5);
        cmdAllocate.Parameters.Add(p6);
        cmdAllocate.Parameters.Add(p7);

        cmdAllocate.ExecuteNonQuery();
     

    }

    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (DataBinder.Eval(e.Row.DataItem, "Prize1Allocation") != DBNull.Value)
                Prize1Total += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Prize1Allocation"));
            if (DataBinder.Eval(e.Row.DataItem, "Prize2Allocation") != DBNull.Value)
                Prize2Total += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Prize2Allocation"));
            if (DataBinder.Eval(e.Row.DataItem, "OtherPrizeAllocation") != DBNull.Value)
                OtherPrizeTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "OtherPrizeAllocation"));
            if (DataBinder.Eval(e.Row.DataItem, "NonPrizeAllocation") != DBNull.Value)
                NonPrizeTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "NonPrizeAllocation"));
            if (DataBinder.Eval(e.Row.DataItem, "Total") != DBNull.Value)
                GrandTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "Total"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblPrize1Total = (Label)e.Row.FindControl("lblPrize1Total");
            lblPrize1Total.Text = Prize1Total.ToString();
            Label lblPrize2Total = (Label)e.Row.FindControl("lblPrize2Total");
            lblPrize2Total.Text = Prize2Total.ToString();
            Label lblOtherPrizeTotal = (Label)e.Row.FindControl("lblOtherPrizeTotal");
            lblOtherPrizeTotal.Text = OtherPrizeTotal.ToString();
            Label lblNonPrizeTotal = (Label)e.Row.FindControl("lblNonPrizeTotal");
            lblNonPrizeTotal.Text = NonPrizeTotal.ToString();
            Label lblGrandTotal = (Label)e.Row.FindControl("lblGrandTotal");
            lblGrandTotal.Text = GrandTotal.ToString();
        }
    }


    protected bool IsTicketsAvailable(long TicketCount, int prize)
    {
        if (GetAvailableTickets(prize) >= TicketCount)
            return true;
        else
            return false;
    }

    protected long GetAvailableTickets(int prize)
    {
        long retValue;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            if(prize ==3 )
                retValue = long.Parse(new SqlCommand("SELECT COUNT(*) FROM AllTickets WHERE Examid ='" +
                                ddlExam.SelectedValue.ToString() +
                                "' AND AgencyUserId IS NULL AND IsPrize >2",con).ExecuteScalar().ToString());
            else
                retValue = long.Parse(new SqlCommand("SELECT COUNT(*) FROM AllTickets WHERE Examid ='" + 
                                            ddlExam.SelectedValue.ToString() +
                                            "' AND AgencyUserId IS NULL AND IsPrize =" + prize.ToString(),con).ExecuteScalar().ToString());
            con.Close();
        }
        return retValue;
    }

    protected long GetTotalTicketsFromAllocationMaster(int prize)
    {
        long retValue;
        string strQuery = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            switch(prize)
            {
                case 1:
                    strQuery = "SELECT ISNULL(SUM(Prize1Allocation),0) as Total FROM AllocationMaster";
                    break;
                case 2:
                    strQuery = "SELECT ISNULL(SUM(Prize2Allocation),0) as Total FROM AllocationMaster";
                    break;
                case 3:
                    strQuery = "SELECT ISNULL(SUM(OtherPrizeAllocation),0) as Total FROM AllocationMaster";
                    break;
                case 0:
                    strQuery = "SELECT ISNULL(SUM(NonPrizeAllocation),0) as Total FROM AllocationMaster";
                    break;
            }
            retValue = long.Parse(new SqlCommand(strQuery,con).ExecuteScalar().ToString());
            con.Close();
        }
        return retValue;
    }

    protected void btnAllocateMaster_Click(object sender, EventArgs e)
    {
        string confirmValue = Request.Form["confirm2_value"];
        if (confirmValue == "Yes")
        {

            if ( IsTicketsAvailable(GetTotalTicketsFromAllocationMaster(1),1) && IsTicketsAvailable(GetTotalTicketsFromAllocationMaster(2), 2) && IsTicketsAvailable(GetTotalTicketsFromAllocationMaster(3), 3) && IsTicketsAvailable(GetTotalTicketsFromAllocationMaster(0), 0))
            {

                if (con.State == ConnectionState.Closed)
                    con.Open();
                try
                {
                    AllocateTickets();
                }
                catch( Exception e1)
                {
                    new SqlCommand("update AllTickets  set AgencyUserID = null, AllocationID=null WHERE ExamID='" + ddlExam.SelectedValue.ToString() + "'", con).ExecuteNonQuery();
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('" + e1.Message  + ")", true);
                }
                if (con.State == ConnectionState.Open)
                    con.Close();
                loadData();
                UpdateSalesInfo();
                Reset();
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Alloted!')", true);
            }
            else
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Not Enough Tickets Available for Allocation!')", true);
            }
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked YES!')", true);
        }
        else
        {
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked NO!')", true);
        }
    }

    protected void btnAllocate_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";

        string confirmValue = Request.Form["confirm_value"];
        if (confirmValue == "Yes")
        {

            if (IsTicketsAvailable(GetAvailableTickets(1), 1) && IsTicketsAvailable(GetAvailableTickets(2), 2) && IsTicketsAvailable(GetAvailableTickets(3), 3) && IsTicketsAvailable(GetAvailableTickets(0), 0))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                try
                { 
                    AllocateUnSoldTickets();
                }
                catch (Exception e1)
                {
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('" + e1.Message + ")", true);
                }
                if (con.State == ConnectionState.Open)
                    con.Close();
                loadData();
                UpdateSalesInfo();
                Reset();
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Alloted!')", true);
            }
            else
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Not Enough Tickets Available for Allocation!')", true);
            }
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked YES!')", true);
        }
        else
        {
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked NO!')", true);
        }
        
           //ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }

    protected void BindAgency()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
                                                    join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
                                                    join aspnet_Roles r on ur.RoleId= r.RoleId
                                                    join Member m on u.UserId = m.MemberID
                                                    where r.RoleName='Agency' AND u.UserId NOT IN (SELECT distinct AgencyUserId from AllTickets WHERE Examid='" + ddlExam.SelectedValue.ToString() + "' AND AgencyUserId IS NOT NULL )", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);


            ddlAgency.DataSource = ds;
            ddlAgency.DataTextField = "UserName";
            ddlAgency.DataValueField = "UserID";
            ddlAgency.DataBind();
            con.Close();
        }
    }

    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand(@"Select a.AgencyUserId, m.MemberName  as AgencyName, 
                                            SUM(CASE WHEN IsPrize=0 THEN 1 ELSE 0 END) as  NonPrizeAllocation, 
                                            SUM(CASE WHEN IsPrize=1 THEN 1 ELSE 0 END) as  Prize1Allocation, 
                                            SUM(CASE WHEN IsPrize=2 THEN 1 ELSE 0 END) as  Prize2Allocation, 
                                            SUM(CASE WHEN IsPrize>2 THEN 1 ELSE 0 END) as  OtherPrizeAllocation, 
                                            COUNT(*) as  Total
                                            from AllTickets a join Member m on a.AgencyUserId= m.MemberID where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0
                                            GROUP BY a.AgencyUserID, m.MemberName", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["ManageAllocation"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        BindAgency();
    }

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["ManageAllocation"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void Reset()
    {
        txtNonPrize.Text = "";
        txtPrize1.Text = "";
        txtPrize2.Text = "";
        txtOtherPrize.Text = "";
        if (ddlAgency.Items.Count > 0)
            ddlAgency.SelectedIndex = 0;
        lblmsg.Text = "";
    }
}