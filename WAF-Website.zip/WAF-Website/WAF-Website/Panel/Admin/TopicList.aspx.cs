﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Admin_TopicList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["id"] != null)
            {
                SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from topic where categoryid='" + Request["id"].ToString() + "'", conn);
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds, "topic");
                DataTable dt = new DataTable();
                dt = ds.Tables["topic"];
                Literal1.Text = "<center>";
                Literal1.Text += "<table width='75%' border='0' >";
                int i = 1;
                foreach (DataRow dr in dt.Rows)
                {
                    if (i % 2 == 1)
                        Literal1.Text += "<tr height='30px'>";
                    Literal1.Text += "<td style=' vertical-align: middle;'> <i class='fa fa-folder-open' aria-hidden='true'></i>  </td> <td> <a href='QuestionList.aspx?id1=" + Request["id"].ToString() + "&id2=" + dr["TopicID"].ToString() + "' > <i>" + dr["TopicName"].ToString() + " </i> </a> </td>";
                    if (i % 2 == 0)
                        Literal1.Text += "</tr>";
                    i++;
                }
                Literal1.Text += "</table>";
                Literal1.Text += "</center>";
                Literal2.Text = "<h4 style=' display: inline;'>" + (new SqlCommand("select CategoryName from Category where CategoryID='" + Request["id"].ToString() + "'", conn)).ExecuteScalar().ToString() + " - List of Topics </h4>" ;

            }
        }
    }
}