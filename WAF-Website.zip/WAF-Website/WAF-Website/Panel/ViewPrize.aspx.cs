﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class Panel_Admin_ViewPrize : System.Web.UI.Page
{
    protected long ExamID;
    protected string curUserId;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateExam();
            
        }
        curUserId = Membership.GetUser().ProviderUserKey.ToString();
        
    }

    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and isdeleted=0 order by examdatetime desc", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DropDownList1.Items.Clear();
            //DropDownList1.Items.Add(new ListItem("All","0"));
            foreach (DataRow dr in dt.Rows)
                DropDownList1.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }
    protected void SetDefaultIndex()
    {
        if (ViewState["VP_Ex_Index"] != null)
        {
            DropDownList1.SelectedIndex = int.Parse(ViewState["VP_Ex_Index"].ToString());
        }
        else
        {
            DropDownList1.SelectedIndex = 0;
            ViewState["VP_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
            ViewState["VP_Ex_Text"] = DropDownList1.SelectedItem.Text;
            ViewState["VP_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        }

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Literal1.Text = "";
        //ViewState["VP_Ex_Value"] = DropDownList1.SelectedValue.ToString();
        //ViewState["VP_Ex_Text"] = DropDownList1.SelectedItem.Text;
        //ViewState["VP_Ex_Index"] = DropDownList1.SelectedIndex.ToString();
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        string strQry="";
        if (DropDownList1.SelectedIndex < 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "alertMessage", "alert('Invalid Selection, Please Check!');", true);
            return;
        }

        try
         {
              
        btnView.Enabled = false;
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        con.Open();

        SqlCommand cmd;
        SqlCommand cmd1;
        DataTable dt;
        DataTable dt1;
        SqlDataAdapter da;
        SqlDataAdapter da1;
        dt = new DataTable();
        dt1 = new DataTable();
        

        if (Roles.IsUserInRole("Agency"))
        {


            strQry = @" SELECT cast(prize as varchar) as Prize,count(*) as Tickets FROM prizedetails a JOIN Alltickets b ON a.ExamID = b.ExamID and a.TicketNumber = b.TicketNumber WHERE a.ExamID = '" + DropDownList1.SelectedValue +
                                                                "' and b.AgencyUserId = '" + Guid.Parse(curUserId) + "' group by prize union select 'Total' as Prize, count(*) as Tickets from prizedetails a JOIN AllTickets b ON a.ExamID=b.ExamID and a.TicketNumber = b.TicketNumber" +
                                                                " WHERE a.ExamID = '" + DropDownList1.SelectedValue + "' and b.AgencyUserId = '" + Guid.Parse(curUserId) + "'";
        }
        else
        {

            strQry = @" SELECT cast(prize as varchar) as Prize,count(*) as Tickets FROM prizedetails WHERE ExamID = '" + DropDownList1.SelectedValue +
                                                                "' group by prize union select 'Total' as Prize, count(*) as Tickets from prizedetails " +
                                                                " WHERE ExamID = '" + DropDownList1.SelectedValue + "'";
        }
        cmd = new SqlCommand(strQry, con);
        da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        if (Roles.IsUserInRole("Agency"))
        {
            strQry = @" SELECT cast(IsExamAttended as varchar), count(*) as Tickets FROM AllTickets WHERE ExamID = '" + DropDownList1.SelectedValue +
                                                    "' and AgencyUserId = '" + Guid.Parse(curUserId) + "' and IsPrize=0 group by IsExamAttended union select 'Total',  count(*) as Tickets from AllTickets " +
                                                    " WHERE ExamID = '" + DropDownList1.SelectedValue + "' and AgencyUserId = '" + Guid.Parse(curUserId) + "' and IsPrize=0";
        }
        else
        {
            strQry = @" SELECT cast(IsExamAttended as varchar), count(*) as Tickets FROM AllTickets WHERE ExamID = '" + DropDownList1.SelectedValue +
                                        "' and IsPrize=0 group by IsExamAttended union select 'Total',  count(*) as Tickets from AllTickets " +
                                        " WHERE ExamID = '" + DropDownList1.SelectedValue + "' and IsPrize=0";
        }
        cmd1 = new SqlCommand(strQry, con);
        da1 = new SqlDataAdapter(cmd1);
        da1.Fill(dt1);

        string strHTML = "";
        strHTML += "<head>";
        strHTML += "<style>";
        strHTML += "span.highlight {";
        strHTML += "background-color: yellow;";
        strHTML += "}";
        strHTML += "</style>";
        strHTML += "</head>";
        strHTML += "<body>";
        strHTML += "<center>";
        strHTML += "<div id='top'>";
        strHTML += "<table border='1' style='border: 0px solid black; width: 90%; word-wrap:break-word; table-layout: fixed;'>'";
        strHTML += "<tr>";
        strHTML += "<th colspan=6> Prize </th><th colspan=3>Non Prize </th>";
        strHTML += "<tr>";
        strHTML += "<tr>";
        strHTML += "<th> <a href='#1'> 1 </a> </th><th><a href='#2'> 2 </a></th><th><a href='#3'> 3</a></th><th><a href='#4'> 4</a></th><th><a  href='#5'> 5</a></th><th>Total</th><th>Exam Not Attended</th><th>Exam Attended</th><th>Total</th>";
        strHTML += "</tr>";
        strHTML += "<tr>";
        //    int x=1;
        //foreach (DataRow row in dt.Rows)
        //{
        //    //if (row["Prize"] == x.ToString())
        //        strHTML += "<td align='center'>" + row["Tickets"].ToString() + "</td>";
        //    //else
        //        //strHTML += "<td align='center'> &nbsp;</td>";
        //    x++;
        //}
        int x=1;
        for (int i = 0; i < dt.Rows.Count ; i++)
        {
            if (dt.Rows[i]["Prize"].ToString() == "Total" || dt.Rows[i]["Prize"].ToString() == x.ToString())
            {
                strHTML += "<td align='center'>" + dt.Rows[i]["Tickets"].ToString() + "</td>";
            }
            else
            {
                strHTML += "<td align='center'> 0 </td>";
                i--;
            }
            x++;
        }
        
        foreach (DataRow row in dt1.Rows)
            strHTML += "<td align='center'>" + row["Tickets"].ToString() + "</td>";
        strHTML += "</tr>";
        strHTML += "</table>";
        strHTML += "</div>";

        dt = new DataTable();
        if (Roles.IsUserInRole("Agency"))
        {
            strQry = @"  SELECT p1.Prize,stuff( (SELECT ','+  cast( p2.TicketNumber as varchar)
                  FROM PrizeDetails p2 join AllTickets b on p2.ExamID = b.ExamID  and p2.TicketNumber = b.TicketNumber
                  WHERE p2.ExamID = '" + DropDownList1.SelectedValue + @"' AND b.AgencyUserId = '" + Guid.Parse(curUserId) + @"' and p2.Prize = p1.Prize 
                  ORDER BY p2.TicketNumber
                  FOR XML PATH(''), TYPE).value('.', 'varchar(max)')
                  ,1,1,'')
                  AS Tickets
                  FROM PrizeDetails p1 join AllTickets b on p1.ExamID = b.ExamID and p1.TicketNumber = b.TicketNumber WHERE p1.ExamID = '" + DropDownList1.SelectedValue + @"'
                  AND b.AgencyUserId = '" + Guid.Parse(curUserId) + "' GROUP BY Prize ORDER BY Prize;";
        }
        else
        {
            strQry = @"  SELECT p1.Prize,stuff( (SELECT ','+  cast( TicketNumber as varchar)
                  FROM PrizeDetails p2 
                  WHERE p2.ExamID = '" + DropDownList1.SelectedValue + @"' and p2.Prize = p1.Prize 
                  ORDER BY TicketNumber
                  FOR XML PATH(''), TYPE).value('.', 'varchar(max)')
                  ,1,1,'')
                  AS Tickets
                  FROM PrizeDetails p1 WHERE p1.ExamID = '" + DropDownList1.SelectedValue + @"'
                  GROUP BY Prize ORDER BY Prize;";

        }
        cmd = new SqlCommand(strQry,con);
        da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        strHTML += "<table border='1' style='border: 0px solid black; width: 90%; word-wrap:break-word; table-layout: fixed;'>'";
        foreach (DataRow row in dt.Rows)
        {
            strHTML += "<tr>";
            strHTML += "<td width='10%' valign='top' > <div id='" + row["Prize"].ToString() + "'>" + row["Prize"].ToString() + " <br> <a href='#top'> Top </a> </div></td>";
            strHTML += "<td width='90%'>" + row["Tickets"].ToString() + "</td>";
            strHTML += "</tr>";
        }
        strHTML += "</table>";
        strHTML += "</center>";
        strHTML += "</body>";
        Literal1.Text = strHTML;
        btnView.Enabled = true;
        }
        catch (Exception ex)
        {
            Literal1.Text = curUserId + "  " + strQry + " " + ex.Message.ToString();
            btnView.Enabled = true;
        }
    }
}