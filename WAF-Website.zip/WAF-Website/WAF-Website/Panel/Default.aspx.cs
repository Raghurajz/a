﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Panel_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LoginButton_Click(object sender, EventArgs e)
    {

        if ((Roles.IsUserInRole(LoginUser.UserName, "Admin")))
        {
              Response.Redirect("Admin/CategoryList.aspx",true);
           // Response.Redirect("Panel/PanelHome.aspx", true);
        }
        else if (Roles.IsUserInRole(LoginUser.UserName, "Agency"))
        {
            this.Response.Redirect("~/Panel/Agency/ManageAllocationForRetailers.aspx");
        }
        else
        {
            this.Response.Redirect("~/Login.aspx");
        }

    }
}