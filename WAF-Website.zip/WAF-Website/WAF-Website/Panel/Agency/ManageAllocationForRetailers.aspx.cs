﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_ManageAllocationForRetailers : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    long GrandTotal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateExam();
            UpdateSalesInfo();
            Reset();
            loadData();
        }
    }


    protected void PopulateExam()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT ExamID, ExamName + ' - ' + FORMAT(ExamDateTime, 'dd/MM/yyyy HH:mm:ss') as ExamName from Exam Where IsScheduleActive=1 and examdatetime > DATEADD(mi,330,GETUTCDATE()) and isdeleted=0 order by examdatetime", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddlExam.Items.Clear();
            foreach (DataRow dr in dt.Rows)
                ddlExam.Items.Add(new ListItem(dr["ExamName"].ToString(), dr["ExamID"].ToString()));
            con.Close();
        }
    }
    protected void UpdateSalesInfo()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            lblTotalAllocated.Text = new SqlCommand(@"Select ISNULL(count(*),0) as  TotalAllocated from AllTickets a where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0 AND AgencyUserId = '" + Membership.GetUser().ProviderUserKey.ToString() + "'", con).ExecuteScalar().ToString();
            lblTotalSales.Text = new SqlCommand(@"Select ISNULL(count(*),0) as  TotalSales from AllTickets a  where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.isdeleted=0  AND RetailerUserId IS NOT NULL AND AgencyUserId = '" + Membership.GetUser().ProviderUserKey.ToString() + "'", con).ExecuteScalar().ToString();

            con.Close();
        }
    }

    protected void AllocateTickets()
    {
        DateTime AllocatedDateTime = DateTime.UtcNow.AddMinutes(330);

        SqlCommand cmd = new SqlCommand("SELECT * from AllocationMasterForRetailer WHERE isdeleted=0 AND AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'", con);
        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        foreach (DataRow dr in dt.Rows)
        {
            SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETSBYAGENCY", con);
            cmdAllocate.CommandType = CommandType.StoredProcedure;

            SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = long.Parse(ddlExam.SelectedValue.ToString());

            SqlParameter p2 = new SqlParameter("@AgencyID", SqlDbType.UniqueIdentifier);
            p2.Direction = ParameterDirection.Input;
            p2.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString()); 

            SqlParameter p3 = new SqlParameter("@RetailerUserId", SqlDbType.UniqueIdentifier);
            p3.Direction = ParameterDirection.Input;
            p3.Value = new Guid(dr["RetailerUserId"].ToString());

            SqlParameter p4 = new SqlParameter("@AllocatedBy", SqlDbType.UniqueIdentifier);
            p4.Direction = ParameterDirection.Input;
            p4.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

            SqlParameter p5 = new SqlParameter("@TotalTickets", SqlDbType.BigInt);
            p5.Direction = ParameterDirection.Input;
            p5.Value = long.Parse(dr["TicketAllocation"].ToString());

            cmdAllocate.Parameters.Add(p1);
            cmdAllocate.Parameters.Add(p2);
            cmdAllocate.Parameters.Add(p3);
            cmdAllocate.Parameters.Add(p4);
            cmdAllocate.Parameters.Add(p5);

            cmdAllocate.ExecuteNonQuery();

        }

    }


    protected void AllocateUnSoldTickets()
    {
        DateTime AllocatedDateTime = DateTime.UtcNow.AddMinutes(330);

        SqlCommand cmdAllocate = new SqlCommand("ALLOCATETICKETSBYAGENCY", con);
        cmdAllocate.CommandType = CommandType.StoredProcedure;

        SqlParameter p1 = new SqlParameter("@ExamID", SqlDbType.BigInt);
        p1.Direction = ParameterDirection.Input;
        p1.Value = long.Parse(ddlExam.SelectedValue.ToString());

        SqlParameter p2 = new SqlParameter("@AgencyID", SqlDbType.UniqueIdentifier);
        p2.Direction = ParameterDirection.Input;
        p2.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

        SqlParameter p3 = new SqlParameter("@RetailerUserId", SqlDbType.UniqueIdentifier);
        p3.Direction = ParameterDirection.Input;
        p3.Value = new Guid(ddlRetailer.SelectedValue.ToString());

        SqlParameter p4 = new SqlParameter("@AllocatedBy", SqlDbType.UniqueIdentifier);
        p4.Direction = ParameterDirection.Input;
        p4.Value = new Guid(Membership.GetUser().ProviderUserKey.ToString());

        SqlParameter p5 = new SqlParameter("@TotalTickets", SqlDbType.BigInt);
        p5.Direction = ParameterDirection.Input;
        p5.Value = long.Parse(txtTicketAllocation.Text);

        cmdAllocate.Parameters.Add(p1);
        cmdAllocate.Parameters.Add(p2);
        cmdAllocate.Parameters.Add(p3);
        cmdAllocate.Parameters.Add(p4);
        cmdAllocate.Parameters.Add(p5);

        cmdAllocate.ExecuteNonQuery();


    }


    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (DataBinder.Eval(e.Row.DataItem, "TicketAllocation") != DBNull.Value)
                GrandTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "TicketAllocation"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblGrandTotal = (Label)e.Row.FindControl("lblGrandTotal");
            lblGrandTotal.Text = GrandTotal.ToString();
        }
    }

    protected bool IsTicketsAvailable(long TicketCount)
    {
        if (GetAvailableTickets() >= TicketCount)
            return true;
        else
            return false;
    }

    protected long GetAvailableTickets()
    {
        long retValue;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
                retValue = long.Parse(new SqlCommand("SELECT COUNT(*) FROM AllTickets WHERE Examid ='" +
                                            ddlExam.SelectedValue.ToString() +
                                            "' AND  RetailerUserId IS NULL AND  AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'", con).ExecuteScalar().ToString());
            con.Close();
        }
        return retValue;
    }

    protected long GetTotalTicketsFromAllocationMaster()
    {
        long retValue;
        string strQuery = "";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            strQuery = "SELECT ISNULL(SUM(TicketAllocation),0) as Total FROM AllocationMasterForRetailer WHERE AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'";
            retValue = long.Parse(new SqlCommand(strQuery, con).ExecuteScalar().ToString());
            con.Close();
        }
        return retValue;
    }

    protected void btnAllocateMaster_Click(object sender, EventArgs e)
    {
        string confirmValue = Request.Form["confirm2_value"];
        if (confirmValue == "Yes")
        {

            if (IsTicketsAvailable(GetTotalTicketsFromAllocationMaster()) )
            {

                if (con.State == ConnectionState.Closed)
                    con.Open();
                try
                {
                    AllocateTickets();
                }
                catch (Exception e1)
                {
                    new SqlCommand("update AllTickets  set RetailerUserId = null, AllocationIDByAgency=null WHERE ExamID='" + ddlExam.SelectedValue.ToString() + "' and AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'", con).ExecuteNonQuery();
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('" + e1.Message + ")", true);
                }
                if (con.State == ConnectionState.Open)
                    con.Close();
                loadData();
                UpdateSalesInfo();
                Reset();
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Alloted!')", true);
            }
            else
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Not Enough Tickets Available for Allocation!')", true);
            }
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked YES!')", true);
        }
        else
        {
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked NO!')", true);
        }
    }

    protected void btnAllocate_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";

        string confirmValue = Request.Form["confirm_value"];
        if (confirmValue == "Yes")
        {

            if (IsTicketsAvailable(GetAvailableTickets()))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                try
                {
                    AllocateUnSoldTickets();
                }
                catch (Exception e1)
                {
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('" + e1.Message + ")", true);
                }
                if (con.State == ConnectionState.Open)
                    con.Close();
                loadData();
                UpdateSalesInfo();
                Reset();
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Alloted!')", true);
            }
            else
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Not Enough Tickets Available for Allocation!')", true);
            }
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked YES!')", true);
        }
        else
        {
            //this.Page.ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('You clicked NO!')", true);
        }

        //ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }

    protected void BindRetailer()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
                                                    join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
                                                    join aspnet_Roles r on ur.RoleId= r.RoleId
                                                    join Member m on u.UserId = m.MemberID
                                                    where r.RoleName='Retailer' AND m.under='" + Membership.GetUser().ProviderUserKey.ToString() + "' AND u.UserId NOT IN (SELECT distinct RetailerUserId from AllTickets WHERE Examid='" + ddlExam.SelectedValue.ToString() + "' AND AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString()  + "' AND RetailerUserId IS NOT NULL )", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);


            ddlRetailer.DataSource = ds;
            ddlRetailer.DataTextField = "UserName";
            ddlRetailer.DataValueField = "UserID";
            ddlRetailer.DataBind();
            con.Close();
        }
    }

    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand(@"Select a.RetailerUserId, m.MemberName  as RetailerName, 
                                            ISNULL(count(*),0)  as  TicketAllocation
                                            from AllTickets a join Member m on a.RetailerUserId= m.MemberID where a.ExamID='" + ddlExam.SelectedValue.ToString() + @"' AND a.AgencyUserId='" +  Membership.GetUser().ProviderUserKey.ToString()  + "' AND  a.isdeleted=0" + 
                                            " GROUP BY a.RetailerUserId, m.MemberName", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["ManageAllocationForRetailer"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        BindRetailer();
    }

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["ManageAllocationForRetailer"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void Reset()
    {
        txtTicketAllocation.Text = "";
        if (ddlRetailer.Items.Count > 0)
            ddlRetailer.SelectedIndex = 0;
        lblmsg.Text = "";
    }
}