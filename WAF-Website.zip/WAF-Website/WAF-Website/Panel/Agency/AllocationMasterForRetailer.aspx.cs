﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_AllocationMasterForRetailer : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    long GrandTotal = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Reset();
            loadData();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        lblmsg.Text = "";
        if (con.State == ConnectionState.Closed)
            con.Open();
        new SqlCommand(@"insert into AllocationMasterForRetailer(AgencyUserId, RetailerUserId, TicketAllocation) 
                            values('" + Membership.GetUser().ProviderUserKey.ToString() + "','" + ddlRetailer.SelectedValue + "','" + txtTickets.Text + "')", con).ExecuteNonQuery();
        loadData();
        Reset();
        con.Close();
        ClientScript.RegisterStartupScript(this.GetType(), "Success", "alert('Successfully Inserted');", true);
    }

    protected void BindRetailer()
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
                                                    join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
                                                    join aspnet_Roles r on ur.RoleId= r.RoleId
                                                    join Member m on u.UserId = m.MemberID
                                                    where r.RoleName='Retailer' and m.Under='" + Membership.GetUser().ProviderUserKey.ToString() + 
                                                    "' AND u.UserId NOT IN (SELECT RetailerUserId from AllocationMasterForRetailer)", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);


            ddlRetailer.DataSource = ds;
            ddlRetailer.DataTextField = "UserName";
            ddlRetailer.DataValueField = "UserID";
            ddlRetailer.DataBind();
            con.Close();
        }
    }

    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        SqlCommand cmd = new SqlCommand("Select a.AutoID, a.RetailerUserId, m.MemberName  as RetailerName, a.TicketAllocation from AllocationMasterForRetailer a join Member m on a.RetailerUserId= m.MemberID WHERE a.AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "' AND a.isdeleted=0", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["AllocationTableForRetailer"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
        BindRetailer();
    }

    protected void gridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gridView.EditIndex = e.NewEditIndex;
        loadData();
    }
    protected void gridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        lblmsg.Text = "";
        string AutoID = gridView.DataKeys[e.RowIndex].Values["AutoID"].ToString();
        DropDownList ddlRetailerEdit = (DropDownList)gridView.Rows[e.RowIndex].FindControl("ddlRetailerEdit");

        System.Web.UI.WebControls.TextBox TicketAllocation = (System.Web.UI.WebControls.TextBox)gridView.Rows[e.RowIndex].FindControl("txtTicketAllocation");

        con.Open();

        SqlCommand cmd = new SqlCommand("update AllocationMasterForRetailer set AgencyUserId='" + Membership.GetUser().ProviderUserKey.ToString() + "', " +
                    "TicketAllocation='" + TicketAllocation.Text + "' where AutoID=" + AutoID, con);
        cmd.ExecuteNonQuery();
        con.Close();
        lblmsg.BackColor = Color.Blue;
        lblmsg.ForeColor = Color.White;
        lblmsg.Text = "Updated successfully...";
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridView.EditIndex = -1;
        loadData();
    }
    protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        lblmsg.Text = "";
        string AutoID = gridView.DataKeys[e.RowIndex].Values["AutoID"].ToString();
        //if (!IsRecordExists(ExamID))
        //{
        con.Open();
        SqlCommand cmd = new SqlCommand("delete from AllocationMasterForRetailer where AutoID=" + AutoID, con);
        int result = cmd.ExecuteNonQuery();
        con.Close();
        if (result == 1)
        {
            loadData();
            lblmsg.BackColor = Color.Red;
            lblmsg.ForeColor = Color.White;
            lblmsg.Text = "Deleted successfully...";
        }
        //}
        //else
        //{
        //    lblmsg.BackColor = Color.Red;
        //    lblmsg.ForeColor = Color.White;
        //    lblmsg.Text = "Exam Result Exist on this ID, So unable to Delete!";
        //}
    }

    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string name = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "RetailerName"));
            System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete");
            //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
            if (lnkbtnresult != null)
            {
                lnkbtnresult.Attributes.Add("onclick", "javascript:return deleteConfirm('" + name + "')");
            }
            if(DataBinder.Eval(e.Row.DataItem, "TicketAllocation") != DBNull.Value)
                GrandTotal += Convert.ToInt64(DataBinder.Eval(e.Row.DataItem, "TicketAllocation"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblGrandTotal = (Label)e.Row.FindControl("lblGrandTotal");
            lblGrandTotal.Text = GrandTotal.ToString();
        }

        //if (e.Row.RowType == DataControlRowType.DataRow && gridView.EditIndex == e.Row.RowIndex)
        //{

        //    con.Open();
        //    DropDownList ddlRetailerEdit = (DropDownList)e.Row.FindControl("ddlRetailerEdit");
        //    HiddenField hdnAgency = (HiddenField)e.Row.FindControl("hdnRetailer");
        //    SqlCommand cmd = new SqlCommand(@"SELECT m.MemberName + ' - ' + m.City as UserName, u.UserId as UserID from aspnet_users u 
        //                                            join aspnet_UsersinRoles ur on u.UserId = ur.UserId 
        //                                            join aspnet_Roles r on ur.RoleId= r.RoleId
        //                                            join Member m on u.UserId = m.MemberID
        //                                            where r.RoleName='Retailer' and m.Under='" + Membership.GetUser().ProviderUserKey.ToString() + "'", con);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    ddlRetailerEdit.DataSource = ds;
        //    ddlRetailerEdit.DataTextField = "UserName";
        //    ddlRetailerEdit.DataValueField = "UserID";
        //    ddlRetailerEdit.DataBind();
        //    ddlRetailerEdit.Items.FindByValue(hdnRetailer.Value).Selected = true;
        //    con.Close();
        //}

    }


    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["AllocationTableForRetailer"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void Reset()
    {
        if (ddlRetailer.Items.Count > 0)
            ddlRetailer.SelectedIndex = 0;
        txtTickets.Text = "";
        lblmsg.Text = "";
    }

}