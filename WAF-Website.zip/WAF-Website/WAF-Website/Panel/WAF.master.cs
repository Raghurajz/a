﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WAF : System.Web.UI.MasterPage, IMasterPage
{
    private string _bodyClass;
    public string BodyClass
    {
        get { return _bodyClass; }
        set { _bodyClass = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LtrCurrentExam.Text = "<b style='background: transparent; color: White; border: 0px; text-align: right; display: inline-block; '> Click here for Today's Online Examination &nbsp; <i class='fa fa-hand-o-right' aria-hidden='true'></i> </b>";
            //lblTime.Text = DateTime.Now.ToString("hh:mm:ss");
        }

        //System.Threading.Thread.Sleep(100);
        //string currenttime = DateTime.Now.ToLongTimeString();
        //lblTime.Text = currenttime;
        
    }
    protected void btnModal_OnClick(object sender, EventArgs e)
    {
        Response.Redirect("~/SignIn.aspx");
    }

    //protected void TimerTime_Tick(object sender, EventArgs e)
    //{
    //    lblTime.Text = DateTime.Now.ToString("hh:mm:ss");
    //}
   
}
