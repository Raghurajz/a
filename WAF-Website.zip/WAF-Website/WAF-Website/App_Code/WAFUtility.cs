﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
/// <summary>
/// Summary description for WAFUtility
/// </summary>
public static class WAFUtility
{


    public static long getWinningNumber(long GroupID )
    {
        
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("getwinningnumber", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter p1 = new SqlParameter("@GroupID", SqlDbType.BigInt);
            p1.Direction = ParameterDirection.Input;
            p1.Value = GroupID;

            SqlParameter p2 = new SqlParameter("@p2", SqlDbType.BigInt);
            p2.Direction = ParameterDirection.ReturnValue;

            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);

            cmd.ExecuteNonQuery();
            long retValue = long.Parse(p2.Value.ToString());
            con.Close();

            return retValue;

        }

    }

}