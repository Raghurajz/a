﻿using System;
/// <summary>
/// Summary description for PaytmConstants
/// </summary>

namespace PaytmContant
{
    public static class PaytmConstants
    {
        public static string MID = "StateC31562155830448";
        public static string MERCHANT_KEY = "ct33NSoM0ZjeL%dm";
        public static string INDUSTRY_TYPE_ID = "Retail";
        public static string CHANNEL_ID = "WAP";
        public static string WEBSITE = "";
        
    }
}