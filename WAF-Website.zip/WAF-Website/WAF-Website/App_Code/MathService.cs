﻿using System;
using System.Collections.Generic;
using System.Web.Security;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Web.Services;
using System.Web.Script;
using System.Web.Script.Serialization;
using System.Net;
using System.IO;
/// <summary>
/// Summary description for MathService
/// </summary>
[WebService(Namespace = "http://winmoneyindia.online/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.ComponentModel.ToolboxItem(false)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class MathService : System.Web.Services.WebService {

    public class BookedTicket
    {
        public long AllocationID;
        public string TicketNumber;
        public String PassWrd;

    }

    [WebMethod]
    public bool ValidateUser(string username, string password)
    {
        //return (a + b);
        
        if (Membership.ValidateUser(username, password))
            return true;
        else
            return false;

        //int x;
        //using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        //{
        //    conn.Open();
            
        //    SqlCommand cmd = new SqlCommand("select groupid from exam where examid=32",conn);
        //    x= int.Parse(cmd.ExecuteScalar().ToString());
        //    conn.Close();
        //}
        //return x;
        
    }
    [WebMethod]
    public long GetCurrentExam()
    {

        long x;
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select dbo.GetCurrentExam()", conn);
            x = long.Parse(cmd.ExecuteScalar().ToString());
            conn.Close();
        }
        return x;

    }


    public Guid GetUserIdByName(string uname)
    {
        Guid retValue;
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select UserId from aspnet_users WHERE UserName = '" + uname + "'",conn);
            retValue = (Guid)cmd.ExecuteScalar();
            conn.Close();
        }
        return retValue;

    }
   
    [WebMethod]
    public long GetBalance(long curExam, string Retailer)
    {

        long x;
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select dbo.[M_GETBALANCE](" + curExam + ",'" + GetUserIdByName(Retailer) + "')" , conn);
            x = long.Parse(cmd.ExecuteScalar().ToString());
            conn.Close();
        }
        return x;

    }

    [WebMethod]
    public long GetAllocated(long curExam, string Retailer)
    {

        long x;
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select dbo.[M_GETALLOCATED](" + curExam + ",'" + GetUserIdByName(Retailer) + "')", conn);
            x = long.Parse(cmd.ExecuteScalar().ToString());
            conn.Close();
        }
        return x;

    }

    [WebMethod]
    public string GetBookedTicketsJSON(long curExam, string Phone, string TicketCount, string agency )
    {
        List<BookedTicket>  BookedTickets;
        using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.CommandText = "M_ALLOCATETICKETS";

            cmd.Parameters.Add("@ExamID", System.Data.SqlDbType.BigInt).Value = curExam;
            cmd.Parameters.Add("@PhoneNumber", System.Data.SqlDbType.VarChar, 50).Value = Phone;
            cmd.Parameters.Add("@RetailerUserId", System.Data.SqlDbType.UniqueIdentifier).Value = GetUserIdByName(agency);
            cmd.Parameters.Add("@TicketCount", System.Data.SqlDbType.BigInt).Value = TicketCount;
            


            SqlDataReader reader = cmd.ExecuteReader();
            BookedTickets = new List<BookedTicket>();

            while (reader.Read())
            {
                
                BookedTicket tempTicket =  new BookedTicket();
                tempTicket.TicketNumber =  reader["TicketNumber"].ToString();
                tempTicket.PassWrd =  reader["PassWrd"].ToString();
                tempTicket.AllocationID = long.Parse(reader["AllocationID"].ToString());
                BookedTickets.Add(tempTicket);
            }

            StreamReader objReader;
            string strMessageValue = "BK SUCCESS. Cust: " + Phone + ". Tickets:" + TicketCount + ". on " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss") + ". TxID " + BookedTickets[0].AllocationID.ToString() + ". Tkt/Pwd : ";
            string strTickets = "";
            foreach (BookedTicket rootObject in BookedTickets)
            {
                strTickets = strTickets + rootObject.TicketNumber.ToString() + " / " + rootObject.PassWrd.ToString() + ". ";
            }
            strMessageValue += strTickets;

            //string sURL = "http://sms.smso2.com/api/sendsms.php?user=Seller&apikey=fpzHspdav18xnyTUBanB&mobile=" + Phone + "&message=" + strMessageValue + "&senderid=SELLER&type=txt";
            string sURL = "http://smshorizon.co.in/api/sendsms.php?user=bagawansms&apikey=qbLGuIUWKH1xzYaGaBek&mobile=" + Phone + "&message=" + strMessageValue + "&senderid=BAGAWN&type=txt";
            WebRequest wrGETURL;
            wrGETURL = WebRequest.Create(sURL);
            try
            {
                Stream objStream;
                objStream = wrGETURL.GetResponse().GetResponseStream();
                objReader = new StreamReader(objStream);
                objReader.Close();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            conn.Close();
        }

        return new JavaScriptSerializer().Serialize(BookedTickets);

    }


    [WebMethod]
    public System.Single Subtract(System.Single A, System.Single B)
    {
        return (A - B);
    }

    [WebMethod]
    public System.Single Multiply(System.Single A, System.Single B)
    {
        return A * B;
    }

    [WebMethod]
    public System.Single Divide(System.Single A, System.Single B)
    {
        if (B == 0)
            return -1;
        return Convert.ToSingle(A / B);
    }
    
}
