﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
public partial class ModalExam1 : System.Web.UI.Page
{
    private static SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            loadData();
    }

    protected void loadData()
    {
        if (conn.State == ConnectionState.Closed)
            conn.Open();
        SqlCommand cmd = new SqlCommand("Select top 10 a.ExamID, a.ExamName, a.ExamDateTime, a.GroupID,b.GroupName from Exam a join QGroup b on a.GroupID= b.GroupID where a.isdeleted=0 and a.IsTrial=1 order by a.CreatedDateTime desc", conn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["ExamTable"] = ds.Tables[0];

        int count = ds.Tables[0].Rows.Count;
        conn.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
        }

    }

    protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    string id = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "ExamID"));
        //    System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonConduct");
        //    if (lnkbtnresult != null)
        //    {
        //        lnkbtnresult.Attributes.Add("onclick", "$find('mp1').show();");
        //    }
        //}

        //if (e.Row.RowType == DataControlRowType.DataRow && gridView.EditIndex == e.Row.RowIndex)
        //{

        //    conn.Open();
        //    DropDownList ddlGroupEdit = (DropDownList)e.Row.FindControl("ddlGroupEdit");
        //    HiddenField hdnGroup = (HiddenField)e.Row.FindControl("hdnGroup");
        //    SqlCommand cmd = new SqlCommand("select GroupID, GroupName from QGroup where isDeleted=0", conn);
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    ddlGroupEdit.DataSource = ds;
        //    ddlGroupEdit.DataTextField = "GroupName";
        //    ddlGroupEdit.DataValueField = "GroupID";
        //    ddlGroupEdit.DataBind();
        //    //ddlCategoryEdit.Items.Insert(0, new ListItem("--Select--", "0"));
        //    ddlGroupEdit.Items.FindByValue(hdnGroup.Value).Selected = true;
        //    conn.Close();
        //}
    }

    protected void gridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gridView.PageIndex = e.NewPageIndex;
        loadData();
    }

    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    }
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["ExamTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void ConductButton_Click(object sender, EventArgs e)
    {
        Session["IsAuth"]=1;
        long ExamID=  long.Parse((sender as LinkButton).CommandArgument);
        Response.Redirect("~/ConductExam.aspx?ExamID=" + ExamID.ToString());
    }
}