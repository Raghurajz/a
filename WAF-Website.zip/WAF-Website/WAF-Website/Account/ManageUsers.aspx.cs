﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;

using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Panel_Admin_ManageUsers : System.Web.UI.Page
{
    private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadData();
        }
    }
    public static MembershipUser GetCurrentUser()
    {
        HttpContext httpContext = HttpContext.Current;
        if (httpContext != null && httpContext.User != null && httpContext.User.Identity.IsAuthenticated)
        {
            return Membership.GetUser();
        }

        return null;
    }

    /// <summary>
    /// Safe check of authenticity. Better than Request.IsAuthenticated in that if there's a used-to-be-valid cookie which does not correspond to the current database, it will fail safe
    /// </summary>
    /// <returns></returns>
    public static bool IsUserAuthenticated()
    {
        if (HttpContext.Current == null)
            return false;

        var request = HttpContext.Current.Request;

        if (!request.IsAuthenticated)
            return false;

        var membershipUser = GetCurrentUser();

        if (membershipUser != null)
            return true;

        return false;
    }
    protected void loadData()
    {
        if (con.State == ConnectionState.Closed)
            con.Open();
        string strCondition = "";
        if (!Roles.IsUserInRole("Admin"))
            strCondition = " WHERE c.RoleName='Retailer' and Under='" + Membership.GetUser().ProviderUserKey.ToString() + "'";

        SqlCommand cmd = new SqlCommand(@"select  a.UserId as UserId,  a.UserName  as UserName, c.RoleName as RoleName, e.UserName as Under, 
                                                f.LoweredEmail as LoweredEmail, f.PasswordQuestion as PasswordQuestion, f.CreateDate as CreateDate, f.LastLoginDate as LastLoginDate, f.IsLockedOut as IsLockedOut
                                                from aspnet_Users a 
                                                join aspnet_UsersInRoles  b on a.UserId = b.userid
                                                join aspnet_Roles c on b.RoleId =c.RoleId
                                                join member d on a.UserId= d.MemberID
                                                join aspnet_Users e on d.under = e.UserId
                                                join aspnet_Membership f on a.UserId = f.UserId" + strCondition, con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        Session["UserTable"] = ds.Tables[0];
        int count = ds.Tables[0].Rows.Count;
        con.Close();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridView.DataSource = ds;
            gridView.DataBind();
        }
        else
        {
            ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
            gridView.DataSource = ds;
            gridView.DataBind();
            int columncount = gridView.Rows[0].Cells.Count;
            lblmsg.Text = " No data found !!!";
        }
    }

    //protected void gridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
    //{

    //    //string name = Convert.ToString(DataBinder.Eval(gridView.Rows[e.RowIndex].DataItem, "CategoryName"));
    //    string UserId = gridView.DataKeys[e.RowIndex].Values["UserId"].ToString();
    //    //if (!IsRecordExists(UserId))
    //    //{
    //        con.Open();
    //        SqlCommand cmd = new SqlCommand("UPDATE aspnet_Membership SET IsLockedOut=1 where UserId=" + UserId, con);
    //        int result = cmd.ExecuteNonQuery();
    //        con.Close();
    //        if (result == 1)
    //        {
    //            loadData();
    //            lblmsg.BackColor = Color.Red;
    //            lblmsg.ForeColor = Color.White;
    //            lblmsg.Text = UserId + " Locked successfully.......    ";
    //        }
    //    //}
    //    //else
    //    //{
    //    //    lblmsg.BackColor = Color.Red;
    //    //    lblmsg.ForeColor = Color.White;
    //    //    lblmsg.Text = "Question Exist on this ID, So unable to Delete!";
    //    //}
    //}

    //protected bool IsRecordExists(string id)
    //{
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("select count(*) from Question where CategoryID='" + id + "' and isdeleted=0", con);
    //    long x = Convert.ToInt64(cmd.ExecuteScalar().ToString());
    //    con.Close();
    //    if (x > 0)
    //        return true;
    //    else
    //        return false;
    //}

    //protected void gridView_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        string name = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "UserName"));
    //        //string name = e.Row.Cells[1].Text;
    //        System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.Cells[2].FindControl("ButtonDelete"); //access the LinkButton from the TemplateField using FindControl method
    //        //System.Web.UI.WebControls.Button lnkbtnresult = (System.Web.UI.WebControls.Button)e.Row.FindControl("System.Web.UI.WebControls.ButtonDelete");
    //        if (lnkbtnresult != null)
    //        {
    //            lnkbtnresult.Attributes.Add("onclick", "return ConfirmOnDelete('" + name + "');"); //attach the JavaScript function
    //        }
    //    }
    //}


    private string SortDir(string sField)
    {
        string sDir = "asc";
        string sPrevField = (ViewState["SortField"] != null ? ViewState["SortField"].ToString() : "");
        if (sPrevField == sField)
            sDir = (ViewState["SortDir"].ToString() == "asc" ? "desc" : "asc");
        else
            ViewState["SortField"] = sField;

        ViewState["SortDir"] = sDir;
        return sDir;
    } 
    protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = ((DataTable)Session["UserTable"]);
        dt.DefaultView.Sort = e.SortExpression + " " + SortDir(e.SortExpression);
        gridView.DataSource = dt;
        gridView.DataBind();
    }

    protected void btnSelect_Click(object sender, EventArgs e)
    {
        
        Button btn = (Button)sender;
        //1: red   0:green

        if (btn.CommandName == "True")
        {
            //change red to green.
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE aspnet_membership SET [IsLockedOut] = 0 WHERE [UserId] ='" + btn.CommandArgument.ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

        }
        else
        {
            //change green to red
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE aspnet_membership SET [IsLockedOut] = 1 WHERE [UserId] ='" + btn.CommandArgument.ToString() + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        loadData(); //rebind GridView

    }

}