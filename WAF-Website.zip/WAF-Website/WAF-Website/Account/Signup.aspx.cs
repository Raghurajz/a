﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Data;
using System.Net;
using System.IO;
public partial class Account_Signup : System.Web.UI.Page
{
    //string @file = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DropDownList ddlRoles = (DropDownList)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("ddlRoles");
            if (Roles.IsUserInRole("Admin"))
            {
                ddlRoles.Items.Clear();
                ddlRoles.Items.Add(new ListItem("Retailer","Retailer"));
                ddlRoles.Items.Add(new ListItem("Agency", "Agency"));
                ddlRoles.Items.Add(new ListItem("Admin", "Admin"));
            }
            else
            {
                ddlRoles.Items.Clear();
                ddlRoles.Items.Add(new ListItem("Retailer", "Retailer"));
            }
        }

    }
    protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
    {
        string insertSql;
        SqlConnection conn = null;
        //SqlCommand cmd;
        //SqlCommand cmd1;
        string snewUserId = "";
        Guid newUserId;
        SqlTransaction Transaction = null;
        bool IsCommited = false;
        string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString;

        try
        {
            conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
            conn.Open();
            Transaction = conn.BeginTransaction("CreateUser");
            DropDownList ddlRoles = (DropDownList)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("ddlRoles");
            Roles.AddUserToRole(CreateUserWizard1.UserName.ToString(), ddlRoles.SelectedValue.ToString());
            //if (Roles.IsUserInRole("Admin") )
            //    Roles.AddUserToRole(CreateUserWizard1.UserName.ToString(), "Agency");
            //else
            //    Roles.AddUserToRole(CreateUserWizard1.UserName.ToString(), "Retailer");

            string sName = Page.User.Identity.Name;
            MembershipUser newUser = Membership.GetUser(CreateUserWizard1.UserName);
            newUserId = (Guid)newUser.ProviderUserKey;
            snewUserId = newUser.ProviderUserKey.ToString();

            String MemberName = ((TextBox)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("txtMemberName")).Text;
            String MobileNumber = ((TextBox)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("txtMobile")).Text;

            insertSql = "INSERT INTO Member(MemberID, MemberName, MobileNumber,Under) VALUES('" +
                            newUserId + "','" + MemberName + "','" + MobileNumber + "','" + Membership.GetUser().ProviderUserKey.ToString() +  "')";
            new SqlCommand(insertSql, conn, Transaction).ExecuteNonQuery();

            Transaction.Commit();
            IsCommited = true;

            //erg.SendSMS("WELCOME TO ERG BIO CARE PVT LTD YOUR ID " + CreateUserWizard1.UserName + " PW " + CreateUserWizard1.Password + " PIN " + PIN + " REACH GREEN %26 RICH LIFE JOIN DATE " + DateTime.UtcNow.AddHours(5.5), MobileNumber);


            //string @folder = CreateUserFolder();
            //@file = @folder + "/Welcome_Receipt.zip";
            //ZipFile zip = new ZipFile();

            //zip.AddFile(Server.MapPath(GenerateReport(newUser.ProviderUserKey.ToString(), @folder, "receipt")), "");
            //zip.AddFile(Server.MapPath(GenerateReport(newUser.ProviderUserKey.ToString(), @folder, "welcome")), "");
            //zip.Save(Server.MapPath(@file));

            //HyperLink h1 = (HyperLink)CreateUserWizard1.CompleteStep.ContentTemplateContainer.FindControl("HyperLink1");
            //HyperLink h2 = (HyperLink)CreateUserWizard1.CompleteStep.ContentTemplateContainer.FindControl("HyperLink2");
            //string lckStatus = (new SqlCommand("Select IsLocked from PIN WHERE PIN = '" + PIN + "'", conn)).ExecuteScalar().ToString();
            //if (lckStatus == "False")
            //{
            //    SendEmail();
            //    h1.NavigateUrl = "~/Downloading.aspx?file=" + folder + "/welcome.pdf&split=3";
            //    h2.NavigateUrl = "~/Downloading.aspx?file=" + folder + "/receipt.pdf&split=3";
            //}
            //else
            //{
            //    h1.Visible = false;
            //    h2.Visible = false;
            //}

            //erg.GetProgress();
            //Master.Master.CurrentProgressText = " <font color='white'  face='Tw Cen MT' size='4px'> <b> <i>Left Count : " + Session["LeftCount"] + ", Right Count : " + Session["RightCount"] + " </font></i></b>";

            conn.Close();
        }
        catch (Exception ex)
        {
            if (!(Transaction == null))
            {
                if (IsCommited == false)
                {
                    Transaction.Rollback();
                    Membership.DeleteUser(CreateUserWizard1.UserName);
                }
            }


            conn.Close();
            // Store the error message in the Context and transfer back to the page preserving the form
            Context.Items.Add("ErrorMessage", "<font color='red'>" + ex.Message + "</font>");

            CustomValidator custValidator = (CustomValidator)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("CustomValidator");
            custValidator.ErrorMessage = Context.Items["ErrorMessage"].ToString();
            custValidator.IsValid = false;
            Server.Transfer(Request.Url.PathAndQuery, true);
        }

    }

    //protected void SendEmail()
    //{
    //    string content = "";
    //    content = content + "Dear " + CreateUserWizard1.UserName + "," + "<br/><br/>";
    //    content = content + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "Welcome to ERG BIO-CARE family and congratulations on having taken the first  step towards a very prosperous and promising future. <br/>Wish you to achieve better accuracy. <br/>";
    //    content = content + "<br>Find the attached welcome letter and receipt for more details.";
    //    content = content + "<br/> <br/> <b> <i> Login to <a href='www.ergmarketing.in/Home.aspx'> www.ergmarketing.in </a> and Update account details </i></b>";
    //    content = content + "<br/> <br/> <br/> <b>With best regards </b><br/> ERG BIO-CARE PVT. LTD. <br> Reach Green &  Rich Life...";
    //    MailMessage message = new MailMessage();
    //    message.To.Add(new MailAddress(CreateUserWizard1.Email.ToString()));
    //    message.Subject = "Welcome Message - ERG Bio-Care";
    //    message.IsBodyHtml = true;
    //    message.Body = content;
    //    message.Attachments.Add(new Attachment(Server.MapPath(CreateUserFolder() + "/welcome.pdf")));
    //    message.Attachments.Add(new Attachment(Server.MapPath(CreateUserFolder() + "/receipt.pdf")));
    //    SmtpClient client = new SmtpClient();
    //    client.Send(message);
    //}

    //protected string CreateUserFolder()
    //{

    //    string @folder = "";
    //    try
    //    {
    //        @folder = "~/Files/" + Membership.GetUser(CreateUserWizard1.UserName).ProviderUserKey.ToString();
    //        if (!(Directory.Exists(Server.MapPath(@folder))))
    //            Directory.CreateDirectory(Server.MapPath(@folder));
    //    }
    //    catch (Exception e1)
    //    {
    //        Response.Write(e1.Message);
    //    }
    //    return @folder;
    //}

    //protected string GenerateReport(string @sMemberID, string @fName, string @ReportName)
    //{
    //    string file;
    //    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    //    con.Open();
    //    SqlCommand cmd = null;
    //    if (@ReportName == "welcome")
    //        cmd = new SqlCommand("SELECT A.*, B.UserName AS UserName, C.UserName  AS SponsorUserName, D.PIN AS SponsorPIN " +
    //                                     "from MEMBER A " +
    //                                     "JOIN aspnet_users B ON A.MemberID=B.UserId " +
    //                                     "JOIN aspnet_users C ON A.SponsorID = C.UserId " +
    //                                     "JOIN member D ON A.SponsorID = D.MemberID WHERE a.MemberID = '" + @sMemberID + "'");
    //    else if (@ReportName == "receipt")
    //        cmd = new SqlCommand("select a.*, b.UserName as UserName,d.ProductName, d.Rate, dbo.AmountToWords(d.Rate) As AmountInWords " +
    //                                    "from Member a " +
    //                                    "join aspnet_users b on a.memberid=b.userid " +
    //                                    "join pin c on a.pin=c.pin " +
    //                                    "join product d on c.productid=d.productid  WHERE a.MemberID = '" + @sMemberID + "'");

    //    using (SqlDataAdapter sda = new SqlDataAdapter())
    //    {
    //        cmd.Connection = con;
    //        sda.SelectCommand = cmd;
    //        DataSet ds = new DataSet();
    //        sda.Fill(ds);
    //        using (ReportViewer viewer1 = new ReportViewer())
    //        {
    //            viewer1.ProcessingMode = ProcessingMode.Local;

    //            if (@ReportName == "welcome")
    //                viewer1.LocalReport.ReportPath = Server.MapPath("~/Member/welcome.rdlc");
    //            else if (@ReportName == "receipt")
    //                viewer1.LocalReport.ReportPath = Server.MapPath("~/Member/receipt.rdlc");

    //            ReportDataSource rds = new ReportDataSource("DataSet1", ds.Tables[0]);
    //            viewer1.LocalReport.DataSources.Clear();
    //            viewer1.LocalReport.DataSources.Add(rds);
    //            viewer1.LocalReport.Refresh();
    //            file = @fName + "/" + @ReportName + ".pdf";
    //            Save(viewer1, file);
    //            con.Close();
    //            con.Dispose();
    //            return file;
    //        }
    //    }

    //}

    //protected void Save(ReportViewer viewer, String savePath)
    //{
    //    Warning[] warnings;
    //    string[] streamIds;
    //    string mimeType = string.Empty;
    //    string encoding = string.Empty;
    //    string extension = string.Empty;
    //    byte[] Bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out extension, out streamIds, out warnings);

    //    using (FileStream Stream = new FileStream(Server.MapPath(savePath), FileMode.Create))
    //    {
    //        Stream.Write(Bytes, 0, Bytes.Length);
    //    }
    //}


    protected void CreateUserWizard1_CreatingUser(object sender, LoginCancelEventArgs e)
    {
        if (Context.Items["ErrorMessage"] != null)
        {

            CustomValidator custValidator = (CustomValidator)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("CustomValidator");
            custValidator.ErrorMessage = Context.Items["ErrorMessage"].ToString();
            custValidator.IsValid = false;
            e.Cancel = true;
        }
    }
    //protected void txtSponsorPIN_TextChanged(object sender, EventArgs e)
    //{
    //    TextBox txt = (TextBox)sender;
    //    if (txt.Text.Length == 32)
    //    {
    //        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    //        conn.Open();

    //        SqlCommand cmd;
    //        cmd = new SqlCommand("Select MemberID from Member where PIN='" + txt.Text + "'", conn);
    //        string MemberID = cmd.ExecuteScalar().ToString();

    //        cmd = new SqlCommand("Select DISTINCT Position from Member where SponsorID='" + MemberID + "'", conn);
    //        DataTable dt = new DataTable();
    //        SqlDataAdapter da = new SqlDataAdapter(cmd);
    //        da.Fill(dt);
    //        DropDownList ddl = (DropDownList)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("ddPosition");

    //        if (dt.Rows.Count > 0)
    //        {
    //            ddl.Items.Clear();
    //            if (dt.Rows.Count == 1)
    //            {
    //                if (dt.Rows[0].ItemArray[0].ToString() == "1")
    //                    ddl.Items.Add(new ListItem("Right", "2"));
    //                else
    //                    ddl.Items.Add(new ListItem("Left", "1"));
    //                ddl.Items[0].Selected = true;
    //            }
    //            else
    //            {
    //                ClientScript.RegisterStartupScript(this.GetType(), "Invalid Sponsor", "alert('Position not available for the User');", true);
    //                return;
    //            }

    //        }
    //        else
    //        {
    //            ddl.Items.Clear();
    //            ddl.Items.Add(new ListItem("Left", "1"));
    //            ddl.Items.Add(new ListItem("Right", "2"));
    //        }

    //        if (Request["POS"] != "")
    //        {
    //            if (Request["POS"].ToString() == "1")
    //                ddl.SelectedValue = "1";
    //            else if (Request["POS"].ToString() == "2")
    //                ddl.SelectedValue = "2";
    //        }

    //        cmd = new SqlCommand("Select UserName from aspnet_Users where UserId='" + MemberID + "'", conn);
    //        string UserName = cmd.ExecuteScalar().ToString();

    //        if (Roles.IsUserInRole(UserName, "Member"))
    //            ((TextBox)CreateUserWizard1.CreateUserStep.ContentTemplateContainer.FindControl("txtUserID")).Text = UserName;

    //        conn.Close();
    //    }

    //}

}