﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
public partial class Account_MyAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            FillData();

        }
    }
    protected void Update_Click(object sender, EventArgs e)
    {
        SqlConnection conn = null;
        SqlCommand cmd;
        string sqlQry = "";
        SqlDataReader dr;
        conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();

        DateTime dt = new DateTime(int.Parse(txtDOB.Text.Substring(6, 4)), int.Parse(txtDOB.Text.Substring(3, 2)), int.Parse(txtDOB.Text.Substring(0, 2)));


        sqlQry = "UPDATE Member SET " +
                        "DateOfBirth = '" + dt + "', " +
                        "Gender = '" + ddGender.SelectedValue + "', " +
                        "MaritalStatus = '" + ddMaritalStatus.SelectedValue + "', " +
                        "RelationType = '" + ddRelationType.SelectedValue + "', " +
                        "RelationName = '" + txtRelationName.Text + "', " +
                        "NomineeRelationType = '" + ddNomineeType.SelectedValue + "', " +
                        "NomineeRelationName = '" + txtNomineeName.Text + "', " +
                        "PANCardNumber = '" + txtPanCardNumber.Text + "', " +
                        "IdentityType = '" + ddIdentity.SelectedValue + "', " +
                        "IdentityValue = '" + txtIdentityValue.Text + "', " +
                        "AccountNumber = '" + txtAccountNumber.Text + "', " +
                        "NameOfBank = '" + txtNameOfBank.Text + "', " +
                        "IFSCCode = '" + txtIFSCCode.Text + "', " +
                        "Address1 = '" + txtAddress1.Text + "', " +
                        "Address2 = '" + txtAddress2.Text + "', " +
                        "City = '" + txtCity.Text + "', " +
                        "Pincode = '" + txtPincode.Text + "', " +
                        "State = '" + txtDOB.Text + "', " +
                        "Country = '" + ddCountry.SelectedValue + "', " +
                        "MobileNumber = '" + txtMobile.Text + "', " +
                        "LastModifiedDateTime = '" + DateTime.UtcNow.AddHours(5.5) + "' WHERE " +
                        "MemberID='" + Membership.GetUser().ProviderUserKey.ToString() + "'";


        cmd = new SqlCommand(sqlQry, conn);
        cmd.ExecuteNonQuery();
        sqlQry = "UPDATE aspnet_Membership SET" +
                " Email = '" + txtEmail.Text + "', " +
                " LoweredEmail = '" + txtEmail.Text.ToLower() + "' WHERE " +
                "UserId='" + Membership.GetUser().ProviderUserKey.ToString() + "'";
        cmd = new SqlCommand(sqlQry, conn);
        cmd.ExecuteNonQuery();

        ClientScript.RegisterStartupScript(this.GetType(), "My Account", "alert(' Account Information Updated!');", true);

    }
    protected void FillData()
    {
        SqlConnection conn = null;
        SqlCommand cmd;
        string sqlQry = "";
        SqlDataReader dr;
        conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
        conn.Open();
        string a = Membership.GetUser().ProviderUserKey.ToString();
        sqlQry = "SELECT a.*,m.Email as Email, c.* " +
                        "FROM Member a " +
                        "LEFT OUTER JOIN aspnet_users c ON a.MemberID = c.UserId " +
                        "LEFT OUTER JOIN aspnet_Membership m ON a.MemberID=m.UserID " +
                        "WHERE a.MemberID='" + Membership.GetUser().ProviderUserKey.ToString() + "'";
        /*'sqlQry = "SELECT a.*,b.MemberName as SponsorName,c1.UserName as SponsorUserID,m.Email as Email, c.* FROM Member a, Member b, aspnet_users c,aspnet_users c1, aspnet_Membership m WHERE " +
                "a.SponsorID = b.MemberID and a.MemberID = c.UserId and a.SponsorID=c1.UserId and a.MemberID=m.UserID and " + 
                "a.MemberID='" + Membership.GetUser().ProviderUserKey.ToString() + "'";*/
        cmd = new SqlCommand(sqlQry, conn);
        dr = cmd.ExecuteReader();
        if (dr.HasRows)
        {
            dr.Read();
            ltrInformation.Text = "<b>" + dr["MemberName"] + "<br><br>";
            //                    + "<u>Under</u><br>" + dr["SponsorName"] + " (" + dr["SponsorUserID"] + ") - " + GetPositionByID(  Int32.Parse(dr["Position"].ToString()) ) ;

            SetSelectedItem(ddGender, dr["Gender"].ToString());



            txtDOB.Text = dr.GetDateTime(dr.GetOrdinal("DateOfBirth")).ToString("dd/MM/yyyy");
            SetSelectedItem(ddMaritalStatus, dr["MaritalStatus"].ToString());
            SetSelectedItem(ddRelationType, dr["RelationType"].ToString());
            txtRelationName.Text = dr["RelationName"].ToString();
            SetSelectedItem(ddNomineeType, dr["NomineeRelationType"].ToString());
            txtNomineeName.Text = dr["NomineeRelationName"].ToString();
            txtPanCardNumber.Text = dr["PANCardNumber"].ToString();
            if (txtPanCardNumber.Text.Length > 0)
                txtPanCardNumber.Enabled = false;
            SetSelectedItem(ddIdentity, dr["IdentityType"].ToString());
            txtIdentityValue.Text = dr["IdentityValue"].ToString();

            txtAccountNumber.Text = dr["AccountNumber"].ToString();
            if (txtAccountNumber.Text.Length > 0)
                txtAccountNumber.Enabled = false;
            txtNameOfBank.Text = dr["NameOfBank"].ToString();
            if (txtNameOfBank.Text.Length > 0)
                txtNameOfBank.Enabled = false;
            txtIFSCCode.Text = dr["IFSCCode"].ToString();
            if (txtIFSCCode.Text.Length > 0)
                txtIFSCCode.Enabled = false;

            txtAddress1.Text = dr["Address1"].ToString();
            txtAddress2.Text = dr["Address2"].ToString();
            txtCity.Text = dr["City"].ToString();
            txtPincode.Text = dr["Pincode"].ToString();

            SetSelectedItem(ddState, dr["State"].ToString());
            SetSelectedItem(ddCountry, dr["Country"].ToString());

            txtMobile.Text = dr["MobileNumber"].ToString();
            txtEmail.Text = dr["Email"].ToString();
        }

    }

    protected void SetSelectedItem(DropDownList dd, string sValue)
    {
        foreach (ListItem itm in dd.Items)
        {
            if (itm.Value.ToString() == sValue)
            {
                itm.Selected = true;
                return;
            }
        }

    }



}