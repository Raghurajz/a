/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function (config) {
    // Define changes to default configuration here. For example:
    // config.language = 'fr';
    // config.uiColor = '#AADC6E';
    config.extraPlugins = 'liststyle';
    config.extraPlugins = 'eqneditor';
    config.floatSpaceDockedOffsetX = 10;
    config.floatSpaceDockedOffsetY = 60;
    config.extraPlugins = 'pastefromword';
    config.pasteFromWordRemoveFontStyles = false;
    config.pasteFromWordRemoveStyles = false;
    config.enterMode = CKEDITOR.ENTER_BR;
    config.extraPlugins = 'sourcedialog';
};

