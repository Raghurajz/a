﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.Services;
using System.Drawing;
public partial class Home : System.Web.UI.Page
{
    //string str1 = "Data Source=.;Initial Catalog=WisdomAcademy;Persist Security Info=True;User ID=sa;Password=sa*123";
   private SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseServices"].ConnectionString);
    //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=WisdomAcademy;Persist Security Info=True;User ID=sa;Password=sa*123");
    protected void Page_Load(object sender, EventArgs e)
    {
        IMasterPage masterPage = Master as IMasterPage;
        if (masterPage != null)
        {
            masterPage.BodyClass = "home page page-id-7 page-template page-template-page-home page-template-page-home-php";
        }

     if (con.State == ConnectionState.Open )
            con.Open();
        string MessageText = new SqlCommand("select top 1 MessageText from ManageMessage", con).ToString();
        txtMessage.Text = MessageText;

    }

}