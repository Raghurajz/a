﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WhoWeAre : System.Web.UI.MasterPage, IMasterPage
{
    private string _bodyClass;
    public string BodyClass
    {
        get { return _bodyClass; }
        set { _bodyClass = value; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        IMasterPage masterPage = Master as IMasterPage;
        if (masterPage != null)
        {
            masterPage.BodyClass = _bodyClass;
        }

        if (!IsPostBack)
        {
            string str = System.IO.Path.GetFileName(Request.Url.ToString());
            switch (str.ToLower())
            {
                //case "accounts.aspx":
                //    accounts.Attributes.Add("class", "current_page_item");
                //    break;
                case "aboutus.aspx":
                    aboutUs.Attributes.Add("class", "current_page_item");
                    break;
                case "directors.aspx":
                    trustees.Attributes.Add("class", "current_page_item");
                    break;
            }
            
        }

    }
}
